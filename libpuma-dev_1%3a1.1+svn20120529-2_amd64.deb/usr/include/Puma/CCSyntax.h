#ifndef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CCSyntax_h__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 0x0004, EXECUTION = 0x0008, CONSTRUCTION = 0x0010, DESTRUCTION = 0x0020 };
  struct Action {
    void **_args; void *_result; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  struct AnyResultBuffer {};
  template <typename T> struct ResultBuffer : public AnyResultBuffer {
    struct { char _array[sizeof (T)]; } _data;
    ~ResultBuffer () { ((T&)_data).T::~T(); }
    operator T& () const { return (T&)_data; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__AttrTypes const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0 };
  };
  template<typename T> struct TypeInfo<T, 1> {
    enum { AVAILABLE = 1 };
    enum { ELEMENTS = T::__AttrTypes::ARGS };
    template<int I>
    struct Member : public AC::Arg<typename T::__AttrTypes,I> {};
    template<int I>
    static typename Member<I>::ReferredType* member (T* obj) {
      return (typename Member<I>::ReferredType*)obj->__attr (I);
    }
    static const char *member_name (T &obj, int i) {
      return obj.__attr_name (i);
    }
	 };
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
inline void * operator new (__SIZE_TYPE__, AC::AnyResultBuffer *p) { return p; }
inline void operator delete (void *, AC::AnyResultBuffer *) { } // for VC++
#endif // __cplusplus
#endif // __ac_h_
#endif // __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

#ifndef __ac_fwd_WinAsm__
#define __ac_fwd_WinAsm__
class WinAsm;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinAsm_WinAsm_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#endif

#ifndef __ac_fwd_WinDeclSpecs__
#define __ac_fwd_WinDeclSpecs__
class WinDeclSpecs;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#endif

#ifndef __ac_fwd_WinMemberExplSpec__
#define __ac_fwd_WinMemberExplSpec__
class WinMemberExplSpec;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinMemberExplSpec_WinMemberExplSpec_a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#endif

#ifndef __ac_fwd_WinTypeKeywords__
#define __ac_fwd_WinTypeKeywords__
class WinTypeKeywords;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinTypeKeywords_WinTypeKeywords_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#endif

#ifndef __ac_fwd_WinFriend__
#define __ac_fwd_WinFriend__
class WinFriend;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinFriend_WinFriend_a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#endif

#ifndef __ac_fwd_ExtACSyntaxCoupling__
#define __ac_fwd_ExtACSyntaxCoupling__
class ExtACSyntaxCoupling;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a2_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#endif

#ifndef __ac_fwd_ExtGnu__
#define __ac_fwd_ExtGnu__
class ExtGnu;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a3_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a5_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a6_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a7_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a8_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a11_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a13_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a15_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a16_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a17_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a18_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a21_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a23_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a25_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a26_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a34_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a35_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a36_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a37_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a38_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a39_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a40_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a41_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a43_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a45_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a47_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a49_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a51_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a52_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a53_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a54_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a55_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a56_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a57_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a58_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a59_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a60_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a61_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a62_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#endif

#ifndef __ac_fwd_LookAhead__
#define __ac_fwd_LookAhead__
class LookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_LookAhead_LookAhead_a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#endif

#ifndef __ac_fwd_CCLookAhead__
#define __ac_fwd_CCLookAhead__
class CCLookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCLookAhead_CCLookAhead_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#endif

#ifndef __ac_fwd_CCSemBinding__
#define __ac_fwd_CCSemBinding__
class CCSemBinding;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a4_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a5_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a6_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a7_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a8_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a11_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a16_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a17_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a18_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a23_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a24_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a26_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a28_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a34_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a35_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a36_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a37_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a38_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a39_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a40_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a41_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a43_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a45_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a47_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a49_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a51_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a52_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a53_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a54_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a55_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a56_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a57_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a58_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding_a59_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#endif

#ifndef __ac_fwd_ExtCC1X__
#define __ac_fwd_ExtCC1X__
class ExtCC1X;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a2_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a3_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a5_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a6_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#endif

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CCSyntax_h__
#define __CCSyntax_h__

// Parser for the C++ programming language

#include "Puma/CSyntax.h"

namespace Puma {


class CCSemantic;
class CCBuilder;
class CStructure;


#line 520 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 556 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 567 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 578 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 600 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 611 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 622 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 633 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 644 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 655 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 666 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 677 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 688 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 699 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 710 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 721 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 732 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 743 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 754 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 765 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 776 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 787 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 798 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 809 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 831 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 853 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 864 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 875 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 886 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 897 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 908 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 941 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 952 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 963 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 974 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 985 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 996 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1007 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1018 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1029 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1040 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1051 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1062 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1084 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1095 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1106 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1117 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1139 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1150 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1172 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1183 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1194 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1205 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1216 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1238 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1260 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1271 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1304 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1315 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1326 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1359 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1381 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1403 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1414 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1425 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1447 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1469 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1480 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1502 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1513 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1524 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1557 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1568 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1579 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1601 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1612 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1623 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1634 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1645 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1656 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1667 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1678 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1689 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1700 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1711 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1722 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1733 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1744 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1755 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1766 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1777 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1788 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1799 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1810 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1821 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1843 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1854 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1865 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1876 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1887 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1898 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1909 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1920 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1942 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1953 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1986 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1997 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2008 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2019 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2030 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2041 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2052 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2063 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2074 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2085 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2096 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2129 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2140 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2151 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2184 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2195 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2206 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2228 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2261 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2272 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2283 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2316 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2327 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2360 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2393 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2404 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
class CCSyntax : public CSyntax {
#line 2415 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2422 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

  friend class CCSemantic;
  int _skip_bodies;
  
  enum {
    SKIP_BODIES_NONE               = 0x0,  // don't skip function bodies
    SKIP_BODIES_ALL                = 0x1,  // skip all function bodies
    SKIP_BODIES_TPL                = 0x2,  // skip function bodies of templates
    SKIP_BODIES_NON_PRJ            = 0x4,  // skip bodies of non-project functions
    SKIP_BODIES_NON_PRIM           = 0x8   // skip bodies in non-primary files
  };

public:
  CCSyntax (CCBuilder &, CCSemantic &);
  
  virtual Grammar grammar () const { return GRAMMAR_CPLUSPLUS; }

  
#line 2473 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_configure(::Puma::Config & );

#line 50 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void configure (Config &);
  
  void config_skip_fct_body (bool s) { 
    if (s) _skip_bodies |= SKIP_BODIES_ALL; 
    else   _skip_bodies ^= (_skip_bodies & SKIP_BODIES_ALL); 
  }

protected:
  CCBuilder &builder () const;
  CCSemantic &semantic () const;

  // TODO: no idea why this can't be introduce by CCLookAhead.ah
  // Specific look-ahead functions
  virtual bool is_fct_def ();
  virtual bool is_nested_name ();
  virtual bool is_class_def ();
  virtual bool is_tpl_id ();
  virtual bool is_tpl_declarator_id ();
  virtual bool is_ptr_to_fct ();
  virtual bool is_nested (State);
  virtual bool is_ass_expr ();

  
#line 2500 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_prim_types();
protected:

#line 72 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void init_prim_types ();
  
#line 2507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_cv_quals();
protected:

#line 73 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void init_cv_quals ();
  
  virtual void init_explicit_instantiation ();
  virtual void init_explicit_specialization ();
  virtual void init_access_spec ();
  virtual void init_oper_fct_id ();
  virtual void init_template_key ();
  virtual void init_template_id ();
  virtual void init_class_template_id ();

  // Grammar rules
public:

  // A.1 Keywords
  struct ClassName {
#line 2527 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 87 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 87 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2568 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14266;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ClassName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 88 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 2602 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ClassName , ::Puma::CCSyntax::ClassName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 88 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ClassName CCClassNameBuilder;

#line 27 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 2623 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14271;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 2652 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 2654 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ClassName , ::Puma::CCSyntax::ClassName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a0_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 2666 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 302 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool class_name ();

  struct EnumName {
#line 2681 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 93 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2687 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 93 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2722 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14279;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::EnumName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 94 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 2756 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::EnumName , ::Puma::CCSyntax::EnumName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 94 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enum_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef EnumName CCEnumNameBuilder;

#line 34 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 2777 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14284;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 2806 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 2808 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::EnumName , ::Puma::CCSyntax::EnumName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a1_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 2820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 307 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _enum_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool enum_name ();

  struct TemplateName {
#line 2835 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 99 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2841 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 99 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2876 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14292;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::TemplateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 100 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 2910 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::TemplateName , ::Puma::CCSyntax::TemplateName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 100 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.template_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef TemplateName CCTemplateNameBuilder;

#line 41 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 2931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14297;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 2960 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 2962 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::TemplateName , ::Puma::CCSyntax::TemplateName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a2_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 2974 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _template_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool template_name ();

  struct ClassTemplateName {
#line 2989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 105 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 2995 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 105 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3030 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14305;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ClassTemplateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 106 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3064 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ClassTemplateName , ::Puma::CCSyntax::ClassTemplateName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 106 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_template_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ClassTemplateName CCClassTemplateNameBuilder;

#line 48 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 3085 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14310;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 3114 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 3116 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ClassTemplateName , ::Puma::CCSyntax::ClassTemplateName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a2_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 3128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 317 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_template_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool class_template_name ();

  struct NamespaceName {
#line 3143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 111 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3149 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 111 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3184 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14318;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NamespaceName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3218 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NamespaceName , ::Puma::CCSyntax::NamespaceName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NamespaceName CCNamespaceNameBuilder;

#line 55 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_name ( ) ;
}   public:

#line 322 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool namespace_name ();

  struct OriginalNsName {
#line 3252 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 117 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3258 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 117 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14331;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::OriginalNsName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3327 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::OriginalNsName , ::Puma::CCSyntax::OriginalNsName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef OriginalNsName CCOriginalNsNameBuilder;

#line 62 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 3348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14336;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 3377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 3379 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::OriginalNsName , ::Puma::CCSyntax::OriginalNsName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a3_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 3391 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 327 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _original_ns_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool original_ns_name ();

  struct NamespaceAlias {
#line 3406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 123 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 123 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3447 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14344;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NamespaceAlias::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3481 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NamespaceAlias , ::Puma::CCSyntax::NamespaceAlias ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_alias (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NamespaceAlias CCNamespaceAliasBuilder;

#line 69 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 3502 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14349;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 3531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 3533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NamespaceAlias , ::Puma::CCSyntax::NamespaceAlias ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a4_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 3545 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 332 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_alias_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool namespace_alias ();
  
  // A.2 Lexical conventions
  struct Literal {
#line 3561 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3567 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3602 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14357;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Literal::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 131 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3636 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Literal , ::Puma::CCSyntax::Literal ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 131 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.literal (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef Literal CCLiteralBuilder;

#line 76 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . literal ( ) ;
}   public:

#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _literal_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool literal ();

  // A.4 Expression
  struct PrimExpr {
#line 3671 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3677 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3712 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14370;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PrimExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 138 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PrimExpr , ::Puma::CCSyntax::PrimExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 138 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.prim_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef PrimExpr CCPrimExprBuilder;

#line 83 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . prim_expr ( ) ;
}   public:

#line 342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _prim_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool prim_expr ();

  struct IdExpr {
#line 3780 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3786 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3821 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14383;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::IdExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 144 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3855 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::IdExpr , ::Puma::CCSyntax::IdExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 144 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.id_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef IdExpr CCIdExprBuilder;

#line 90 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . id_expr ( ) ;
}   public:

#line 347 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _id_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool id_expr ();

  struct QualId {
#line 3889 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 149 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 3895 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 149 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14396;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::QualId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 150 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 3964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::QualId , ::Puma::CCSyntax::QualId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 150 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.qual_id (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef QualId CCQualIdBuilder;

#line 97 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . qual_id ( ) ;
}   public:

#line 352 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _qual_id_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool qual_id ();

  struct UnqualId {
#line 3998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4004 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4039 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14409;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UnqualId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UnqualId , ::Puma::CCSyntax::UnqualId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unqual_id (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef UnqualId CCUnqualIdBuilder;

#line 104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . unqual_id ( ) ;
}   public:

#line 357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _unqual_id_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool unqual_id ();

  struct ColonColon {
#line 4107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4113 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14422;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ColonColon::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ColonColon , ::Puma::CCSyntax::ColonColon ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.colon_colon (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ColonColon CCColonColonBuilder;

#line 111 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 4203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14427;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 4232 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 4234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ColonColon , ::Puma::CCSyntax::ColonColon ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a5_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 4246 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . get_node ( ) ;
}   public:

#line 362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _colon_colon_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool colon_colon ();

  struct NestedNameSpec {
#line 4261 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4267 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4302 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14435;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NestedNameSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NestedNameSpec , ::Puma::CCSyntax::NestedNameSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.nested_name_spec (); }
    
#line 4351 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 169 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef NestedNameSpec CCNestedNameSpecBuilder;

#line 118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 4362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14440;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 4391 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 4393 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NestedNameSpec , ::Puma::CCSyntax::NestedNameSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a6_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 4405 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . nested_name_spec ( ) ;
}   public:

#line 367 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> is_nested_name ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool nested_name_spec ();

  struct NestedNameSpec1 {
#line 4420 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4426 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14448;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NestedNameSpec1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 174 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NestedNameSpec1 , ::Puma::CCSyntax::NestedNameSpec1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 174 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.nested_name_spec1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NestedNameSpec1 CCNestedNameSpec1Builder;

#line 125 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 4516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14453;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 4545 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 4547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NestedNameSpec1 , ::Puma::CCSyntax::NestedNameSpec1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a8_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 4559 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . nested_name_spec1 ( ) ;
}   public:

#line 372 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> is_nested_name ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool nested_name_spec1 ();

  struct ClassOrNsName {
#line 4574 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4580 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4615 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14461;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ClassOrNsName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 180 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4649 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ClassOrNsName , ::Puma::CCSyntax::ClassOrNsName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 180 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_or_ns_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ClassOrNsName CCClassOrNsNameBuilder;

#line 132 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . class_or_ns_name ( ) ;
}   public:

#line 377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_or_ns_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool class_or_ns_name ();

  struct PostfixExpr {
#line 4683 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4689 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4724 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14474;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PostfixExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 186 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4758 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PostfixExpr , ::Puma::CCSyntax::PostfixExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 186 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef PostfixExpr CCPostfixExprBuilder;

#line 139 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 4779 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14479;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 4808 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 4810 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::PostfixExpr , ::Puma::CCSyntax::PostfixExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a11_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 4822 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{

return s . builder ( ) . postfix_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool postfix_expr ();

  struct PostfixExpr1 {
#line 4833 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4839 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4874 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14484;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PostfixExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 192 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 4908 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PostfixExpr1 , ::Puma::CCSyntax::PostfixExpr1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 192 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr1 (); }
    
#line 4923 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 193 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef PostfixExpr1 CCPostfixExpr1Builder;

#line 147 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 4934 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14489;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 4963 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 4965 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::PostfixExpr1 , ::Puma::CCSyntax::PostfixExpr1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a12_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 4977 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . postfix_expr1 ( ) ;
}   public:

#line 382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr1_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool postfix_expr1 ();

  struct PostfixExpr2 {
#line 4992 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 4998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5033 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14497;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PostfixExpr2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 198 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PostfixExpr2 , ::Puma::CCSyntax::PostfixExpr2 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 198 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr2 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef PostfixExpr2 CCPostfixExpr2Builder;

#line 154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 5088 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14502;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 5117 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 5119 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::PostfixExpr2 , ::Puma::CCSyntax::PostfixExpr2 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a14_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 5131 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . postfix_expr2 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool postfix_expr2 ();

  struct ConstructExpr {
#line 5141 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5147 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14507;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ConstructExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 204 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5216 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ConstructExpr , ::Puma::CCSyntax::ConstructExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 204 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.construct_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ConstructExpr CCConstructExprBuilder;

#line 161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . construct_expr ( ) ;
}   public:

#line 387 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _construct_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool construct_expr ();

  struct PseudoDtorName {
#line 5250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 209 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 209 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5291 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14520;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PseudoDtorName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PseudoDtorName , ::Puma::CCSyntax::PseudoDtorName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.pseudo_dtor_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef PseudoDtorName CCPseudoDtorNameBuilder;

#line 168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 5346 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14525;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 5375 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 5377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::PseudoDtorName , ::Puma::CCSyntax::PseudoDtorName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a15_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 5389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . pseudo_dtor_name ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool pseudo_dtor_name ();

  struct UnaryExpr {
#line 5399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 215 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5405 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 215 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5440 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14530;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UnaryExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 216 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UnaryExpr , ::Puma::CCSyntax::UnaryExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 216 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unary_expr (); }
    
#line 5489 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef UnaryExpr CCUnaryExprBuilder;

#line 175 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . unary_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool unary_expr ();

  struct TypeTraitExpr {
#line 5508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5514 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5549 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14540;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::TypeTraitExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::TypeTraitExpr , ::Puma::CCSyntax::TypeTraitExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.type_trait_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef TypeTraitExpr CCTypeTraitExprBuilder;

#line 182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . type_trait_expr ( ) ;
}   public:

#line 392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _type_trait_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool type_trait_expr ();

  struct NewExpr {
#line 5617 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5623 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5658 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14553;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NewExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 228 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5692 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NewExpr , ::Puma::CCSyntax::NewExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 228 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NewExpr CCNewExprBuilder;

#line 189 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_expr ( ) ;
}   public:

#line 397 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool new_expr ();

  struct NewPlacement {
#line 5726 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 233 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5732 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 233 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5767 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14566;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NewPlacement::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NewPlacement , ::Puma::CCSyntax::NewPlacement ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_placement (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NewPlacement CCNewPlacementBuilder;

#line 196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_placement ( ) ;
}   public:

#line 402 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_placement_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool new_placement ();

  struct NewTypeId {
#line 5835 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5841 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5876 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14579;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NewTypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 240 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 5910 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NewTypeId , ::Puma::CCSyntax::NewTypeId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 240 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_type_id (); }
    
#line 5925 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 241 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef NewTypeId CCNewTypeIdBuilder;

#line 203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 5936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14584;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 5965 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 5967 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NewTypeId , ::Puma::CCSyntax::NewTypeId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a16_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 5979 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool new_type_id ();

  struct NewDeclarator {
#line 5989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 5995 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6030 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14589;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NewDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 246 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6064 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NewDeclarator , ::Puma::CCSyntax::NewDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 246 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_declarator (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NewDeclarator CCNewDeclaratorBuilder;

#line 210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 6085 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14594;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 6114 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 6116 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NewDeclarator , ::Puma::CCSyntax::NewDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a18_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 6128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . abst_declarator ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool new_declarator ();

  struct DirectNewDeclarator {
#line 6138 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 251 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6144 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 251 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14599;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DirectNewDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 252 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6213 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DirectNewDeclarator , ::Puma::CCSyntax::DirectNewDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 252 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_new_declarator (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DirectNewDeclarator CCDirectNewDeclaratorBuilder;

#line 217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 6234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14604;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 6263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 6265 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::DirectNewDeclarator , ::Puma::CCSyntax::DirectNewDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a19_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 6277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . direct_new_declarator ( ) ;
}   public:

#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_new_declarator_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool direct_new_declarator ();

  struct DirectNewDeclarator1 {
#line 6292 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6333 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14612;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DirectNewDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 258 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6367 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DirectNewDeclarator1 , ::Puma::CCSyntax::DirectNewDeclarator1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 258 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_new_declarator1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DirectNewDeclarator1 CCDirectNewDeclarator1Builder;

#line 224 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . direct_new_declarator1 ( ) ;
}   public:

#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_new_declarator1_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool direct_new_declarator1 ();
  
  struct NewInit {
#line 6401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14625;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NewInit::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 264 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6476 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NewInit , ::Puma::CCSyntax::NewInit ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 264 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_init (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NewInit CCNewInitBuilder;

#line 231 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_init ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_init_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool new_init ();

  struct DeleteExpr {
#line 6510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6551 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14638;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DeleteExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 270 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6585 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DeleteExpr , ::Puma::CCSyntax::DeleteExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 270 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.delete_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DeleteExpr CCDeleteExprBuilder;

#line 238 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . delete_expr ( ) ;
}   public:

#line 422 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _delete_expr_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool delete_expr ();

  struct PmExpr {
#line 6619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 275 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6625 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 275 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6660 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14651;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PmExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 276 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6694 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PmExpr , ::Puma::CCSyntax::PmExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 276 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.pm_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef PmExpr CCPmExprBuilder;

#line 245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . pm_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool pm_expr ();

  struct MulExpr {
#line 6723 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6729 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6764 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14661;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::MulExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6798 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::MulExpr , ::Puma::CCSyntax::MulExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.mul_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef MulExpr CCMulExprBuilder;

#line 252 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . mul_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool mul_expr ();

  struct RelExpr {
#line 6827 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 287 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6833 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 287 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6868 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14671;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::RelExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 6902 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::RelExpr , ::Puma::CCSyntax::RelExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.rel_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef RelExpr CCRelExprBuilder;

#line 259 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . rel_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool rel_expr ();

  struct CondExpr {
#line 6931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 6937 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6972 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14681;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::CondExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7006 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::CondExpr , ::Puma::CCSyntax::CondExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.cond_expr (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef CondExpr CCCondExprBuilder;

#line 266 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . cond_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool cond_expr ();

  struct AssExpr {
#line 7035 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 299 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7041 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 299 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7076 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14691;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::AssExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7110 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::AssExpr , ::Puma::CCSyntax::AssExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ass_expr (); }
    
#line 7125 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef AssExpr CCAssExprBuilder;

#line 273 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ass_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool ass_expr ();

  struct AssExpr1 {
#line 7144 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7150 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14701;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::AssExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7219 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::AssExpr1 , ::Puma::CCSyntax::AssExpr1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ass_expr1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef AssExpr1 CCAssExpr1Builder;

#line 280 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ass_expr1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool ass_expr1 ();

  struct ConstExpr {
#line 7248 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 311 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7254 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 311 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7289 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14711;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ConstExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7323 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ConstExpr , ::Puma::CCSyntax::ConstExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.const_expr (); }
    
#line 7338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef ConstExpr CCConstExprBuilder;

#line 287 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 7349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14716;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 7378 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 7380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ConstExpr , ::Puma::CCSyntax::ConstExpr ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a21_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 7392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . const_expr ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool const_expr ();

  // A.5 Statements
  struct Stmt {
#line 7403 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7409 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7444 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14721;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Stmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 319 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Stmt , ::Puma::CCSyntax::Stmt ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 319 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.stmt (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef Stmt CCStmtBuilder;

#line 294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . stmt ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  
#line 7505 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_stmt();

#line 322 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool stmt ();

  struct StmtSeq {
#line 7512 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 324 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7518 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 324 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7553 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14731;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::StmtSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7587 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::StmtSeq , ::Puma::CCSyntax::StmtSeq ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.stmt_seq (); }
    
#line 7602 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 326 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef StmtSeq CCStmtSeqBuilder;

#line 301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . stmt_seq ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool stmt_seq ();

  struct SubStmt {
#line 7621 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7627 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7662 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14741;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::SubStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7696 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::SubStmt , ::Puma::CCSyntax::SubStmt ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.sub_stmt (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef SubStmt CCSubStmtBuilder;

#line 308 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . sub_stmt ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool sub_stmt ();

  struct Condition {
#line 7725 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7731 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7766 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14751;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Condition::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7800 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Condition , ::Puma::CCSyntax::Condition ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef Condition CCConditionBuilder;

#line 315 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool condition ();

  struct Condition1 {
#line 7829 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7835 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7870 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14761;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Condition1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 7904 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Condition1 , ::Puma::CCSyntax::Condition1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition1 (); }
    
#line 7919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef Condition1 CCCondition1Builder;

#line 322 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 7930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14766;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 7959 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 7961 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::Condition1 , ::Puma::CCSyntax::Condition1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a23_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 7973 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . condition ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool condition1 ();

  struct Condition2 {
#line 7983 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 7989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8024 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14771;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Condition2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Condition2 , ::Puma::CCSyntax::Condition2 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition2 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef Condition2 CCCondition2Builder;

#line 329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool condition2 ();

  struct DeclStmt {
#line 8087 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 354 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8093 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 354 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14781;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DeclStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DeclStmt , ::Puma::CCSyntax::DeclStmt ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl_stmt (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DeclStmt CCDeclStmtBuilder;

#line 336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . decl_stmt ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool decl_stmt ();

  // A.6 Declarations
  
  struct Decl {
#line 8193 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8199 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14791;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::Decl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8268 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::Decl , ::Puma::CCSyntax::Decl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef Decl CCDeclBuilder;

#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . decl ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool decl ();
  // helper function, which is needed, because ac++ can't weave in templates :-(
  virtual bool decl_check ();

  struct BlockDecl {
#line 8299 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8340 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14801;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::BlockDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::BlockDecl , ::Puma::CCSyntax::BlockDecl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.block_decl (); }
    
#line 8389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 372 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef BlockDecl CCBlockDeclBuilder;

#line 350 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . block_decl ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool block_decl ();

  struct SimpleDecl {
#line 8408 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8414 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14811;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::SimpleDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8483 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::SimpleDecl , ::Puma::CCSyntax::SimpleDecl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.simple_decl (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef SimpleDecl CCSimpleDeclBuilder;

#line 357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 8504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14816;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 8533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 8535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::SimpleDecl , ::Puma::CCSyntax::SimpleDecl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
    result = ::Puma::CCSyntax::SimpleDecl::__exec_old_build(arg0);
  AC::invoke_CCSemBinding_CCSemBinding_a24_after<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 8548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_decl ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool simple_decl ();

  struct DeclSpecSeq1 {
#line 8558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8599 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14821;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DeclSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 383 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8633 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DeclSpecSeq1 , ::Puma::CCSyntax::DeclSpecSeq1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 383 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl_spec_seq1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DeclSpecSeq1 CCDeclSpecSeq1Builder;

#line 364 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 8654 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14826;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 8683 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 8685 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::DeclSpecSeq1 , ::Puma::CCSyntax::DeclSpecSeq1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a25_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 8697 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool decl_spec_seq1 ();

  struct MiscSpec {
#line 8707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 388 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8713 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 388 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8748 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14831;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::MiscSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::MiscSpec , ::Puma::CCSyntax::MiscSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.misc_spec (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef MiscSpec CCMiscSpecBuilder;

#line 371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . misc_spec ( ) ;
}   public:

#line 427 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _misc_spec_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool misc_spec ();

  struct StorageClassSpec {
#line 8816 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8822 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8857 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14844;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::StorageClassSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 8891 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::StorageClassSpec , ::Puma::CCSyntax::StorageClassSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.storage_class_spec (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef StorageClassSpec CCStorageClassSpecBuilder;

#line 378 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . storage_class_spec ( ) ;
}   public:

#line 432 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _storage_class_spec_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool storage_class_spec ();

  struct FctSpec {
#line 8925 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 8931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8966 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14857;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::FctSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::FctSpec , ::Puma::CCSyntax::FctSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.fct_spec (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef FctSpec CCFctSpecBuilder;

#line 385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . fct_spec ( ) ;
}   public:

#line 437 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _fct_spec_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool fct_spec ();

  struct SimpleTypeSpec {
#line 9034 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9040 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9075 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14870;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::SimpleTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9109 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::SimpleTypeSpec , ::Puma::CCSyntax::SimpleTypeSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.simple_type_spec (); }
    
#line 9124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 408 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef SimpleTypeSpec CCSimpleTypeSpecBuilder;

#line 392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 9135 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14875;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 9164 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 9166 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::SimpleTypeSpec , ::Puma::CCSyntax::SimpleTypeSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a27_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 9178 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_type_spec ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool simple_type_spec ();

  struct TypeName {
#line 9188 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9194 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14880;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::TypeName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 413 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::TypeName , ::Puma::CCSyntax::TypeName ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 413 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.type_name (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef TypeName CCTypeNameBuilder;

#line 399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . type_name ( ) ;
}   public:

#line 442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _type_name_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool type_name ();

  struct ElaboratedTypeSpec {
#line 9297 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9303 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14893;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ElaboratedTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9372 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ElaboratedTypeSpec , ::Puma::CCSyntax::ElaboratedTypeSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.elaborated_type_spec (); }
    
#line 9387 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 420 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef ElaboratedTypeSpec CCElaboratedTypeSpecBuilder;

#line 406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 9398 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14898;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 9427 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 9429 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ElaboratedTypeSpec , ::Puma::CCSyntax::ElaboratedTypeSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a29_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 9441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . elaborated_type_spec ( ) ;
}   public:

#line 447 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _elaborated_type_spec_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool elaborated_type_spec ();

  struct EnumeratorList {
#line 9456 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 424 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 424 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14906;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::EnumeratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 425 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::EnumeratorList , ::Puma::CCSyntax::EnumeratorList ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 425 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enumerator_list (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef EnumeratorList CCEnumeratorListBuilder;

#line 413 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . enumerator_list ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool enumerator_list ();

  struct EnumeratorDef {
#line 9560 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9566 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9601 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14916;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::EnumeratorDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9635 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::EnumeratorDef , ::Puma::CCSyntax::EnumeratorDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enumerator_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef EnumeratorDef CCEnumeratorDefBuilder;

#line 420 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 9656 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14921;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 9685 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 9687 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::EnumeratorDef , ::Puma::CCSyntax::EnumeratorDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a30_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 9699 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . enumerator_def ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool enumerator_def ();

  struct LinkageSpec {
#line 9709 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9715 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14926;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::LinkageSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 437 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9784 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::LinkageSpec , ::Puma::CCSyntax::LinkageSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 437 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.linkage_spec (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef LinkageSpec CCLinkageSpecBuilder;

#line 427 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . linkage_spec ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool linkage_spec ();

  // A.6.1 Namespaces
  struct NamespaceDef {
#line 9814 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9855 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14936;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NamespaceDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 444 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9889 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NamespaceDef , ::Puma::CCSyntax::NamespaceDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 444 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NamespaceDef CCNamespaceDefBuilder;

#line 434 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_def ( ) ;
}   public:

#line 452 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_def_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool namespace_def ();

  struct NamedNsDef {
#line 9923 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 9929 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14949;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NamedNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 450 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 9998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NamedNsDef , ::Puma::CCSyntax::NamedNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 450 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.named_ns_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NamedNsDef CCNamedNsDefBuilder;

#line 441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . named_ns_def ( ) ;
}   public:

#line 457 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _named_ns_def_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool named_ns_def ();

  struct OriginalNsDef {
#line 10032 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10038 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14962;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::OriginalNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 456 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::OriginalNsDef , ::Puma::CCSyntax::OriginalNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 456 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef OriginalNsDef CCOriginalNsDefBuilder;

#line 448 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14967;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10157 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10159 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::OriginalNsDef , ::Puma::CCSyntax::OriginalNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a33_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10171 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}   public:

#line 462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _original_ns_def_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool original_ns_def ();

  struct OriginalNsDef1 {
#line 10186 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10192 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14975;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::OriginalNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10261 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::OriginalNsDef1 , ::Puma::CCSyntax::OriginalNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_def1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef OriginalNsDef1 CCOriginalNsDef1Builder;

#line 455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14980;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10311 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::OriginalNsDef1 , ::Puma::CCSyntax::OriginalNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a35_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool original_ns_def1 ();

  struct ExtensionNsDef {
#line 10335 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 467 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10341 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 467 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14985;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ExtensionNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 468 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ExtensionNsDef , ::Puma::CCSyntax::ExtensionNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 468 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.extension_ns_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ExtensionNsDef CCExtensionNsDefBuilder;

#line 462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14990;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10460 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ExtensionNsDef , ::Puma::CCSyntax::ExtensionNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a33_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}   public:

#line 467 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _extension_ns_def_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool extension_ns_def ();

  struct ExtensionNsDef1 {
#line 10489 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 473 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 473 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10530 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14998;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ExtensionNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ExtensionNsDef1 , ::Puma::CCSyntax::ExtensionNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.extension_ns_def1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ExtensionNsDef1 CCExtensionNsDef1Builder;

#line 469 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10585 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15003;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10616 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ExtensionNsDef1 , ::Puma::CCSyntax::ExtensionNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a36_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10628 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool extension_ns_def1 ();

  struct UnnamedNsDef {
#line 10638 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10644 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10679 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15008;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UnnamedNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 480 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10713 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UnnamedNsDef , ::Puma::CCSyntax::UnnamedNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 480 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unnamed_ns_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef UnnamedNsDef CCUnnamedNsDefBuilder;

#line 476 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15013;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10763 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10765 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::UnnamedNsDef , ::Puma::CCSyntax::UnnamedNsDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a33_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10777 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}   public:

#line 472 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _unnamed_ns_def_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool unnamed_ns_def ();

  struct UnnamedNsDef1 {
#line 10792 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10798 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10833 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15021;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UnnamedNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 10867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UnnamedNsDef1 , ::Puma::CCSyntax::UnnamedNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unnamed_ns_def1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef UnnamedNsDef1 CCUnnamedNsDef1Builder;

#line 483 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 10888 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15026;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10917 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 10919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::UnnamedNsDef1 , ::Puma::CCSyntax::UnnamedNsDef1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a37_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 10931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool unnamed_ns_def1 ();

  struct NamespaceBody {
#line 10941 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 10947 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10982 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15031;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NamespaceBody::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11016 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NamespaceBody , ::Puma::CCSyntax::NamespaceBody ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_body (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NamespaceBody CCNamespaceBodyBuilder;

#line 490 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_body ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool namespace_body ();

  struct NsAliasDef {
#line 11045 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11051 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11086 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15041;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::NsAliasDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::NsAliasDef , ::Puma::CCSyntax::NsAliasDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ns_alias_def (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef NsAliasDef CCNsAliasDefBuilder;

#line 497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 11141 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15046;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11170 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 11172 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::NsAliasDef , ::Puma::CCSyntax::NsAliasDef ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a38_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 11184 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . ns_alias_def ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool ns_alias_def ();

  struct QualNsSpec {
#line 11194 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11200 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11235 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15051;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::QualNsSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::QualNsSpec , ::Puma::CCSyntax::QualNsSpec ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.qual_ns_spec (); }
    
#line 11284 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 505 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef QualNsSpec CCQualNsSpecBuilder;

#line 504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . qual_ns_spec ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool qual_ns_spec ();

  struct UsingDecl {
#line 11303 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11309 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15061;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UsingDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11378 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UsingDecl , ::Puma::CCSyntax::UsingDecl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.using_decl (); }
    
#line 11393 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 511 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef UsingDecl CCUsingDeclBuilder;

#line 511 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 11404 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15066;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11433 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 11435 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::UsingDecl , ::Puma::CCSyntax::UsingDecl ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a41_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 11447 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . using_decl ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool using_decl ();

  struct UsingDirective {
#line 11457 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 515 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11463 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 515 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15071;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::UsingDirective::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11532 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::UsingDirective , ::Puma::CCSyntax::UsingDirective ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.using_directive (); }
    
#line 11547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 517 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef UsingDirective CCUsingDirectiveBuilder;

#line 518 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 11558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15076;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11587 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 11589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::UsingDirective , ::Puma::CCSyntax::UsingDirective ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a43_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 11601 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . using_directive ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool using_directive ();

  // A.7 Declarators
  struct InitDeclarator {
#line 11612 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 522 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11618 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 522 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11653 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15081;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::InitDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 523 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11687 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::InitDeclarator , ::Puma::CCSyntax::InitDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 523 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.init_declarator (); }
    
#line 11702 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 524 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef InitDeclarator CCInitDeclaratorBuilder;

#line 525 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 11713 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15086;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11742 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 11744 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::InitDeclarator , ::Puma::CCSyntax::InitDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a45_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 11756 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . init_declarator ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool init_declarator ();

  struct DirectDeclarator1 {
#line 11766 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 528 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11772 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 528 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11807 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15091;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DirectDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 529 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11841 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DirectDeclarator1 , ::Puma::CCSyntax::DirectDeclarator1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 529 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_declarator1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DirectDeclarator1 CCDirectDeclarator1Builder;

#line 532 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . direct_declarator1 ( ) ;
}   public:

#line 477 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_declarator1_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool direct_declarator1 ();

  struct ArrayDelim {
#line 11875 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11881 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11916 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15104;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ArrayDelim::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 11950 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ArrayDelim , ::Puma::CCSyntax::ArrayDelim ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.array_delim (); }
    
#line 11965 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 536 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef ArrayDelim CCArrayDelimBuilder;

#line 539 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . array_delim ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool array_delim ();

  struct PtrOperator {
#line 11984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 11990 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12025 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15114;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::PtrOperator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 541 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12059 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::PtrOperator , ::Puma::CCSyntax::PtrOperator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 541 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ptr_operator (); }
    
#line 12074 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 542 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef PtrOperator CCPtrOperatorBuilder;

#line 546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ptr_operator ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool ptr_operator ();

  struct DeclaratorId {
#line 12093 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12099 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12134 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15124;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DeclaratorId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DeclaratorId , ::Puma::CCSyntax::DeclaratorId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.declarator_id (); }
    
#line 12183 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef DeclaratorId CCDeclaratorIdBuilder;

#line 553 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . declarator_id ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool declarator_id ();

  struct DirectAbstDeclarator {
#line 12202 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12243 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15134;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::DirectAbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 553 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::DirectAbstDeclarator , ::Puma::CCSyntax::DirectAbstDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 553 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_abst_declarator (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef DirectAbstDeclarator CCDirectAbstDeclaratorBuilder;

#line 560 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 12298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15139;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12327 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 12329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::DirectAbstDeclarator , ::Puma::CCSyntax::DirectAbstDeclarator ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a50_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 12341 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . direct_abst_declarator ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool direct_abst_declarator ();

  struct ParamDeclClause {
#line 12351 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15144;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ParamDeclClause::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 559 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12426 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ParamDeclClause , ::Puma::CCSyntax::ParamDeclClause ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 559 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.param_decl_clause (); }
    
#line 12441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 560 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef ParamDeclClause CCParamDeclClauseBuilder;

#line 567 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 12452 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15149;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12481 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 12483 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ParamDeclClause , ::Puma::CCSyntax::ParamDeclClause ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a52_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 12495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . param_decl_clause ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool param_decl_clause ();

  CTree * rule_param_decl ();
  virtual bool param_decl ();
  CTree * rule_param_init ();
  virtual bool param_init ();
  
#line 12509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_fct_def();

#line 568 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_fct_def ();
  virtual bool fct_def ();
  CTree * rule_skipped_fct_body ();
  virtual bool skipped_fct_body ();
  CTree * rule_fct_body ();
  virtual bool fct_body ();
  CTree * rule_init ();
  virtual bool init ();
  CTree * rule_init_clause ();
  virtual bool init_clause ();

  // A.8 Classes
  CTree *rule_class_spec ();
  virtual bool class_spec ();

  struct ClassHead {
#line 12529 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12570 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15154;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ClassHead::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 584 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12604 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ClassHead , ::Puma::CCSyntax::ClassHead ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 584 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_head (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ClassHead CCClassHeadBuilder;

#line 574 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 12625 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15159;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12654 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 12656 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ClassHead , ::Puma::CCSyntax::ClassHead ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a53_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 12668 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . class_head ( ) ;
}   public:

#line 482 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_head_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool class_head ();

  struct ClassHead1 {
#line 12683 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12689 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12724 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15167;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ClassHead1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12758 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ClassHead1 , ::Puma::CCSyntax::ClassHead1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_head1 (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ClassHead1 CCClassHead1Builder;

#line 581 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 12779 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15172;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12808 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 12810 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ClassHead1 , ::Puma::CCSyntax::ClassHead1 ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a55_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 12822 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . class_head1 ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool class_head1 ();

  
#line 12832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_decl();

#line 595 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_decl ();
  virtual bool member_decl ();
  
#line 12839 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_decl1();

#line 597 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_decl1 ();
  virtual bool member_decl1 ();
  CTree * rule_access_decl ();
  virtual bool access_decl ();
  
#line 12848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_declarator();

#line 601 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_declarator ();
  virtual bool member_declarator ();
  CTree * rule_pure_spec ();
  virtual bool pure_spec ();
  CTree * rule_const_init ();
  virtual bool const_init ();

  // A.9 Derived classes
  CTree * rule_base_clause ();
  virtual bool base_clause ();
  CTree * rule_base_spec_list ();
  virtual bool base_spec_list ();
  CTree * rule_base_spec ();
  virtual bool base_spec ();
  CTree * rule_access_spec ();
  virtual bool access_spec ();

  // A.10 Special member functions
  struct ConvFctId {
#line 12871 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12877 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12912 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15177;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ConvFctId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 620 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 12946 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ConvFctId , ::Puma::CCSyntax::ConvFctId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 620 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.conv_fct_id (); }
    
#line 12961 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax & );

#line 621 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
     private:
  typedef ConvFctId CCConvFctIdBuilder;

#line 588 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . conv_fct_id ( ) ;
}   public:

#line 487 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _conv_fct_id_1 ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool conv_fct_id ();

  struct ConvTypeId {
#line 12985 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 625 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 12991 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 625 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 13026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15190;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CCSyntax::ConvTypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 626 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax & arg0) 
#line 13060 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0< bool , ::Puma::CCSyntax::ConvTypeId , ::Puma::CCSyntax::ConvTypeId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax & s)
#line 626 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.conv_type_id (); }
    static inline bool parse (CCSyntax &);
     private:
  typedef ConvTypeId CCConvTypeIdBuilder;

#line 595 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCBuilderExtension.ah"
 public :

#line 13081 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15195;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 13110 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax &  arg0 ) 
#line 13112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0< ::Puma::CTree * , ::Puma::CCSyntax::ConvTypeId , ::Puma::CCSyntax::ConvTypeId ,  AC::TL< ::Puma::CCSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CCSemBinding_CCSemBinding_a59_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CCSyntax & s)
#line 13124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}   public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  virtual bool conv_type_id ();

  CTree * rule_conv_declarator ();
  virtual bool conv_declarator ();
  CTree * rule_ctor_init ();
  virtual bool ctor_init ();
  CTree * rule_mem_init_list ();
  virtual bool mem_init_list ();
  CTree * rule_mem_init ();
  virtual bool mem_init ();
  CTree * rule_mem_init_id ();
  virtual bool mem_init_id ();

  // A.11 Overloading
  CTree *rule_oper_fct_id ();
  virtual bool oper_fct_id ();

  // A.12 Templates
  CTree * rule_template_key (); 
  virtual bool template_key (); 
  
#line 13152 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_template_decl();

#line 649 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_template_decl (); 
  virtual bool template_decl (); 
  
#line 13159 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_template_decl();

#line 651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_template_decl (); 
  virtual bool member_template_decl (); 
  CTree * rule_template_param_list (); 
  virtual bool template_param_list (); 
  CTree * rule_template_param (); 
  virtual bool template_param (); 
  CTree * rule_type_param (); 
  virtual bool type_param (); 
  CTree * rule_non_type_param (); 
  virtual bool non_type_param (); 
  CTree *rule_template_id (); 
  virtual bool template_id ();
  CTree *rule_class_template_id (); 
  virtual bool class_template_id ();
  CTree * rule_template_arg_list (); 
  virtual bool template_arg_list (); 
  CTree * rule_template_arg (); 
  virtual bool template_arg (); 
  CTree * rule_template_type_arg (); 
  virtual bool template_type_arg (); 
  CTree * rule_template_non_type_arg (); 
  virtual bool template_non_type_arg (); 
  CTree * rule_template_template_arg (); 
  virtual bool template_template_arg (); 
  
#line 13188 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_explicit_instantiation();

#line 675 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_explicit_instantiation (); 
  virtual bool explicit_instantiation (); 
  CTree * rule_explicit_specialization (); 
  virtual bool explicit_specialization (); 

  // A.13 Exception handling
  CTree * rule_try_block ();
  virtual bool try_block ();
  CTree * rule_fct_try_block ();
  virtual bool fct_try_block ();
  CTree * rule_handler_seq ();
  virtual bool handler_seq ();
  CTree * rule_handler ();
  virtual bool handler ();
  CTree * rule_exception_decl ();
  virtual bool exception_decl ();
  CTree * rule_throw_expr ();
  virtual bool throw_expr ();
  CTree * rule_exception_spec ();
  virtual bool exception_spec ();
  CTree * rule_type_id_list (); 
  virtual bool type_id_list (); 

protected:
  void skip_param_init ();
  void skip_ctor_init ();
  void skip_fct_body ();
  void skip_fct_try_block ();
  void skip_const_expr ();
  void skip_const_init ();

protected:
  struct SearchScope {
#line 13225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 13231 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
 CStructure *scope, *last_scope; bool dep;    public:

#line 494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 static inline bool lookahead ( void * ) { return true ; }};
  void get_search_scope (SearchScope &);
  void set_search_scope (SearchScope &);
   public:

#line 31 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCLookAhead.ah"
 protected :


tokenset _class_name_1 ;
tokenset _enum_name_1 ;
tokenset _template_name_1 ;
tokenset _class_template_name_1 ;
tokenset _namespace_name_1 ;
tokenset _original_ns_name_1 ;
tokenset _namespace_alias_1 ;
tokenset _qual_id_1 ;
tokenset _unqual_id_1 ;
tokenset _colon_colon_1 ;
tokenset _nested_name_spec_1 ;
tokenset _nested_name_spec1_1 ;
tokenset _class_or_ns_name_1 ;
tokenset _construct_expr_1 ;
tokenset _type_trait_expr_1 ;
tokenset _new_expr_1 ;
tokenset _new_placement_1 ;
tokenset _direct_new_declarator_1 ;
tokenset _direct_new_declarator1_1 ;
tokenset _new_init_1 ;
tokenset _delete_expr_1 ;
tokenset _namespace_def_1 ;
tokenset _named_ns_def_1 ;
tokenset _original_ns_def_1 ;

tokenset _explicit_instantiation_1 ;
tokenset _explicit_specialization_1 ;
tokenset _access_spec_1 ;
tokenset _conv_fct_id_1 ;
tokenset _oper_fct_id_1 ;
tokenset _template_key_1 ;
tokenset _template_id_1 ;
tokenset _extension_ns_def_1 ;
tokenset _unnamed_ns_def_1 ;

virtual void init_class_name ( ) {
init_class_template_id ( ) ;
_class_name_1 = _template_id_1 ;
_class_name_1 . set ( TOK_ID ) ;
}

virtual void init_enum_name ( ) {
_enum_name_1 . set ( TOK_ID ) ;
}

virtual void init_template_name ( ) {
_template_name_1 . set ( TOK_ID ) ;
}

virtual void init_class_template_name ( ) {
_class_template_name_1 . set ( TOK_ID ) ;
}

virtual void init_namespace_name ( ) {
init_original_ns_name ( ) ;
init_namespace_alias ( ) ;
_namespace_name_1 = _original_ns_name_1 ;
_namespace_name_1 |= _namespace_alias_1 ;
}

virtual void init_original_ns_name ( ) {
_original_ns_name_1 . set ( TOK_ID ) ;
}

virtual void init_namespace_alias ( ) {
_namespace_alias_1 . set ( TOK_ID ) ;
}

virtual void init_literal ( ) {
CSyntax :: init_literal ( ) ;
_literal_1 . set ( TOK_BOOL_VAL ) ;
}

virtual void init_prim_expr ( ) {
CSyntax :: init_prim_expr ( ) ;
_prim_expr_1 . set ( TOK_THIS ) ;
}

virtual void init_id_expr ( ) {

init_qual_id ( ) ;
init_unqual_id ( ) ;
_id_expr_1 = _qual_id_1 ;
_id_expr_1 |= _unqual_id_1 ;
}

virtual void init_qual_id ( ) {
init_colon_colon ( ) ;
init_nested_name_spec ( ) ;
_qual_id_1 = _colon_colon_1 ;
_qual_id_1 |= _nested_name_spec_1 ;
}

virtual void init_unqual_id ( ) {
init_identifier ( ) ;
init_oper_fct_id ( ) ;
init_conv_fct_id ( ) ;
init_template_id ( ) ;
_unqual_id_1 = _identifier_1 ;
_unqual_id_1 |= _oper_fct_id_1 ;
_unqual_id_1 |= _conv_fct_id_1 ;
_unqual_id_1 |= _template_id_1 ;
_unqual_id_1 . set ( TOK_TILDE ) ;
}

virtual void init_colon_colon ( ) {
_colon_colon_1 . set ( TOK_COLON_COLON ) ;
}

virtual void init_nested_name_spec ( ) {
init_nested_name_spec1 ( ) ;
_nested_name_spec_1 = _nested_name_spec1_1 ;
}

virtual void init_nested_name_spec1 ( ) {
init_class_or_ns_name ( ) ,
init_template_key ( ) ;
_nested_name_spec1_1 = _class_or_ns_name_1 ;
_nested_name_spec1_1 |= _template_key_1 ;
}

virtual void init_class_or_ns_name ( ) {
init_class_name ( ) ;
init_namespace_name ( ) ;
_class_or_ns_name_1 = _class_name_1 ;
_class_or_ns_name_1 |= _namespace_name_1 ;
}

virtual void init_postfix_expr1 ( ) {
CSyntax :: init_postfix_expr1 ( ) ;
}


#line 13409 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15674;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13433 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_simple_type_spec ( ) 
#line 13435 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0< void, ::Puma::CCSyntax , ::Puma::CCSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_simple_type_spec();
  AC::invoke_ExtGnu_ExtGnu_a37_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_simple_type_spec()
#line 13445 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
init_prim_types ( ) ;
init_type_name ( ) ;
init_nested_name_spec ( ) ;
init_colon_colon ( ) ;
_simple_type_spec_1 = _prim_types ;
_simple_type_spec_1 |= _type_name_1 ;
_simple_type_spec_1 |= _nested_name_spec_1 ;
_simple_type_spec_1 |= _colon_colon_1 ;
}

virtual void init_construct_expr ( ) {
init_simple_type_spec ( ) ;
_construct_expr_1 = _simple_type_spec_1 ;
_construct_expr_1 . set ( TOK_TYPENAME ) ;
}

virtual void init_type_trait_expr ( ) {
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_ASSIGN ) ;
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_COPY ) ;
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_CTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_ASSIGN ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_COPY ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_CTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_DTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_VIRTUAL_DTOR ) ;
_type_trait_expr_1 . set ( TOK_IS_ABSTRACT ) ;
_type_trait_expr_1 . set ( TOK_IS_CLASS ) ;
_type_trait_expr_1 . set ( TOK_IS_EMPTY ) ;
_type_trait_expr_1 . set ( TOK_IS_ENUM ) ;
_type_trait_expr_1 . set ( TOK_IS_POD ) ;
_type_trait_expr_1 . set ( TOK_IS_POLYMORPHIC ) ;
_type_trait_expr_1 . set ( TOK_IS_UNION ) ;
_type_trait_expr_1 . set ( TOK_IS_BASE_OF ) ;
}

virtual void init_new_expr ( ) {
_new_expr_1 . set ( TOK_NEW ) ;
_new_expr_1 . set ( TOK_COLON_COLON ) ;
}

virtual void init_new_placement ( ) {
_new_placement_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_direct_new_declarator ( ) {
_direct_new_declarator_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_direct_new_declarator1 ( ) {
_direct_new_declarator1_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_new_init ( ) {
_new_init_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_delete_expr ( ) {
_delete_expr_1 . set ( TOK_DELETE ) ;
_delete_expr_1 . set ( TOK_COLON_COLON ) ;
}


#line 13509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14init_misc_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax14init_misc_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15701;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_misc_spec ( ) 
#line 13535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14init_misc_specEv_0< void, ::Puma::CCSyntax , ::Puma::CCSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_misc_spec();
  AC::invoke_WinDeclSpecs_WinDeclSpecs_a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_misc_spec()
#line 13545 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
CSyntax :: init_misc_spec ( ) ;
_misc_spec_1 . set ( TOK_FRIEND ) ;
}


#line 13552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15704;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13576 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_storage_class_spec ( ) 
#line 13578 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0< void, ::Puma::CCSyntax , ::Puma::CCSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_storage_class_spec();
  AC::invoke_ExtGnu_ExtGnu_a35_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_storage_class_spec()
#line 13588 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
CSyntax :: init_storage_class_spec ( ) ;
_storage_class_spec_1 . set ( TOK_MUTABLE ) ;
}

virtual void init_fct_spec ( ) {
CSyntax :: init_fct_spec ( ) ;
_fct_spec_1 . set ( TOK_VIRTUAL ) ;
_fct_spec_1 . set ( TOK_EXPLICIT ) ;
}

virtual void init_type_name ( ) {
init_class_name ( ) ;
init_enum_name ( ) ;
init_typedef_name ( ) ;
_type_name_1 = _class_name_1 ;
_type_name_1 |= _enum_name_1 ;
_type_name_1 |= _typedef_name_1 ;
}

virtual void init_elaborated_type_spec ( ) {
init_class_key ( ) ;
_elaborated_type_spec_1 = _class_key_1 ;
_elaborated_type_spec_1 . set ( TOK_ENUM ) ;
_elaborated_type_spec_1 . set ( TOK_TYPENAME ) ;
}

virtual void init_namespace_def ( ) {
init_named_ns_def ( ) ;
init_unnamed_ns_def ( ) ;
_namespace_def_1 = _named_ns_def_1 ;
_namespace_def_1 |= _unnamed_ns_def_1 ;
}

virtual void init_named_ns_def ( ) {
init_original_ns_def ( ) ;
init_extension_ns_def ( ) ;
_named_ns_def_1 = _original_ns_def_1 ;
_named_ns_def_1 |= _extension_ns_def_1 ;
}


virtual void init_original_ns_def ( ) {
_original_ns_def_1 . set ( TOK_NAMESPACE ) ;
}


virtual void init_extension_ns_def ( ) {
_extension_ns_def_1 . set ( TOK_NAMESPACE ) ;
}


virtual void init_unnamed_ns_def ( ) {
_unnamed_ns_def_1 . set ( TOK_NAMESPACE ) ;
}


#line 13646 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma8CCSyntax14init_class_keyEv_0 {
  typedef TJP__ZN4Puma8CCSyntax14init_class_keyEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 15731;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13670 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_class_key ( ) 
#line 13672 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14init_class_keyEv_0< void, ::Puma::CCSyntax , ::Puma::CCSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_class_key();
  AC::invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_class_key()
#line 13682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
CSyntax :: init_class_key ( ) ;
_class_key_1 . set ( TOK_CLASS ) ;
}

virtual void init_conv_fct_id ( ) {
_conv_fct_id_1 . set ( TOK_OPERATOR ) ;
}   private:
  typedef CCSyntax ExtACCSyntax;

#line 59 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtACSyntaxH.ah"
 protected :
CTree * rule_slice_ref ( ) ;
virtual bool slice_ref ( ) ;
CTree * rule_class_slice_decl ( ) ;
virtual bool class_slice_decl ( ) ;
CTree * rule_class_slice_name ( ) ;
virtual bool class_slice_name ( ) ;
CTree * rule_class_slice_base_clause ( ) ;
virtual bool class_slice_base_clause ( ) ;   private:
  typedef CCSyntax ExtCC1XSyntax;

#line 30 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtCC1XSyntaxH.ah"
 protected :
CTree * rule_static_assert_decl ( ) ;
virtual bool static_assert_decl ( ) ;   private:
  typedef CCSyntax WinMemberExplSpecSyntax;

#line 62 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/WinMemberExplSpec.ah"
 CTree * rule_member_explicit_specialization ( ) ;
virtual bool member_explicit_specialization ( ) ;};


} // namespace Puma

#endif /* __CCSyntax_h__ */

#line 13720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

#ifdef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CCSyntax_h__
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#include "Puma/ExtACBuilderCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#include "Puma/ExtACSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#include "Puma/ExtCC1XBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#include "Puma/ExtCC1XBuilderCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#include "Puma/ExtCC1XSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#include "Puma/ExtCC1XSemanticH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#include "Puma/ExtCC1XSemanticCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#undef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CCSyntax_h__
#endif // __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CCSyntax_h__
