#ifndef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSyntax_h__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 0x0004, EXECUTION = 0x0008, CONSTRUCTION = 0x0010, DESTRUCTION = 0x0020 };
  struct Action {
    void **_args; void *_result; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  struct AnyResultBuffer {};
  template <typename T> struct ResultBuffer : public AnyResultBuffer {
    struct { char _array[sizeof (T)]; } _data;
    ~ResultBuffer () { ((T&)_data).T::~T(); }
    operator T& () const { return (T&)_data; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__AttrTypes const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0 };
  };
  template<typename T> struct TypeInfo<T, 1> {
    enum { AVAILABLE = 1 };
    enum { ELEMENTS = T::__AttrTypes::ARGS };
    template<int I>
    struct Member : public AC::Arg<typename T::__AttrTypes,I> {};
    template<int I>
    static typename Member<I>::ReferredType* member (T* obj) {
      return (typename Member<I>::ReferredType*)obj->__attr (I);
    }
    static const char *member_name (T &obj, int i) {
      return obj.__attr_name (i);
    }
	 };
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
inline void * operator new (__SIZE_TYPE__, AC::AnyResultBuffer *p) { return p; }
inline void operator delete (void *, AC::AnyResultBuffer *) { } // for VC++
#endif // __cplusplus
#endif // __ac_h_
#endif // __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

#ifndef __ac_fwd_WinAsm__
#define __ac_fwd_WinAsm__
class WinAsm;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinAsm_WinAsm_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#endif

#ifndef __ac_fwd_WinDeclSpecs__
#define __ac_fwd_WinDeclSpecs__
class WinDeclSpecs;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs_a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#endif

#ifndef __ac_fwd_WinTypeKeywords__
#define __ac_fwd_WinTypeKeywords__
class WinTypeKeywords;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinTypeKeywords_WinTypeKeywords_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#endif

#ifndef __ac_fwd_ExtACSyntaxCoupling__
#define __ac_fwd_ExtACSyntaxCoupling__
class ExtACSyntaxCoupling;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a2_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#endif

#ifndef __ac_fwd_ExtGnu__
#define __ac_fwd_ExtGnu__
class ExtGnu;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a3_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a5_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a6_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a7_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a8_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a11_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a13_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a15_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a16_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a17_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a18_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a21_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a23_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a25_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a26_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a34_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a35_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a36_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a37_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a38_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a39_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a40_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a41_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a43_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a45_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a47_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a49_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a51_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a52_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a53_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a54_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a55_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a56_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a57_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a58_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a59_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a60_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a61_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu_a62_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#endif

#ifndef __ac_fwd_LookAhead__
#define __ac_fwd_LookAhead__
class LookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_LookAhead_LookAhead_a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#endif

#ifndef __ac_fwd_CLookAhead__
#define __ac_fwd_CLookAhead__
class CLookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CLookAhead_CLookAhead_a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#endif

#ifndef __ac_fwd_CSemBinding__
#define __ac_fwd_CSemBinding__
class CSemBinding;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a5_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a6_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a7_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a8_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a9_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a10_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a11_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a16_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a17_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a18_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a22_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a23_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a26_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding_a31_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#endif

#ifndef __ac_fwd_ExtCC1X__
#define __ac_fwd_ExtCC1X__
class ExtCC1X;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a2_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a3_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a5_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtCC1X_ExtCC1X_a6_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#endif

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CSyntax_h__
#define __CSyntax_h__

/** \file 
 *  Parser for the C programming language (C99). */

#include "Puma/Syntax.h"
#include "Puma/CBuilder.h"
#include "Puma/CSemantic.h"
#include "Puma/CTokens.h"

namespace Puma {



#line 438 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 496 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 518 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 529 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 551 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 562 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 573 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 584 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 595 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 606 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 617 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 628 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 639 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 650 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 661 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 672 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 683 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 694 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 705 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 716 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 727 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 738 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 749 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 771 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 793 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 804 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 815 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 826 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 837 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 859 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 870 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 881 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 892 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 903 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 914 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 925 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 947 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 969 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 980 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 991 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1002 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1013 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1024 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1035 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1057 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1068 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1079 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1090 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1101 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1123 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1134 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1178 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1189 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1200 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1233 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1244 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1255 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1266 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1299 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1310 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1321 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1332 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1354 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1365 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1387 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1398 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1409 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1420 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1453 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1464 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1475 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1519 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1530 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1541 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1563 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1574 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1585 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1607 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1618 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1629 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1640 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1662 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1684 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1695 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1706 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1717 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1728 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1739 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1761 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1772 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1783 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1794 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1805 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1816 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1827 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1849 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1860 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1871 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1882 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1893 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1904 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1915 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1937 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1948 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1959 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1970 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1981 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1992 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2003 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2014 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2025 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2036 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2047 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2069 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2080 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2091 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2102 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2113 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2135 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2146 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2157 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2201 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2212 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2223 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2267 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2278 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2289 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2311 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2322 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2333 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2366 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2388 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2421 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2432 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2454 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2465 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2476 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2487 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2520 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2542 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2553 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2575 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2586 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
class CSyntax : public Syntax {
#line 2597 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2604 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 33 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

public:
  CSyntax (CBuilder &, CSemantic &);
  
#line 2641 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_configure(::Puma::Config & );

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void configure (Config &);

  enum Grammar { GRAMMAR_C, GRAMMAR_CPLUSPLUS };
  virtual Grammar grammar () const { return GRAMMAR_C; }

private:
  CBuilder &builder () const { return (CBuilder&)Syntax::builder (); }
  CSemantic &semantic () const { return (CSemantic&)Syntax::semantic (); }

protected:
  // Faster check for primitive types
  tokenset _prim_types;
  
#line 2658 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_prim_types();
protected:

#line 48 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void init_prim_types ();
  bool is_prim_type () { return _prim_types[look_ahead ()]; }

  // Faster check for cv qualifiers
  tokenset _cv_quals;
  
#line 2669 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_cv_quals();
protected:

#line 53 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void init_cv_quals ();
  bool is_cv_qual () { return _cv_quals[look_ahead ()]; }

  // FIRST and FOLLOW sets
  tokenset _class_spec_1;

  // FIRST and FOLLOW initialization
  virtual void init_class_spec ();

  // result cache!
  Token *last_look_ahead_token;
  bool last_look_ahead_result;

  // Grammar rules

public:
  // A.1 Keywords

  struct TypedefName {
#line 2693 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 71 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2699 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 71 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12681;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypedefName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 72 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 2768 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypedefName , ::Puma::CSyntax::TypedefName ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 72 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.typedef_name (); }
    static inline bool parse (CSyntax &);
     private:
  typedef TypedefName CTypedefNameBuilder;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 2789 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12686;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 2818 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 2820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::TypedefName , ::Puma::CSyntax::TypedefName ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a1_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 2832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . semantic ( ) . typedef_name ( ) ;
}   public:

#line 250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _typedef_name_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool typedef_name ();

  struct PrivateName {
#line 2847 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 2853 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2888 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12694;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::PrivateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 78 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 2922 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::PrivateName , ::Puma::CSyntax::PrivateName ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 78 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.private_name (); }
    static inline bool parse (CSyntax &);
     private:
  typedef PrivateName CPrivateNameBuilder;

#line 29 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 2943 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12699;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 2972 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 2974 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::PrivateName , ::Puma::CSyntax::PrivateName ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a0_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 2986 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . semantic ( ) . PrivateName ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool private_name ();

  // A.2 Lexical conventions

  struct Identifier {
#line 2998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 85 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3004 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 85 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3039 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12704;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Identifier::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 86 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Identifier , ::Puma::CSyntax::Identifier ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 86 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.identifier (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Identifier CIdentifierBuilder;

#line 43 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 255 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _identifier_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool identifier ();
  
  struct Literal {
#line 3107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 91 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3113 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 91 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12717;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Literal::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 92 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Literal , ::Puma::CSyntax::Literal ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 92 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.literal (); }
    static bool parse (CSyntax &);
     private:
  typedef Literal CLiteralBuilder;

#line 50 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . literal ( ) ;
}   public:

#line 260 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _literal_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool literal ();
  
  struct CmpdStr {
#line 3216 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 97 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 97 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12730;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CmpdStr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 98 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3291 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CmpdStr , ::Puma::CSyntax::CmpdStr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 98 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_str (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CmpdStr CCmpdStrBuilder;

#line 64 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cmpd_str ( ) ;
}   public:

#line 265 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cmpd_str_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cmpd_str ();
  
  struct StrLiteral {
#line 3325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 103 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 103 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3366 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12743;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::StrLiteral::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::StrLiteral , ::Puma::CSyntax::StrLiteral ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.str_literal (); }
    static inline bool parse (CSyntax &);
     private:
  typedef StrLiteral CStrLiteralBuilder;

#line 57 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . str_literal ( ) ;
}   public:

#line 270 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _str_literal_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool str_literal ();
  
  // A.3 Basic concepts 

  struct TransUnit {
#line 3436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 111 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 111 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3477 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12756;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TransUnit::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3511 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TransUnit , ::Puma::CSyntax::TransUnit ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.trans_unit (); }
    static inline bool parse (CSyntax &);
     private:
  typedef TransUnit CTransUnitBuilder;

#line 71 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 3532 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12761;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 3561 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 3563 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::TransUnit , ::Puma::CSyntax::TransUnit ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a2_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 3575 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . trans_unit ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool trans_unit ();

  // A.4 Expression
  struct PrimExpr {
#line 3586 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3592 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3627 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12766;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::PrimExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 119 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3661 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::PrimExpr , ::Puma::CSyntax::PrimExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 119 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.prim_expr (); }
    
#line 3676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
     private:
  typedef PrimExpr CPrimExprBuilder;

#line 78 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . prim_expr ( ) ;
}   public:

#line 275 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _prim_expr_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool prim_expr ();

  struct IdExpr {
#line 3700 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3706 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3741 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12779;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::IdExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 125 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3775 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::IdExpr , ::Puma::CSyntax::IdExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 125 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.id_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef IdExpr CIdExprBuilder;

#line 85 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 3796 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12784;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 3825 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 3827 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::IdExpr , ::Puma::CSyntax::IdExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a3_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 3839 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}   public:

#line 280 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _id_expr_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool id_expr ();

  struct CmpdLiteral {
#line 3854 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3860 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3895 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12792;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CmpdLiteral::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 131 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 3929 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CmpdLiteral , ::Puma::CSyntax::CmpdLiteral ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 131 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_literal (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CmpdLiteral CCmpdLiteralBuilder;

#line 92 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cmpd_literal ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cmpd_literal ();

  struct PostfixExpr {
#line 3958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 136 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 3964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 136 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3999 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12802;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::PostfixExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4033 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::PostfixExpr , ::Puma::CSyntax::PostfixExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.postfix_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef PostfixExpr CPostfixExprBuilder;

#line 99 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . postfix_expr ( ) ;
}   public:

#line 285 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool postfix_expr ();

  struct PostfixExpr1 {
#line 4067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 142 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 142 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12815;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::PostfixExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4142 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::PostfixExpr1 , ::Puma::CSyntax::PostfixExpr1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.postfix_expr1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef PostfixExpr1 CPostfixExpr1Builder;

#line 106 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . postfix_expr1 ( ) ;
}   public:

#line 290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr1_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool postfix_expr1 ();

  struct ExprList {
#line 4176 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12828;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ExprList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 149 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4251 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ExprList , ::Puma::CSyntax::ExprList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 149 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr_list (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ExprList CExprListBuilder;

#line 113 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr_list ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool expr_list ();

  struct UnaryExpr {
#line 4280 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4286 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4321 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12838;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::UnaryExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::UnaryExpr , ::Puma::CSyntax::UnaryExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.unary_expr (); }
    
#line 4370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef UnaryExpr CUnaryExprBuilder;

#line 120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . unary_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool unary_expr ();

  struct UnaryExpr1 {
#line 4389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12848;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::UnaryExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4464 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::UnaryExpr1 , ::Puma::CSyntax::UnaryExpr1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.unary_expr1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef UnaryExpr1 CUnaryExpr1Builder;

#line 127 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . unary_expr1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool unary_expr1 ();

  struct CastExpr {
#line 4493 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 166 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4499 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 166 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12858;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CastExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4568 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CastExpr , ::Puma::CSyntax::CastExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CastExpr CCastExprBuilder;

#line 134 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cast_expr ();

  struct CastExpr1 {
#line 4597 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 172 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4603 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 172 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4638 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12868;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CastExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4672 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CastExpr1 , ::Puma::CSyntax::CastExpr1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CastExpr1 CCastExpr1Builder;

#line 141 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr1 ( ) ;
}   public:

#line 295 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cast_expr1_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cast_expr1 ();

  struct CastExpr2 {
#line 4706 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 178 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4712 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 178 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4747 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12881;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CastExpr2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4781 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CastExpr2 , ::Puma::CSyntax::CastExpr2 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr2 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CastExpr2 CCastExpr2Builder;

#line 148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr2 ( ) ;
}   public:

#line 300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cast_expr2_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cast_expr2 ();

  struct OffsetofExpr {
#line 4815 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 184 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4821 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 184 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4856 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12894;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::OffsetofExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4890 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::OffsetofExpr , ::Puma::CSyntax::OffsetofExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.offsetof_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef OffsetofExpr COffsetofExprBuilder;

#line 155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . offsetof_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool offsetof_expr ();

  struct MembDesignator {
#line 4919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 4925 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4960 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12904;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::MembDesignator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 4994 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::MembDesignator , ::Puma::CSyntax::MembDesignator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.memb_designator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef MembDesignator CMembDesignatorBuilder;

#line 162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . memb_designator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool memb_designator ();

  struct MulExpr {
#line 5023 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5029 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5064 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12914;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::MulExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::MulExpr , ::Puma::CSyntax::MulExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.mul_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef MulExpr CMulExprBuilder;

#line 169 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . mul_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool mul_expr ();

  struct AddExpr {
#line 5127 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 202 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5133 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 202 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5168 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12924;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AddExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5202 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AddExpr , ::Puma::CSyntax::AddExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.add_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AddExpr CAddExprBuilder;

#line 176 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . add_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool add_expr ();

  struct ShiftExpr {
#line 5231 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5237 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5272 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12934;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ShiftExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 209 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ShiftExpr , ::Puma::CSyntax::ShiftExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 209 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.shift_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ShiftExpr CShiftExprBuilder;

#line 183 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . shift_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool shift_expr ();

  struct RelExpr {
#line 5335 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 214 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5341 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 214 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12944;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::RelExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 215 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::RelExpr , ::Puma::CSyntax::RelExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 215 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.rel_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef RelExpr CRelExprBuilder;

#line 190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . rel_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool rel_expr ();

  struct EquExpr {
#line 5439 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 220 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5445 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 220 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5480 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12954;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EquExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5514 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EquExpr , ::Puma::CSyntax::EquExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.equ_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef EquExpr CEquExprBuilder;

#line 197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . equ_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool equ_expr ();

  struct AndExpr {
#line 5543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 226 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5549 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 226 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5584 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12964;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AndExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5618 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AndExpr , ::Puma::CSyntax::AndExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.and_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AndExpr CAndExprBuilder;

#line 204 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . and_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool and_expr ();

  struct ExclOrExpr {
#line 5647 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 232 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5653 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 232 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5688 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12974;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ExclOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 233 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5722 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ExclOrExpr , ::Puma::CSyntax::ExclOrExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 233 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.excl_or_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ExclOrExpr CExclOrExprBuilder;

#line 211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . excl_or_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool excl_or_expr ();

  struct InclOrExpr {
#line 5751 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 238 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5757 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 238 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5792 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12984;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::InclOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5826 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::InclOrExpr , ::Puma::CSyntax::InclOrExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.incl_or_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef InclOrExpr CInclOrExprBuilder;

#line 218 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . incl_or_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool incl_or_expr ();

  struct LogAndExpr {
#line 5855 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 244 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5861 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 244 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5896 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 12994;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::LogAndExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 5930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::LogAndExpr , ::Puma::CSyntax::LogAndExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 245 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.log_and_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef LogAndExpr CLogAndExprBuilder;

#line 225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . log_and_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool log_and_expr ();

  struct LogOrExpr {
#line 5959 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 5965 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13004;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::LogOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 251 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6034 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::LogOrExpr , ::Puma::CSyntax::LogOrExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 251 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.log_or_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef LogOrExpr CLogOrExprBuilder;

#line 232 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . log_or_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool log_or_expr ();

  struct CondExpr {
#line 6063 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6069 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13014;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CondExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6138 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CondExpr , ::Puma::CSyntax::CondExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cond_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CondExpr CCondExprBuilder;

#line 239 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cond_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cond_expr ();

  struct AssExpr {
#line 6167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 262 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 262 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13024;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AssExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AssExpr , ::Puma::CSyntax::AssExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 263 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ass_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AssExpr CAssExprBuilder;

#line 246 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ass_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool ass_expr ();

  struct AssExpr1 {
#line 6271 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 268 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 268 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13034;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AssExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6346 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AssExpr1 , ::Puma::CSyntax::AssExpr1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ass_expr1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AssExpr1 CAssExpr1Builder;

#line 253 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ass_expr1 ( ) ;
}   public:

#line 305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> is_ass_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool ass_expr1 ();

  struct Expr {
#line 6380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 274 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6386 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 274 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6421 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13047;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Expr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 275 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Expr , ::Puma::CSyntax::Expr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 275 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Expr CExprBuilder;

#line 260 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool expr ();

  struct ConstExpr {
#line 6484 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 280 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6490 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 280 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6525 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13057;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ConstExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6559 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ConstExpr , ::Puma::CSyntax::ConstExpr ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.const_expr (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ConstExpr CConstExprBuilder;

#line 267 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . const_expr ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool const_expr ();

  // A.5 Statements

  struct Stmt {
#line 6590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6631 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13067;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Stmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 289 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6665 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Stmt , ::Puma::CSyntax::Stmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 289 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Stmt CStmtBuilder;

#line 274 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . stmt ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  
#line 6692 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_stmt();

#line 292 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual bool stmt ();

  struct LabelStmt {
#line 6699 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6705 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 294 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6740 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13077;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::LabelStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 295 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::LabelStmt , ::Puma::CSyntax::LabelStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 295 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.label_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef LabelStmt CLabelStmtBuilder;

#line 281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 6795 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13082;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 6824 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 6826 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::LabelStmt , ::Puma::CSyntax::LabelStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
    result = ::Puma::CSyntax::LabelStmt::__exec_old_build(arg0);
  AC::invoke_CSemBinding_CSemBinding_a4_after<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 6839 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . label_stmt ( ) ;
}   public:

#line 310 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _label_stmt_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool label_stmt ();

  struct ExprStmt {
#line 6854 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6860 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 300 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6895 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13090;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ExprStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 6929 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ExprStmt , ::Puma::CSyntax::ExprStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ExprStmt CExprStmtBuilder;

#line 288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr_stmt ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool expr_stmt ();

  struct CmpdStmt {
#line 6958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 6964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6999 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13100;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CmpdStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 307 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7033 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CmpdStmt , ::Puma::CSyntax::CmpdStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 307 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CmpdStmt CCmpdStmtBuilder;

#line 295 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 7054 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13105;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 7083 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 7085 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::CmpdStmt , ::Puma::CSyntax::CmpdStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a5_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 7097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . cmpd_stmt ( ) ;
}   public:

#line 315 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cmpd_stmt_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cmpd_stmt ();

  struct StmtSeq {
#line 7112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7153 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13113;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::StmtSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7187 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::StmtSeq , ::Puma::CSyntax::StmtSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.stmt_seq (); }
    
#line 7202 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 314 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef StmtSeq CStmtSeqBuilder;

#line 302 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . stmt_seq ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool stmt_seq ();

  struct SelectStmt {
#line 7221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7227 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7262 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13123;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::SelectStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 319 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7296 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::SelectStmt , ::Puma::CSyntax::SelectStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 319 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.select_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef SelectStmt CSelectStmtBuilder;

#line 309 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 7317 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13128;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 7346 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 7348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::SelectStmt , ::Puma::CSyntax::SelectStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a6_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 7360 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . select_stmt ( ) ;
}   public:

#line 320 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _select_stmt_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool select_stmt ();

  struct SubStmt {
#line 7375 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 324 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7381 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 324 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7416 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13136;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::SubStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7450 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::SubStmt , ::Puma::CSyntax::SubStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.sub_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef SubStmt CSubStmtBuilder;

#line 316 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . sub_stmt ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool sub_stmt ();

  struct Condition {
#line 7479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7520 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13146;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Condition::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7554 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Condition , ::Puma::CSyntax::Condition ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.condition (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Condition CConditionBuilder;

#line 323 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool condition ();

  struct IterStmt {
#line 7583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 336 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7624 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13156;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::IterStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7658 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::IterStmt , ::Puma::CSyntax::IterStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.iter_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef IterStmt CIterStmtBuilder;

#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 7679 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13161;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 7708 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 7710 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::IterStmt , ::Puma::CSyntax::IterStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a7_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 7722 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . iter_stmt ( ) ;
}   public:

#line 325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _iter_stmt_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool iter_stmt ();
  
  struct ForInitStmt {
#line 7737 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7743 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13169;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ForInitStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7812 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ForInitStmt , ::Puma::CSyntax::ForInitStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.for_init_stmt (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ForInitStmt CForInitStmtBuilder;

#line 337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . for_init_stmt ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool for_init_stmt ();
  
  struct JumpStmt {
#line 7841 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7847 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7882 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13179;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::JumpStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 7916 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::JumpStmt , ::Puma::CSyntax::JumpStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.jump_stmt (); }
    
#line 7931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 350 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef JumpStmt CJumpStmtBuilder;

#line 344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . jump_stmt ( ) ;
}   public:

#line 330 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _jump_stmt_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool jump_stmt ();
      
  // A.6 Declarations

  struct DeclSeq {
#line 7957 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 356 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 7963 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 356 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13192;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DeclSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8032 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DeclSeq , ::Puma::CSyntax::DeclSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_seq (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DeclSeq CDeclSeqBuilder;

#line 351 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl_seq ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool decl_seq ();

  struct Decl {
#line 8061 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 362 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8102 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13202;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Decl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8136 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Decl , ::Puma::CSyntax::Decl ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Decl CDeclBuilder;

#line 358 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool decl ();
  // helper function, which is needed, because ac++ can't weave in templates :-(
  virtual bool decl_check ();

  struct BlockDecl {
#line 8167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13212;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::BlockDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::BlockDecl , ::Puma::CSyntax::BlockDecl ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.block_decl (); }
    
#line 8257 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 372 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef BlockDecl CBlockDeclBuilder;

#line 365 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . block_decl ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool block_decl ();

  struct SimpleDecl {
#line 8276 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8317 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13222;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::SimpleDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8351 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::SimpleDecl , ::Puma::CSyntax::SimpleDecl ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.simple_decl (); }
    static bool parse (CSyntax &);
     private:
  typedef SimpleDecl CSimpleDeclBuilder;

#line 372 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_decl ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool simple_decl ();

  struct DeclSpec {
#line 8380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8386 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 382 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8421 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13232;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DeclSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 383 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DeclSpec , ::Puma::CSyntax::DeclSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 383 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DeclSpec CDeclSpecBuilder;

#line 379 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl_spec ( ) ;
}   public:

#line 335 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _decl_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool decl_spec ();

  struct DeclSpecSeq {
#line 8489 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 388 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 388 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8530 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13245;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DeclSpecSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DeclSpecSeq , ::Puma::CSyntax::DeclSpecSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec_seq (); }
    
#line 8579 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 390 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
     private:
  typedef DeclSpecSeq CDeclSpecSeqBuilder;

#line 386 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 8590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13250;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 8619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 8621 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::DeclSpecSeq , ::Puma::CSyntax::DeclSpecSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a8_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 8633 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return 0 ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool decl_spec_seq ();

  struct DeclSpecSeq1 {
#line 8643 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8649 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8684 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13255;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DeclSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8718 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DeclSpecSeq1 , ::Puma::CSyntax::DeclSpecSeq1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec_seq1 (); }
    static bool parse (CSyntax &);
     private:
  typedef DeclSpecSeq1 CDeclSpecSeq1Builder;

#line 393 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 8739 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13260;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 8768 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 8770 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::DeclSpecSeq1 , ::Puma::CSyntax::DeclSpecSeq1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a10_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 8782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool decl_spec_seq1 ();

  struct MiscSpec {
#line 8792 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8798 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8833 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13265;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::MiscSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::MiscSpec , ::Puma::CSyntax::MiscSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.misc_spec (); }
    static bool parse (CSyntax &);
     private:
  typedef MiscSpec CMiscSpecBuilder;

#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . misc_spec ( ) ;
}   public:

#line 340 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _misc_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool misc_spec ();

  struct StorageClassSpec {
#line 8901 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 8907 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8942 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13278;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::StorageClassSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 8976 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::StorageClassSpec , ::Puma::CSyntax::StorageClassSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.storage_class_spec (); }
    
#line 8991 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 408 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
     private:
  typedef StorageClassSpec CStorageClassSpecBuilder;

#line 407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . storage_class_spec ( ) ;
}   public:

#line 345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _storage_class_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool storage_class_spec ();

  struct FctSpec {
#line 9015 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9021 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9056 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13291;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::FctSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 413 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9090 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::FctSpec , ::Puma::CSyntax::FctSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 413 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.fct_spec (); }
    static bool parse (CSyntax &);
     private:
  typedef FctSpec CFctSpecBuilder;

#line 414 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . fct_spec ( ) ;
}   public:

#line 350 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _fct_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool fct_spec ();

  struct TypeSpec {
#line 9124 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9165 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13304;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9199 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypeSpec , ::Puma::CSyntax::TypeSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec (); }
    static inline bool parse (CSyntax &);
     private:
  typedef TypeSpec CTypeSpecBuilder;

#line 421 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . type_spec ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool type_spec ();

  struct SimpleTypeSpec {
#line 9228 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 424 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9234 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 424 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9269 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13314;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::SimpleTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 425 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9303 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::SimpleTypeSpec , ::Puma::CSyntax::SimpleTypeSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 425 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.simple_type_spec (); }
    
#line 9318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 426 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef SimpleTypeSpec CSimpleTypeSpecBuilder;

#line 428 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_type_spec ( ) ;
}   public:

#line 355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _simple_type_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool simple_type_spec ();

  struct TypeName {
#line 9342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9383 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13327;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypeName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypeName , ::Puma::CSyntax::TypeName ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 431 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_name (); }
    static inline bool parse (CSyntax &);
     private:
  typedef TypeName CTypeNameBuilder;

#line 435 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . type_name ( ) ;
}   public:

#line 360 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _type_name_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool type_name ();

  struct ElaboratedTypeSpec {
#line 9451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9457 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13340;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ElaboratedTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 437 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9526 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ElaboratedTypeSpec , ::Puma::CSyntax::ElaboratedTypeSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 437 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.elaborated_type_spec (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ElaboratedTypeSpec CElaboratedTypeSpecBuilder;

#line 442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 9547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13345;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 9576 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 9578 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::ElaboratedTypeSpec , ::Puma::CSyntax::ElaboratedTypeSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a11_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 9590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . elaborated_type_spec ( ) ;
}   public:

#line 365 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _elaborated_type_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool elaborated_type_spec ();

  struct EnumKey {
#line 9605 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9611 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9646 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13353;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EnumKey::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9680 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EnumKey , ::Puma::CSyntax::EnumKey ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_key (); }
    static inline bool parse (CSyntax &);
     private:
  typedef EnumKey CEnumKeyBuilder;

#line 449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enum_key ( ) ;
}   public:

#line 370 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_key_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enum_key ();

  struct EnumSpec {
#line 9714 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 448 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 448 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9755 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13366;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EnumSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9789 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EnumSpec , ::Puma::CSyntax::EnumSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 449 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_spec (); }
    static inline bool parse (CSyntax &);
     private:
  typedef EnumSpec CEnumSpecBuilder;

#line 456 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enum_spec ( ) ;
}   public:

#line 375 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_spec_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enum_spec ();

  struct EnumSpec1 {
#line 9823 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 454 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9829 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 454 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9864 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13379;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EnumSpec1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 9898 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EnumSpec1 , ::Puma::CSyntax::EnumSpec1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 455 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_spec1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef EnumSpec1 CEnumSpec1Builder;

#line 463 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 9919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13384;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 9948 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 9950 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::EnumSpec1 , ::Puma::CSyntax::EnumSpec1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a12_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 9962 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enum_spec1 ( ) ;
}   public:

#line 380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_spec1_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enum_spec1 ();

  struct EnumeratorList {
#line 9977 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 460 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 9983 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 460 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10018 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13392;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EnumeratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10052 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EnumeratorList , ::Puma::CSyntax::EnumeratorList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator_list (); }
    static inline bool parse (CSyntax &);
     private:
  typedef EnumeratorList CEnumeratorListBuilder;

#line 470 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enumerator_list ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enumerator_list ();

  struct EnumeratorDef {
#line 10081 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 466 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10087 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 466 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10122 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13402;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::EnumeratorDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 467 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::EnumeratorDef , ::Puma::CSyntax::EnumeratorDef ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 467 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator_def (); }
    static bool parse (CSyntax &);
     private:
  typedef EnumeratorDef CEnumeratorDefBuilder;

#line 477 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 10177 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13407;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10206 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 10208 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::EnumeratorDef , ::Puma::CSyntax::EnumeratorDef ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a13_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 10220 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enumerator_def ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enumerator_def ();

  struct Enumerator {
#line 10230 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 472 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10236 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 472 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10271 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13412;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Enumerator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 473 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Enumerator , ::Puma::CSyntax::Enumerator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 473 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Enumerator CEnumeratorBuilder;

#line 484 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 10326 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13417;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 10357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::Enumerator , ::Puma::CSyntax::Enumerator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a14_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 10369 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enumerator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool enumerator ();

  struct AsmDef {
#line 10379 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10420 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13422;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AsmDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10454 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AsmDef , ::Puma::CSyntax::AsmDef ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.asm_def (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AsmDef CAsmDefBuilder;

#line 491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . asm_def ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  
#line 10481 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_asm_def();

#line 482 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual bool asm_def ();

  // A.7 Declarators
  struct InitDeclaratorList {
#line 10489 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 485 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10530 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13432;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::InitDeclaratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::InitDeclaratorList , ::Puma::CSyntax::InitDeclaratorList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator_list (); }
    static inline bool parse (CSyntax &);
     private:
  typedef InitDeclaratorList CInitDeclaratorListBuilder;

#line 498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . init_declarator_list ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool init_declarator_list ();

  struct InitDeclarator {
#line 10593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10599 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10634 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13442;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::InitDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10668 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::InitDeclarator , ::Puma::CSyntax::InitDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator (); }
    static bool parse (CSyntax &);
     private:
  typedef InitDeclarator CInitDeclaratorBuilder;

#line 505 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 10689 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13447;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10718 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 10720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::InitDeclarator , ::Puma::CSyntax::InitDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a15_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 10732 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . init_declarator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool init_declarator ();

  struct InitDeclarator1 {
#line 10742 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10748 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10783 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13452;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::InitDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10817 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::InitDeclarator1 , ::Puma::CSyntax::InitDeclarator1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 498 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator1 (); }
    
#line 10832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 499 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef InitDeclarator1 CInitDeclarator1Builder;

#line 512 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 10843 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13457;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 10872 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 10874 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::InitDeclarator1 , ::Puma::CSyntax::InitDeclarator1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a17_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 10886 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . init_declarator1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool init_declarator1 ();

  struct Declarator {
#line 10896 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 10902 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10937 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13462;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::Declarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 10971 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::Declarator , ::Puma::CSyntax::Declarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 504 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.declarator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef Declarator CDeclaratorBuilder;

#line 519 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . declarator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool declarator ();

  struct DirectDeclarator {
#line 11000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11006 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 509 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11041 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13472;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DirectDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11075 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DirectDeclarator , ::Puma::CSyntax::DirectDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_declarator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DirectDeclarator CDirectDeclaratorBuilder;

#line 526 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_declarator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool direct_declarator ();

  struct DirectDeclarator1 {
#line 11104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 515 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11110 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 515 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13482;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DirectDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11179 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DirectDeclarator1 , ::Puma::CSyntax::DirectDeclarator1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_declarator1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DirectDeclarator1 CDirectDeclarator1Builder;

#line 533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_declarator1 ( ) ;
}   public:

#line 385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _direct_declarator1_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool direct_declarator1 ();

  struct IdentifierList {
#line 11213 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 521 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11219 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 521 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11254 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13495;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::IdentifierList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 522 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11288 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::IdentifierList , ::Puma::CSyntax::IdentifierList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 522 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.identifier_list (); }
    
#line 11303 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 523 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef IdentifierList CIdentifierListBuilder;

#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 11314 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13500;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 11345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::IdentifierList , ::Puma::CSyntax::IdentifierList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a19_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 11357 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . identifier_list ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool identifier_list ();

  struct ArrayDelim {
#line 11367 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 527 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11373 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 527 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11408 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13505;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ArrayDelim::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 528 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11442 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ArrayDelim , ::Puma::CSyntax::ArrayDelim ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 528 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.array_delim (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ArrayDelim CArrayDelimBuilder;

#line 547 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 11463 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13510;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 11492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 11494 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::ArrayDelim , ::Puma::CSyntax::ArrayDelim ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a21_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 11506 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . array_delim ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool array_delim ();

  struct PtrOperator {
#line 11516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11522 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11557 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13515;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::PtrOperator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11591 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::PtrOperator , ::Puma::CSyntax::PtrOperator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ptr_operator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef PtrOperator CPtrOperatorBuilder;

#line 554 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ptr_operator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool ptr_operator ();

  struct CvQualSeq {
#line 11620 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 539 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11626 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 539 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11661 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13525;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CvQualSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11695 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CvQualSeq , ::Puma::CSyntax::CvQualSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cv_qual_seq (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CvQualSeq CCvQualSeqBuilder;

#line 561 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cv_qual_seq ( ) ;
}   public:

#line 390 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cv_qual_seq_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cv_qual_seq ();

  struct CvQual {
#line 11729 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 545 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11735 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 545 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11770 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13538;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::CvQual::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11804 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::CvQual , ::Puma::CSyntax::CvQual ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cv_qual (); }
    static inline bool parse (CSyntax &);
     private:
  typedef CvQual CCvQualBuilder;

#line 568 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cv_qual ( ) ;
}   public:

#line 395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cv_qual_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool cv_qual ();

  struct DeclaratorId {
#line 11838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 551 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11844 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 551 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11879 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13551;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DeclaratorId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 11913 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DeclaratorId , ::Puma::CSyntax::DeclaratorId ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 552 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.declarator_id (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DeclaratorId CDeclaratorIdBuilder;

#line 575 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . declarator_id ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool declarator_id ();

  struct TypeId {
#line 11942 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 557 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 11948 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 557 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11983 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13561;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12017 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypeId , ::Puma::CSyntax::TypeId ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 558 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_id (); }
    
#line 12032 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 559 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef TypeId CTypeIdBuilder;

#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12043 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13566;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12072 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12074 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::TypeId , ::Puma::CSyntax::TypeId ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a22_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12086 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool type_id ();

  struct TypeSpecSeq {
#line 12096 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 563 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12102 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 563 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13571;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypeSpecSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12171 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypeSpecSeq , ::Puma::CSyntax::TypeSpecSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 564 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec_seq (); }
    
#line 12186 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 565 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef TypeSpecSeq CTypeSpecSeqBuilder;

#line 589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12197 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13576;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12226 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12228 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::TypeSpecSeq , ::Puma::CSyntax::TypeSpecSeq ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a25_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12240 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return 0 ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool type_spec_seq ();

  struct TypeSpecSeq1 {
#line 12250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 569 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 569 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12291 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13581;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::TypeSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 570 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::TypeSpecSeq1 , ::Puma::CSyntax::TypeSpecSeq1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 570 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec_seq1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef TypeSpecSeq1 CTypeSpecSeq1Builder;

#line 596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12346 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13586;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12375 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::TypeSpecSeq1 , ::Puma::CSyntax::TypeSpecSeq1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a26_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12389 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool type_spec_seq1 ();

  struct AbstDeclarator {
#line 12399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 575 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12405 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 575 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12440 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13591;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::AbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 576 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::AbstDeclarator , ::Puma::CSyntax::AbstDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 576 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.abst_declarator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef AbstDeclarator CAbstDeclaratorBuilder;

#line 603 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13596;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12524 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12526 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::AbstDeclarator , ::Puma::CSyntax::AbstDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a27_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12538 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . abst_declarator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool abst_declarator ();

  struct DirectAbstDeclarator {
#line 12548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 581 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12554 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 581 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12589 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13601;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DirectAbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12623 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DirectAbstDeclarator , ::Puma::CSyntax::DirectAbstDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_abst_declarator (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DirectAbstDeclarator CDirectAbstDeclaratorBuilder;

#line 610 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12644 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13606;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12675 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::DirectAbstDeclarator , ::Puma::CSyntax::DirectAbstDeclarator ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a28_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12687 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . direct_abst_declarator ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool direct_abst_declarator ();

  struct DirectAbstDeclarator1 {
#line 12697 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 587 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12703 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 587 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12738 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13611;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::DirectAbstDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 588 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12772 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::DirectAbstDeclarator1 , ::Puma::CSyntax::DirectAbstDeclarator1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 588 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_abst_declarator1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef DirectAbstDeclarator1 CDirectAbstDeclarator1Builder;

#line 617 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_abst_declarator1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool direct_abst_declarator1 ();

  struct ParamDeclClause {
#line 12801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12807 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13621;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ParamDeclClause::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 594 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 12876 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ParamDeclClause , ::Puma::CSyntax::ParamDeclClause ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 594 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl_clause (); }
    
#line 12891 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax & );

#line 595 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
     private:
  typedef ParamDeclClause CParamDeclClauseBuilder;

#line 624 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 12902 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13626;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 12931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 12933 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::ParamDeclClause , ::Puma::CSyntax::ParamDeclClause ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a20_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 12945 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . param_decl_clause ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool param_decl_clause ();

  struct ParamDeclList {
#line 12955 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 599 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 12961 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 599 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12996 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13631;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ParamDeclList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 600 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 13030 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ParamDeclList , ::Puma::CSyntax::ParamDeclList ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 600 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl_list (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ParamDeclList CParamDeclListBuilder;

#line 631 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . param_decl_list ( ) ;
}   public:

#line 400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return ! s -> look_ahead ( TOK_CLOSE_ROUND ) && ! s -> look_ahead ( TOK_ELLIPSIS ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool param_decl_list ();

  CTree * rule_param_decl ();
  virtual bool param_decl ();
  
  struct ParamDecl1 {
#line 13067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 608 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 13073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 608 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13644;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ParamDecl1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 609 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 13142 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ParamDecl1 , ::Puma::CSyntax::ParamDecl1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 609 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl1 (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ParamDecl1 CParamDecl1Builder;

#line 640 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 13163 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13649;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 13192 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 13194 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::ParamDecl1 , ::Puma::CSyntax::ParamDecl1 ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a29_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 13206 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . param_decl1 ( ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool param_decl1 ();

//  CTree * rule_param_decl2 ();
//  virtual bool param_decl2 ();
  
#line 13218 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_fct_def();

#line 616 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
CTree * rule_fct_def ();
  virtual bool fct_def ();
  CTree * rule_arg_decl_seq ();
  virtual bool arg_decl_seq ();
  CTree * rule_fct_body ();
  virtual bool fct_body ();
  CTree * rule_init ();
  virtual bool init ();
  CTree * rule_init_clause ();
  virtual bool init_clause ();
  CTree * rule_init_list ();
  virtual bool init_list ();
  CTree * rule_init_list_item ();
  virtual bool init_list_item ();
  CTree * rule_designation ();
  virtual bool designation ();
  CTree * rule_designator ();
  virtual bool designator ();

  // A.8 Classes
  CTree * rule_class_spec ();
  virtual bool class_spec ();

  struct ClassHead {
#line 13246 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 639 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 13252 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 639 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13287 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13654;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ClassHead::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 640 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 13321 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ClassHead , ::Puma::CSyntax::ClassHead ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 640 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.class_head (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ClassHead CClassHeadBuilder;

#line 649 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :

#line 13342 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13659;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};


#line 13371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax &  arg0 ) 
#line 13373 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0< ::Puma::CTree * , ::Puma::CSyntax::ClassHead , ::Puma::CSyntax::ClassHead ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  ::Puma::CTree * result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_CSemBinding_CSemBinding_a31_around<__TJP> (&tjp);
  return (::Puma::CTree * &)result;

}
__attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s)
#line 13385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . class_head ( ) ;
}   public:

#line 405 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _class_head_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool class_head ();

  struct ClassKey {
#line 13400 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 645 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 13406 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 645 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13667;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::ClassKey::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 646 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax & arg0) 
#line 13475 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::ClassKey , ::Puma::CSyntax::ClassKey ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 646 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.class_key (); }
    static inline bool parse (CSyntax &);
     private:
  typedef ClassKey CClassKeyBuilder;

#line 656 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CBuilderExtension.ah"
 public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . class_key ( ) ;
}   public:

#line 410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _class_key_1 ) ;
}   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }};
  virtual bool class_key ();

  CTree * rule_member_spec ();
  virtual bool member_spec ();
  
#line 13511 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_decl();

#line 653 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
CTree * rule_member_decl ();
  virtual bool member_decl ();
  CTree * rule_member_declarator_list ();
  virtual bool member_declarator_list ();
  
#line 13520 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree * __exec_old_rule_member_declarator();

#line 657 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSyntax.h"
CTree * rule_member_declarator ();
  virtual bool member_declarator ();

protected:
  virtual bool is_fct_def ();
  virtual bool is_ass_expr ();

  virtual void handle_directive ();
   public:

#line 31 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 tokenset _typedef_name_1 ;
tokenset _identifier_1 ;
tokenset _literal_1 ;
tokenset _cmpd_str_1 ;
tokenset _str_literal_1 ;
tokenset _prim_expr_1 ;
tokenset _id_expr_1 ;
tokenset _cmpd_literal_1 ;
tokenset _postfix_expr_1 ;
tokenset _postfix_expr1_1 ;
tokenset _cast_expr1_1 ;
tokenset _cast_expr2_1 ;
tokenset _label_stmt_1 ;
tokenset _cmpd_stmt_1 ;
tokenset _select_stmt_1 ;
tokenset _iter_stmt_1 ;
tokenset _jump_stmt_1 ;
tokenset _decl_spec_1 ;
tokenset _misc_spec_1 ;
tokenset _storage_class_spec_1 ;
tokenset _fct_spec_1 ;
tokenset _type_spec_1 ;
tokenset _simple_type_spec_1 ;
tokenset _type_name_1 ;
tokenset _elaborated_type_spec_1 ;
tokenset _enum_spec_1 ;
tokenset _enum_spec1_1 ;
tokenset _direct_declarator1_1 ;
tokenset _cv_qual_seq_1 ;
tokenset _cv_qual_1 ;
tokenset _class_head_1 ;
tokenset _class_key_1 ;
tokenset _enum_key_1 ;

virtual void init_typedef_name ( ) {
_typedef_name_1 . set ( TOK_ID ) ;
}
virtual void init_identifier ( ) {
_identifier_1 . set ( TOK_ID ) ;
}
virtual void init_literal ( ) {
init_cmpd_str ( ) ;
_literal_1 = _cmpd_str_1 ;
_literal_1 . set ( TOK_INT_VAL ) ;
_literal_1 . set ( TOK_ZERO_VAL ) ;
_literal_1 . set ( TOK_CHAR_VAL ) ;
_literal_1 . set ( TOK_FLT_VAL ) ;
}
virtual void init_cmpd_str ( ) {
init_str_literal ( ) ;
_cmpd_str_1 = _str_literal_1 ;
}
virtual void init_str_literal ( ) {
_str_literal_1 . set ( TOK_STRING_VAL ) ;
}
virtual void init_prim_expr ( ) {
init_literal ( ) ;
init_id_expr ( ) ;
_prim_expr_1 = _literal_1 ;
_prim_expr_1 |= _id_expr_1 ;
_prim_expr_1 . set ( TOK_OPEN_ROUND ) ;
}
virtual void init_id_expr ( ) {
_id_expr_1 . set ( TOK_ID ) ;
}
virtual void init_cmpd_literal ( ) {
_cmpd_literal_1 . set ( TOK_OPEN_ROUND ) ;
}
virtual void init_postfix_expr ( ) {
init_prim_expr ( ) ;
init_cmpd_literal ( ) ;
_postfix_expr_1 = _prim_expr_1 ;
_postfix_expr_1 |= _cmpd_literal_1 ;
}
virtual void init_postfix_expr1 ( ) {
_postfix_expr1_1 . set ( TOK_DECR ) ;
_postfix_expr1_1 . set ( TOK_INCR ) ;
_postfix_expr1_1 . set ( TOK_DOT ) ;
_postfix_expr1_1 . set ( TOK_PTS ) ;
_postfix_expr1_1 . set ( TOK_OPEN_ROUND ) ;
_postfix_expr1_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_cast_expr1 ( ) {
init_cast_expr2 ( ) ;
_cast_expr1_1 = _cast_expr2_1 ;
}

virtual void init_cast_expr2 ( ) {
_cast_expr2_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_label_stmt ( ) {
init_identifier ( ) ;
_label_stmt_1 = _identifier_1 ;
_label_stmt_1 . set ( TOK_CASE ) ;
_label_stmt_1 . set ( TOK_DEFAULT ) ;
}

virtual void init_cmpd_stmt ( ) {
_cmpd_stmt_1 . set ( TOK_OPEN_CURLY ) ;
}

virtual void init_select_stmt ( ) {
_select_stmt_1 . set ( TOK_SWITCH ) ;
_select_stmt_1 . set ( TOK_IF ) ;
}

virtual void init_iter_stmt ( ) {
_iter_stmt_1 . set ( TOK_FOR ) ;
_iter_stmt_1 . set ( TOK_WHILE ) ;
_iter_stmt_1 . set ( TOK_DO ) ;
}

virtual void init_jump_stmt ( ) {
_jump_stmt_1 . set ( TOK_BREAK ) ;
_jump_stmt_1 . set ( TOK_CONTINUE ) ;
_jump_stmt_1 . set ( TOK_RETURN ) ;
_jump_stmt_1 . set ( TOK_GOTO ) ;
}

virtual void init_decl_spec ( ) {
init_storage_class_spec ( ) ;
init_type_spec ( ) ;
init_fct_spec ( ) ;
init_misc_spec ( ) ;
_decl_spec_1 = _storage_class_spec_1 ;
_decl_spec_1 |= _type_spec_1 ;
_decl_spec_1 |= _fct_spec_1 ;
_decl_spec_1 |= _misc_spec_1 ;
}


#line 13668 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14init_misc_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax14init_misc_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14098;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13692 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_misc_spec ( ) 
#line 13694 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14init_misc_specEv_0< void, ::Puma::CSyntax , ::Puma::CSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_misc_spec();
  AC::invoke_WinDeclSpecs_WinDeclSpecs_a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_misc_spec()
#line 13704 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
_misc_spec_1 . set ( TOK_TYPEDEF ) ;
}


#line 13710 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14101;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_storage_class_spec ( ) 
#line 13736 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0< void, ::Puma::CSyntax , ::Puma::CSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_storage_class_spec();
  AC::invoke_ExtGnu_ExtGnu_a35_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_storage_class_spec()
#line 13746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
_storage_class_spec_1 . set ( TOK_AUTO ) ;
_storage_class_spec_1 . set ( TOK_REGISTER ) ;
_storage_class_spec_1 . set ( TOK_STATIC ) ;
_storage_class_spec_1 . set ( TOK_EXTERN ) ;
}

virtual void init_fct_spec ( ) {
_fct_spec_1 . set ( TOK_INLINE ) ;
}

virtual void init_type_spec ( ) {
init_simple_type_spec ( ) ;
init_class_spec ( ) ;
init_enum_spec ( ) ;
init_elaborated_type_spec ( ) ;
init_cv_qual ( ) ;
_type_spec_1 = _simple_type_spec_1 ;
_type_spec_1 |= _class_spec_1 ;
_type_spec_1 |= _enum_spec_1 ;
_type_spec_1 |= _elaborated_type_spec_1 ;
_type_spec_1 |= _cv_qual_1 ;
}


#line 13772 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14110;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13796 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_simple_type_spec ( ) 
#line 13798 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0< void, ::Puma::CSyntax , ::Puma::CSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_simple_type_spec();
  AC::invoke_ExtGnu_ExtGnu_a37_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_simple_type_spec()
#line 13808 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
init_type_name ( ) ;

_simple_type_spec_1 = _type_name_1 ;
_simple_type_spec_1 |= _prim_types ;
}

virtual void init_type_name ( ) {
init_typedef_name ( ) ;
_type_name_1 = _typedef_name_1 ;
}

virtual void init_elaborated_type_spec ( ) {
init_class_key ( ) ;
_elaborated_type_spec_1 = _class_key_1 ;
_elaborated_type_spec_1 . set ( TOK_ENUM ) ;
}

virtual void init_enum_key ( ) {
_enum_key_1 . set ( TOK_ENUM ) ;
}

virtual void init_enum_spec ( ) {
init_enum_spec1 ( ) ;
_enum_spec_1 = _enum_spec1_1 ;
}

virtual void init_enum_spec1 ( ) {
init_enum_key ( ) ;
_enum_spec1_1 = _enum_key_1 ;
}

virtual void init_direct_declarator1 ( ) {
_direct_declarator1_1 . set ( TOK_OPEN_SQUARE ) ;
_direct_declarator1_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_cv_qual_seq ( ) {
init_cv_qual ( ) ;
_cv_qual_seq_1 = _cv_qual_1 ;
}

virtual void init_cv_qual ( ) {
_cv_qual_1 = _cv_quals ;
}

virtual void init_class_head ( ) {
init_class_key ( ) ;
_class_head_1 = _class_key_1 ;
}


#line 13861 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14init_class_keyEv_0 {
  typedef TJP__ZN4Puma7CSyntax14init_class_keyEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 14140;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 13885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_class_key ( ) 
#line 13887 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14init_class_keyEv_0< void, ::Puma::CSyntax , ::Puma::CSyntax ,  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_init_class_key();
  AC::invoke_ExtACSyntaxCoupling_ExtACSyntaxCoupling_a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_class_key()
#line 13897 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
_class_key_1 . set ( TOK_STRUCT ) ;
_class_key_1 . set ( TOK_UNION ) ;
}   private:
  typedef CSyntax ExtACSyntax;

#line 30 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtACSyntaxH.ah"
 protected :
void skip_pointcut_expr ( ) ;
CTree * rule_order_decl ( ) ;
virtual bool order_decl ( ) ;
CTree * rule_order_list ( ) ;
virtual bool order_list ( ) ;
CTree * rule_advice_decl ( ) ;
virtual bool advice_decl ( ) ;
CTree * rule_pointcut_decl ( ) ;
virtual bool pointcut_decl ( ) ;
CTree * rule_slice_ref ( ) ;
virtual bool slice_ref ( ) ;
CTree * rule_class_slice_decl ( ) ;
virtual bool class_slice_decl ( ) ;
CTree * rule_class_slice_member_decl ( ) ;
virtual bool class_slice_member_decl ( ) ;
CTree * rule_class_slice_member_list ( ) ;
virtual bool class_slice_member_list ( ) ;
CTree * rule_pointcut_expr ( ) ;
virtual bool pointcut_expr ( ) ;
CTree * rule_pointcut_member_decl ( ) ;
virtual bool pointcut_member_decl ( ) ;
CTree * rule_advice_member_decl ( ) ;
virtual bool advice_member_decl ( ) ;
CTree * rule_intro ( ) ;
virtual bool intro ( ) ;   private:
  typedef CSyntax ExtGnuAttributeSyntax;

#line 1256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnu.ah"
 public :
struct GnuAttribute {
#line 13936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 13940 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 13943 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13681;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAttribute::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 13975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 13977 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAttribute , ::Puma::CSyntax::GnuAttribute ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 13989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_attribute ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_attribute ( ) ;
bool catch_gnu_attribute ( ) ;   private:
  typedef CSyntax ExtGnuAsmSyntax;

#line 1303 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnu.ah"
 public :
struct GnuAsmSpec {
#line 14004 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14008 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14011 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13693;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14043 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14045 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmSpec , ::Puma::CSyntax::GnuAsmSpec ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14057 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_spec ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_spec ( ) ;

struct GnuAsmDef {
#line 14068 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14072 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14075 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13705;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14109 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmDef , ::Puma::CSyntax::GnuAsmDef ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14121 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_def ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_def ( ) ;

struct GnuAsmOperands {
#line 14132 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14136 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14139 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13717;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmOperands::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14171 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmOperands , ::Puma::CSyntax::GnuAsmOperands ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14185 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_operands ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_operands ( ) ;

struct GnuAsmEmptyOperands {
#line 14196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14200 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13729;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmEmptyOperands::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14235 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14237 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmEmptyOperands , ::Puma::CSyntax::GnuAsmEmptyOperands ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_empty_operands ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_empty_operands ( ) ;

struct GnuAsmOperand {
#line 14260 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14264 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14267 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13741;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmOperand::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14299 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmOperand , ::Puma::CSyntax::GnuAsmOperand ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_operand ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_operand ( ) ;

struct GnuAsmClobbers {
#line 14324 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14328 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13753;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuAsmClobbers::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14365 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuAsmClobbers , ::Puma::CSyntax::GnuAsmClobbers ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_clobbers ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_asm_clobbers ( ) ;   private:
  typedef CSyntax ExtGnuLocalLabelStmtSyntax;

#line 1493 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnu.ah"
 public :
struct GnuLocalLabelStmt {
#line 14391 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
#line 14395 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


#line 14398 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 13765;
  static const AC::JPType JPTYPE = (AC::JPType)8;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void *arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  void proceed () {
    *__TJP::result () = (bool )::Puma::CSyntax::GnuLocalLabelStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 14430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax &  arg0 ) 
#line 14432 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0< bool , ::Puma::CSyntax::GnuLocalLabelStmt , ::Puma::CSyntax::GnuLocalLabelStmt ,  AC::TL< ::Puma::CSyntax & , AC::TLE > > __TJP;
  bool result;
  __TJP tjp;
  tjp._args[0] = (void*)&arg0;
  tjp._result = &(__TJP::Result&)result;
  AC::invoke_LookAhead_LookAhead_a0_around<__TJP> (&tjp);
  return (bool &)result;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax & s)
#line 14444 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_local_label_stmt ( ) ; }
static inline bool parse ( CSyntax & ) ;

#line 14448 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static ::Puma::CTree * __exec_old_build(::Puma::CSyntax & s);

#line 14451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline CTree * build ( CSyntax & s ) ;
   public:

#line 417 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CLookAhead.ah"
 static bool lookahead ( void * ) { return true ; }} ;
virtual bool gnu_local_label_stmt ( ) ;   private:
  typedef CSyntax ExtGnuTypeofSyntax;

#line 1526 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnu.ah"
 public :
CTree * rule_gnu_typeof ( ) ;
virtual bool gnu_typeof ( ) ;   private:
  typedef CSyntax WinAsmSyntax;

#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/WinAsm.ah"
 public :
virtual bool asm_block ( ) ;
Puma :: CTree * rule_asm_block ( ) ;   private:
  typedef CSyntax WinDeclSpecsSyntax;

#line 102 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/WinDeclSpecs.ah"
 public :

Puma :: CTree * rule_win_decl_spec ( ) ;
virtual bool win_decl_spec ( ) ;};

inline CSyntax::CSyntax (CBuilder &b, CSemantic &s) : Syntax (b, s),
 last_look_ahead_token (0),
 last_look_ahead_result (false)
 {}

inline void CSyntax::handle_directive ()
 { Syntax::handle_directive (); }


} // namespace Puma

#endif /* __CSyntax_h__ */

#line 14491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSyntax.h"

#ifdef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSyntax_h__
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#include "Puma/ExtACBuilderCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#include "Puma/ExtACSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#include "Puma/ExtCC1XBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#include "Puma/ExtCC1XBuilderCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#include "Puma/ExtCC1XSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#include "Puma/ExtCC1XSemanticH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#include "Puma/ExtCC1XSemanticCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#undef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSyntax_h__
#endif // __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSyntax_h__
