#ifndef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSemDatabase_h__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 0x0004, EXECUTION = 0x0008, CONSTRUCTION = 0x0010, DESTRUCTION = 0x0020 };
  struct Action {
    void **_args; void *_result; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  struct AnyResultBuffer {};
  template <typename T> struct ResultBuffer : public AnyResultBuffer {
    struct { char _array[sizeof (T)]; } _data;
    ~ResultBuffer () { ((T&)_data).T::~T(); }
    operator T& () const { return (T&)_data; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__AttrTypes const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0 };
  };
  template<typename T> struct TypeInfo<T, 1> {
    enum { AVAILABLE = 1 };
    enum { ELEMENTS = T::__AttrTypes::ARGS };
    template<int I>
    struct Member : public AC::Arg<typename T::__AttrTypes,I> {};
    template<int I>
    static typename Member<I>::ReferredType* member (T* obj) {
      return (typename Member<I>::ReferredType*)obj->__attr (I);
    }
    static const char *member_name (T &obj, int i) {
      return obj.__attr_name (i);
    }
	 };
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
inline void * operator new (__SIZE_TYPE__, AC::AnyResultBuffer *p) { return p; }
inline void operator delete (void *, AC::AnyResultBuffer *) { } // for VC++
#endif // __cplusplus
#endif // __ac_h_
#endif // __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"

#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"

#ifndef __ac_fwd_ExtAC__
#define __ac_fwd_ExtAC__
class ExtAC;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a0_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a5_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a6_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a7_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a8_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a9_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a11_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtAC_ExtAC_a12_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#endif

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CSemDatabase_h__
#define __CSemDatabase_h__

/** \file 
 *  Semantic information database. */

#include "Puma/CScopeInfo.h"
#include "Puma/CProject.h"
#include <iostream>
#include <map>
#include <set>

using namespace std;

namespace Puma {


class CObjectInfo;
class CArgumentInfo;
class CAttributeInfo;
class CBaseClassInfo;
class CClassInfo;
class CClassInstance;
class CEnumInfo;
class CEnumeratorInfo;
class CFunctionInfo;
class CFctInstance;
class CLabelInfo;
class CLocalScope;
class CMemberAliasInfo;
class CNamespaceInfo;
class CTemplateInfo;
class CTemplateInstance;
class CTemplateParamInfo;
class CTypedefInfo;
class CUnionInfo;
class CUnionInstance;
class CTypeInfo;
class CFileInfo;
class Token;


/** \class CSemDatabase CSemDatabase.h Puma/CSemDatabase.h
 *  Semantic information database. Contains all semantic objects
 *  created during the semantic analysis for one translation
 *  unit. */

#line 182 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"

#line 218 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
namespace Puma {

#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"
class CSemDatabase : public Puma :: ACClassDatabase 
#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"
{
#line 231 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"

#line 238 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 65 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"

public:
  typedef set<CObjectInfo*> ObjectSet;

private:
  Array<CObjectInfo*> _Classes;    // index of classes
  Array<CObjectInfo*> _Unions;     // index of unions
  Array<CObjectInfo*> _Enums;      // index of enums
  Array<CObjectInfo*> _Typedefs;   // index of typedefs
  Array<CObjectInfo*> _Functions;  // index of functions
  Array<CObjectInfo*> _Files;      // index of files

  CProject *_Project; // associated project

  ObjectSet _Objects; // set of all semantic objects
  multimap<int,CFunctionInfo*> _builtin_ops; // map for built-in operator lookup

public:
  /** Constructor. 
   *  \param prj The project information.
   *  \param size Initial size of the database (not yet used!). */
  CSemDatabase (CProject &prj, int size = 997);
  /** Destructor. Destroys all semantic information objects in
   *  the database. */
  virtual ~CSemDatabase ();

  /** Get the set of all semantic objects. */
  ObjectSet& Objects();

  /** Get the number of semantic objects. */
  unsigned ObjectInfos () const;
  /** Get the number of semantic objects for classes. */
  unsigned ClassInfos () const;
  /** Get the number of semantic objects for unions. */
  unsigned UnionInfos () const;
  /** Get the number of semantic objects for enumerations. */
  unsigned EnumInfos () const;
  /** Get the number of semantic objects for typedefs. */
  unsigned TypedefInfos () const;
  /** Get the number of semantic objects for functions. */
  unsigned FunctionInfos () const;
  /** Get the number of semantic objects for translation units (file scope). */
  unsigned FileInfos () const;

  /** Get the n-th semantic object.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CObjectInfo *ObjectInfo (unsigned n) const;
  /** Get the n-th semantic object for classes.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CClassInfo *ClassInfo (unsigned n) const;
  /** Get the n-th semantic object for unions.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CUnionInfo *UnionInfo (unsigned n) const;
  /** Get the n-th semantic object for enumerations.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CEnumInfo *EnumInfo (unsigned n) const;
  /** Get the n-th semantic object for typedefs.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CTypedefInfo *TypedefInfo (unsigned n) const;
  /** Get the n-th semantic object for functions.
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CFunctionInfo *FunctionInfo (unsigned n) const;
  /** Get the n-th semantic object for translation units (file scope).
   *  \param n The index of the object.
   *  \return The object or NULL if \e n is invalid. */
  CFileInfo *FileInfo (unsigned n) const;

  /** Get the semantic object for the entity at the given
   *  source code position (token). 
   *  \param pos The token of the entity. 
   *  \return The semantic object or NULL. */
  CObjectInfo *ObjectInfo (Token *pos) const; 
  /** Get the semantic object for the entity at the given
   *  source code position (token). 
   *  \param pos The token of the entity. 
   *  \return The semantic object or NULL. */
  CObjectInfo *ObjectInfo (CT_Token *pos) const; 

public:
  CArgumentInfo *newArgument ();
  CAttributeInfo *newAttribute ();
  CBaseClassInfo *newBaseClass ();
  CClassInfo *newClass ();
  CClassInstance *newClassInstance ();
  CEnumInfo *newEnum ();
  CEnumeratorInfo *newEnumerator ();
  CFunctionInfo *newFunction ();
  CFctInstance *newFctInstance ();
  CLabelInfo *newLabel ();
  CLocalScope *newLocalScope ();
  CMemberAliasInfo *newMemberAlias ();
  CNamespaceInfo *newNamespace ();
  CTemplateInfo *newTemplate ();
  CTemplateParamInfo *newTemplateParam ();
  CTypedefInfo *newTypedef ();
  CUnionInfo *newUnion ();
  CUnionInstance *newUnionInstance ();
  CUsingInfo *newUsing ();
  CFileInfo *newFile ();

public:
  /** Insert a new semantic object into the database.
   *  \param info The semantic object. */
  void Insert (CObjectInfo *info);
  /** Remove the given semantic object from the database.
   *  \param info The semantic object. */
  void Remove (CObjectInfo *info);
  /** Get the semantic object for the given built-in operator.
   *  \param name The operator name/symbol.
   *  \param tok The operator token type.
   *  \param rtype The result type of the operator.
   *  \param t0 Type of the first operand.
   *  \param t1 Type of the second operand, or NULL if only one operand. */
  CFunctionInfo *BuiltinOperator (const char *name, int tok, CTypeInfo *rtype, CTypeInfo *t0, CTypeInfo *t1);
  /** Dump the contents of the database. The dump is indented as
   *  tree corresponding to the nesting of the semantic objects.
   *  \param out The output stream.
   *  \param depth The maximum indentation depth (0 means infinite). 
   *  \param dump_builtins Dump or ignore builtin function, types and objects. */
  
#line 397 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"
public: __attribute__((always_inline)) inline void __exec_old_Dump(::std::ostream & out,int depth,bool dump_builtins) const;

#line 190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CSemDatabase.h"
void Dump (ostream &out, int depth = 0, bool dump_builtins = true) const;

  /** Get the project information. */
  CProject *Project () const;

private:
  void CreateParameter (CFunctionInfo *fi, CTypeInfo *type) const;

  void Dump (ostream &, CStructure *, int, int, bool) const;
  void DumpType (ostream &, CObjectInfo *, int) const;
  void DumpUsing (ostream &, CUsingInfo *, int) const;
  void DumpFriends (ostream &, CStructure *) const;
  void DumpFunction (ostream &, CFunctionInfo *, int, int) const;
  void DumpAttribute (ostream &, CAttributeInfo *, int) const;
  void DumpNamespace (ostream &, CNamespaceInfo *, int) const;
  void DumpQualities (ostream &, CObjectInfo *) const;
  void DumpScopeName (ostream &, CStructure *) const;
  void DumpLocalScope (ostream &, CObjectInfo *, int) const;
  void DumpTemplateParam (ostream &, CTemplateParamInfo *, int) const;
  void DumpTemplateInstance (ostream &, CObjectInfo *, int) const;
  void indent (ostream &, int) const;
};

inline CSemDatabase::CSemDatabase (CProject &p, int size) :
  _Classes (20, 50),
  _Unions (20, 50),
  _Enums (20, 50),
  _Typedefs (20, 50),
  _Functions (20, 50),
  _Files (5, 20),
  _Project (&p)
 {}

inline CSemDatabase::ObjectSet& CSemDatabase::Objects()
 { return _Objects; }

inline unsigned CSemDatabase::ObjectInfos () const
 { return ClassInfos () + UnionInfos () + EnumInfos () + 
          TypedefInfos () + FunctionInfos () + FileInfos (); }
inline unsigned CSemDatabase::ClassInfos () const
 { return _Classes.length (); }
inline unsigned CSemDatabase::UnionInfos () const
 { return _Unions.length (); }
inline unsigned CSemDatabase::EnumInfos () const
 { return _Enums.length (); }
inline unsigned CSemDatabase::TypedefInfos () const
 { return _Typedefs.length (); }
inline unsigned CSemDatabase::FunctionInfos () const
 { return _Functions.length (); }
inline unsigned CSemDatabase::FileInfos () const
 { return _Files.length (); }

inline CClassInfo *CSemDatabase::ClassInfo (unsigned i) const
 { return (CClassInfo*)_Classes.lookup (i); }
inline CUnionInfo *CSemDatabase::UnionInfo (unsigned i) const
 { return (CUnionInfo*)_Unions.lookup (i); }
inline CEnumInfo *CSemDatabase::EnumInfo (unsigned i) const
 { return (CEnumInfo*)_Enums.lookup (i); }
inline CTypedefInfo *CSemDatabase::TypedefInfo (unsigned i) const
 { return (CTypedefInfo*)_Typedefs.lookup (i); }
inline CFunctionInfo *CSemDatabase::FunctionInfo (unsigned i) const
 { return (CFunctionInfo*)_Functions.lookup (i); }
inline CFileInfo *CSemDatabase::FileInfo (unsigned i) const
 { return (CFileInfo*)_Files.lookup (i); }

inline CProject *CSemDatabase::Project () const
 { return _Project; }


} // namespace Puma

#endif /* __CSemDatabase_h__ */

#line 474 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CSemDatabase.h"

#ifdef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSemDatabase_h__
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#include "Puma/ExtACBuilderCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#include "Puma/ExtACSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#include "Puma/ExtCC1XBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#include "Puma/ExtCC1XBuilderCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#include "Puma/ExtCC1XSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#include "Puma/ExtCC1XSemanticH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#include "Puma/ExtCC1XSemanticCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#undef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSemDatabase_h__
#endif // __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CSemDatabase_h__
