#ifndef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_Heap_h__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 0x0004, EXECUTION = 0x0008, CONSTRUCTION = 0x0010, DESTRUCTION = 0x0020 };
  struct Action {
    void **_args; void *_result; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  struct AnyResultBuffer {};
  template <typename T> struct ResultBuffer : public AnyResultBuffer {
    struct { char _array[sizeof (T)]; } _data;
    ~ResultBuffer () { ((T&)_data).T::~T(); }
    operator T& () const { return (T&)_data; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__AttrTypes const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0 };
  };
  template<typename T> struct TypeInfo<T, 1> {
    enum { AVAILABLE = 1 };
    enum { ELEMENTS = T::__AttrTypes::ARGS };
    template<int I>
    struct Member : public AC::Arg<typename T::__AttrTypes,I> {};
    template<int I>
    static typename Member<I>::ReferredType* member (T* obj) {
      return (typename Member<I>::ReferredType*)obj->__attr (I);
    }
    static const char *member_name (T &obj, int i) {
      return obj.__attr_name (i);
    }
	 };
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
inline void * operator new (__SIZE_TYPE__, AC::AnyResultBuffer *p) { return p; }
inline void operator delete (void *, AC::AnyResultBuffer *) { } // for VC++
#endif // __cplusplus
#endif // __ac_h_
#endif // __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/Heap.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __Heap_h__
#define __Heap_h__

#include <stdlib.h>

// use pt_malloc only for the cross-compiled mingw version!
#if defined(WIN32) && !defined(_MSC_VER) 

extern "C" void *pt_malloc (size_t);
extern "C" void  pt_free (void *);

namespace Puma {


class Heap {
public:
  Heap () {}
  ~Heap () {}
   
  void *malloc (size_t s) 
   { return pt_malloc (s); }
  void free(void *p) 
   { pt_free(p); }
};


} // namespace Puma

#else /* defined(WIN32) && !defined(_MSC_VER) */

namespace Puma {



#line 128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/Heap.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 52 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/Heap.h"
class Heap {
#line 164 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/Heap.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 52 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/Heap.h"

#line 171 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/Heap.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 52 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/Heap.h"

public:
  Heap () {}
  ~Heap () {}

  void *malloc (size_t n) 
   { return ::malloc (n); }
  void free (void *p) 
   { ::free (p); }
};


} // namespace Puma

#endif /* defined(WIN32) && !defined(_MSC_VER) */

#endif /* __Heap_h__ */

#line 222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/Heap.h"

#ifdef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_Heap_h__
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#include "Puma/ExtACBuilderCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#include "Puma/ExtACSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#include "Puma/ExtCC1XBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#include "Puma/ExtCC1XBuilderCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#include "Puma/ExtCC1XSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#include "Puma/ExtCC1XSemanticH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#include "Puma/ExtCC1XSemanticCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#undef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_Heap_h__
#endif // __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_Heap_h__
