#ifndef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#define __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CTree_h__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 0x0004, EXECUTION = 0x0008, CONSTRUCTION = 0x0010, DESTRUCTION = 0x0020 };
  struct Action {
    void **_args; void *_result; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  struct AnyResultBuffer {};
  template <typename T> struct ResultBuffer : public AnyResultBuffer {
    struct { char _array[sizeof (T)]; } _data;
    ~ResultBuffer () { ((T&)_data).T::~T(); }
    operator T& () const { return (T&)_data; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__AttrTypes const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0 };
  };
  template<typename T> struct TypeInfo<T, 1> {
    enum { AVAILABLE = 1 };
    enum { ELEMENTS = T::__AttrTypes::ARGS };
    template<int I>
    struct Member : public AC::Arg<typename T::__AttrTypes,I> {};
    template<int I>
    static typename Member<I>::ReferredType* member (T* obj) {
      return (typename Member<I>::ReferredType*)obj->__attr (I);
    }
    static const char *member_name (T &obj, int i) {
      return obj.__attr_name (i);
    }
	 };
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
inline void * operator new (__SIZE_TYPE__, AC::AnyResultBuffer *p) { return p; }
inline void operator delete (void *, AC::AnyResultBuffer *) { } // for VC++
#endif // __cplusplus
#endif // __ac_h_
#endif // __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 77 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

#ifndef __ac_fwd_ExtACTree__
#define __ac_fwd_ExtACTree__
class ExtACTree;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACTree_ExtACTree_a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACTree_ExtACTree_a1_before (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#endif

#ifndef __ac_fwd_ExtGnuCTree__
#define __ac_fwd_ExtGnuCTree__
class ExtGnuCTree;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree_a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree_a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree_a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree_a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#endif

#line 1 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CTree_h__
#define __CTree_h__

/** \file 
 *  C/C++ syntax tree classes. */

namespace Puma {


// Syntax tree node hierarchy:
class CTree;
class   CT_Statement;          
class     CT_LabelStmt;
class     CT_IfStmt;
class     CT_IfElseStmt;
class     CT_SwitchStmt;
class     CT_BreakStmt;
class     CT_ExprStmt;
class     CT_WhileStmt;
class     CT_DoStmt;
class     CT_ForStmt;
class     CT_ContinueStmt;
class     CT_ReturnStmt;
class     CT_GotoStmt;
class     CT_DeclStmt;
class     CT_CaseStmt;
class     CT_DefaultStmt;
class     CT_TryStmt;
class   CT_Expression;
class     CT_Call;
class       CT_CallExpr;
class       CT_ImplicitCall;
class     CT_ThrowExpr;
class     CT_NewExpr;
class     CT_DeleteExpr;
class     CT_ConstructExpr;
class     CT_Integer;
class     CT_Character;
class       CT_WideCharacter;
class     CT_Float;
class     CT_Bool;
class     CT_BracedExpr;
class     CT_BinaryExpr;
class       CT_MembPtrExpr;
class         CT_MembRefExpr;
class     CT_UnaryExpr;
class       CT_PostfixExpr;
class       CT_AddrExpr;
class       CT_DerefExpr;
class     CT_IfThenExpr;
class     CT_CmpdLiteral;
class     CT_IndexExpr;
class     CT_CastExpr;
class     CT_StaticCast;
class       CT_ConstCast;
class       CT_ReintCast;
class       CT_DynamicCast;
class     CT_TypeidExpr;
class     CT_SizeofExpr;
class     CT_AlignofExpr;
class     CT_TypeTraitExpr;
class     CT_OffsetofExpr;
class     CT_MembDesignator;
class     CT_IndexDesignator;
class     CT_ImplicitCast;
class     CT_MembInit;
class   CT_DeclSpec;
class     CT_PrimDeclSpec;
class     CT_NamedType;
class     CT_ClassSpec;
class       CT_UnionSpec;
class       CT_EnumSpec;
class     CT_ExceptionSpec;
class   CT_Declarator;
class     CT_InitDeclarator;
class     CT_BracedDeclarator;
class     CT_ArrayDeclarator;
class     CT_FctDeclarator;
class     CT_RefDeclarator;
class     CT_PtrDeclarator;
class     CT_MembPtrDeclarator;
class     CT_BitFieldDeclarator;
class   CT_Decl;
class     CT_ObjDecl;
class     CT_ArgDecl;
class     CT_AccessDecl;
class       CT_UsingDecl;
class     CT_FctDef;
class     CT_AsmDef;
class     CT_EnumDef;
class     CT_ClassDef;
class       CT_UnionDef;
class     CT_Enumerator;
class     CT_LinkageSpec;
class     CT_Handler;
class     CT_TemplateDecl;
class     CT_TemplateParamDecl;
class       CT_TypeParamDecl;
class       CT_NonTypeParamDecl;
class     CT_NamespaceDef;
class     CT_NamespaceAliasDef;
class     CT_UsingDirective;
class     CT_Condition;
class   CT_List;
class     CT_CmpdStmt;
class     CT_DeclSpecSeq;
class     CT_HandlerSeq;
class     CT_DesignatorSeq;
class     CT_DeclList;
class       CT_Program;
class       CT_ArgDeclList;
class         CT_ArgNameList;
class       CT_ArgDeclSeq;
class       CT_MembList;
class     CT_ExprList;
class     CT_DeclaratorList;
class     CT_BaseSpecList;
class     CT_MembInitList;
class     CT_SimpleName;
class       CT_SpecialName;
class         CT_PrivateName;
class         CT_OperatorName;
class         CT_DestructorName;
class         CT_ConversionName;
class         CT_TemplateName;
class       CT_QualName;
class         CT_RootQualName;
class     CT_String;
class       CT_WideString;
class     CT_TemplateParamList;
class     CT_TemplateArgList;
class     CT_ExtensionList;
class   CT_Token;
class   CT_Error;
class   CT_DelayedParse;
class   CT_BaseSpec;
class   CT_AccessSpec;
class   CT_ArrayDelimiter;
class   CT_Any;
class   CT_AnyList;
class   CT_AnyExtension;
class   CT_AnyCondition;

} // namespace Puma

#include "Puma/ErrorSeverity.h"
#include "Puma/CSemObject.h"
#include "Puma/CSemScope.h"
#include "Puma/CSemValue.h"
#include "Puma/CExprValue.h"
#include "Puma/CStrLiteral.h"
#include "Puma/CTypeInfo.h"
#include "Puma/Printable.h"
#include "Puma/CTokens.h"
#include "Puma/Token.h"

#include <iostream>
#include <map>
#include <string.h>

using namespace std;

namespace Puma {


class ErrorStream;
class CObjectInfo;
class CStructure;

/*****************************************************************************/
/*                                                                           */
/*                    S y n t a x  t r e e  n o d e s                        */
/*                                                                           */
/*****************************************************************************/

/** \class CTree CTree.h Puma/CTree.h
 *  Base class for all C/C++ syntax tree classes. 
 *
 *  The syntax tree is the result of the syntactic analysis of the input source 
 *  code representing its syntactic structure according to the accepted grammar
 *  (see class Syntax). 
 *
 *  Objects of this class and classes derived from this class are created by 
 *  the tree builder component of %Puma during the parse process. A syntax tree 
 *  shall be destroyed using the tree builder that has created it by calling its 
 *  method Builder::destroy(CTree*) with the root node of the syntax tree as its 
 *  argument.
 *  
 *  The navigation in the syntax tree is done using the methods CTree::Parent(), 
 *  CTree::Sons(), and CTree::Son(int) const. In a syntax tree "sons" are 
 *  understood as the syntactic child nodes of a syntax tree node, whereas 
 *  "daughters" are understood are their semantic child nodes. 
 *
 *  Another way to traverse a syntax tree is to implement an own tree visitor 
 *  based on class Puma::CVisitor. This is recommended especially for larger 
 *  syntax trees.
 *
 *  A syntax tree node can be identified by comparing its node name with the node 
 *  identifier of the expected syntax tree node:
 *  \code if (node->NodeName() == Puma::CT_BinaryExpr::NodeId()) ... \endcode
 *  
 *  Based on the syntax tree further semantic analyses can be performed. Semantic 
 *  information, like scope, value, type, and object information, is linked into 
 *  the syntax tree. It can be accessed using the methods CTree::SemScope(), 
 *  CTree::SemValue(), and CTree::SemObject(). Some nodes provide short-cuts to
 *  the semantic type and value information by implementing the methods 
 *  CTree::Type() and CTree::Value().
 *
 *  The information of the syntax tree can be used to perform high-level 
 *  transformations of the source code (see class ManipCommander). */

#line 343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 379 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 390 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 401 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CTree {
#line 412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree * _parent;

public:
  /*DEBUG*/static int alloc;
  /*DEBUG*/static int release;

protected:
  /** Get the n-th son from given sons array. Skips empty (NULL) array items.
   *  \param sons The sons array.
   *  \param len Length of the sons array.
   *  \param n Index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (CTree * const *sons, int len, int n) const;
  /** Get the number of sons in the given sons array. Skips empty (NULL) array items.
   *  \param sons The sons array.
   *  \param len Length of the sons array. */
  int Sons (CTree * const *sons, int len) const;
  /** Replace a son.
   *  \param sons The sons array.
   *  \param len Length of the sons array.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree **sons, int len, CTree *old_son, CTree *new_son);
  /** Replace a son if it equals the given son.
   *  \param son The actual son.
   *  \param old_son The son to replace, must match the actual son.
   *  \param new_son The new son, overwrites the actual son. */
  void ReplaceSon (CTree *&son, CTree *old_son, CTree *new_son);
  /** Add a new son.
   *  \param son The actual son.
   *  \param new_son The new son, overwrites the actual son. */
  void AddSon (CTree *&son, CTree *new_son);
  /** Set the parent tree node.
   *  \param parent The new parent tree node. */
  void SetParent (const CTree *parent) { _parent = (CTree*)parent; }
  /** Set the parent tree node of the given tree node.
   *  \param node The tree node.
   *  \param parent The new parent. */
  void SetParent (CTree *node, const CTree *parent) { node->_parent = (CTree*)parent; }
  
protected:
  /** Default constructor. */
  CTree () : _parent(0) { /*DEBUG*/alloc++; }

public:
  /** Destructor. */
  virtual ~CTree () { /*DEBUG*/release++; }
  /** Get the number of sons. */
  virtual int Sons () const = 0;
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  virtual CTree *Son (int n) const { return (CTree*)0; }
  /** Get the node name (node identifier). */
  virtual const char *NodeName () const = 0;
  /** Get the first token of the syntactic construct represented by this sub-tree.
   *  \return The token or NULL. */
  
#line 511 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::Token * __exec_old_token() const;

#line 287 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual Token *token () const;
  /** Get the last token of the syntactic construct represented by this sub-tree.
   *  \return The token or NULL. */
  
#line 519 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::Token * __exec_old_end_token() const;

#line 290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual Token *end_token () const;
  /** Get the CT_Token node of the first token of the syntactic construct represented by this sub-tree.
   *  \return The token node or NULL. */
  
#line 527 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::CT_Token * __exec_old_token_node() const;

#line 293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual CT_Token *token_node () const;
  /** Get the CT_Token node of the last token of the syntactic construct represented by this sub-tree.
   *  \return The token node or NULL. */
  
#line 535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::CT_Token * __exec_old_end_token_node() const;

#line 296 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual CT_Token *end_token_node () const;
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The son with which to replace. */
  virtual void ReplaceSon (CTree *old_son, CTree *new_son) {}
  /** Get the parent node.
   *  \return The parent node or NULL. */
  virtual CTree *Parent () const { return (CTree*)_parent; }

public: // semantic information
  /** Get the semantic type of the node.
   *  \return The type object or NULL. */
  virtual CTypeInfo *Type () const { return (CTypeInfo*)0; }
  /** Get the calculated value of the expression.
   *  \return The value object or NULL. */
  virtual CExprValue *Value () const { return (CExprValue*)0; }
  
  /** Get the scope opened by the node.
   *  \return The scope object or NULL. */
  virtual CSemScope *SemScope () const { return (CSemScope*)0; }
  /** Get the semantic value of the node.
   *  \return The value object or NULL. */
  virtual CSemValue *SemValue () const { return (CSemValue*)0; }
  /** Get the semantic information of the node.
   *  \return The semantic object or NULL. */
  virtual CSemObject *SemObject () const { return (CSemObject*)0; }
  
public: // node classification function
  /** Get a pointer to CT_SimpleName if the current node represents a name.
   *  \return The CT_SimpleName node or NULL. */
  virtual CT_SimpleName *IsSimpleName () { return 0; }
  /** Get a pointer to CT_String if the current node represents a string.
   *  \return The CT_String node or NULL. */
  virtual CT_String *IsString () { return 0; }
  /** Get a pointer to CT_Declarator if the current node represents a declarator.
   *  \return The CT_Declarator pointer or NULL. */
  virtual CT_Declarator *IsDeclarator () { return 0; }
  /** Get a pointer to CT_Statement if the current node represents a statement.
   *  \return The CT_Statement pointer or NULL. */
  virtual CT_Statement *IsStatement () { return 0; }
  /** Get a pointer to CT_Expression if the current node represents a expression.
   *  \return The CT_Expression pointer or NULL. */
  virtual CT_Expression *IsExpression () { return 0; }
  /** Get a pointer to CT_Decl if the current node represents a declaration.
   *  \return The CT_Decl pointer or NULL. */
  virtual CT_Decl *IsDeclaration () { return 0; }
  /** Get a pointer to CT_Call if the current node represents a call expression.
   *  \return The CT_Call pointer or NULL. */
  virtual CT_Call *IsCall () { return 0; }
  /** Get a pointer to CT_List if the current node represents a list.
   *  \return The CT_List pointer or NULL. */
  virtual CT_List *IsList () { return 0; }
  /** Get a pointer to CT_DelayedParse if the current node represents a delayed code fragment.
   *  \return The CT_DelayedParse pointer or NULL. */
  virtual CT_DelayedParse *IsDelayedParse () { return 0; }

public: // additional semantic information
  /** Return true if the tree has the constant value 0.
   *  \return True if constant value is 0. */
  bool HasValueNull () const;
   private:
  typedef CTree CCExprResolveCTree;

#line 32 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CTree CExprResolveCTree;

#line 32 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;   private:

#line 28 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 public :
typedef std :: list < CTree * > CTreeList ;
virtual CTreeList * gnu_prefix ( ) { return 0 ; }
virtual CTreeList * gnu_suffix ( ) { return 0 ; }
virtual CTreeList * gnu_infix ( ) { return 0 ; }
virtual const CTreeList * gnu_prefix ( ) const { return 0 ; }
virtual const CTreeList * gnu_suffix ( ) const { return 0 ; }
virtual const CTreeList * gnu_infix ( ) const { return 0 ; }
virtual int gnu_infix_pos ( ) const { return - 1 ; }};

/** \class CT_Error CTree.h Puma/CTree.h
 *  Error tree node that is inserted into the tree for syntactic constructs
 *  that could not be parsed. */

#line 626 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Error : public CTree {
#line 662 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 669 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
};

/** \class CT_Token CTree.h Puma/CTree.h
 *  Tree node representing a single token in the source code. */

#line 715 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 373 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Token : public CTree {
#line 751 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 373 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 758 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 373 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  Token *_token;
  unsigned long int _number;
  
public:
  /** Constructor. 
   *  \param token The represented token.
   *  \param number The token number (a consecutive number). */
  CT_Token (Token *token, unsigned long int number = 0) : 
    _token (token), _number (number) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the represented token. */
  Token *token () const { return _token; }
  /** Get the represented token. */
  Token *end_token () const { return _token; }
  /** Get this. */
  CT_Token *token_node () const { return (CT_Token*)this; }
  /** Get this. */
  CT_Token *end_token_node () const { return (CT_Token*)this; }
  /** Set the token number. 
   *  \param number The token number. */ 
  void Number (unsigned long int number) { _number = number; }
  /** Get the token number. Can be used to indentify this token. */
  unsigned long int Number () const { return _number; }
  
public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
};

/*****************************************************************************/
/*                                                                           */
/*                              List nodes                                   */
/*                                                                           */
/*****************************************************************************/

/** \class CT_List CTree.h Puma/CTree.h
 *  Base class for tree nodes representing lists. */

#line 837 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_List : public CTree {
#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 880 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  /** Son to index map type. */
  typedef std::map<CTree*,int> SonToIndexMap;

  Array<CTree*> _sons;
  int _properties;
  SonToIndexMap _son2idx;

protected:
  /** Constructor.
   *  \param size The initial list size.
   *  \param incr The initial increment count. 
   *  \param props The list properties (bit array). */
  CT_List(int size = 5, int incr = 5, int props = 0) : 
    _sons (size, incr), _properties (props) {}

public:
  /** %List properties. */
  enum {
    /** %List has a start token, like ':' in ":a(1),b(2)" */
    OPEN = 1,         
    /** %List has an end token */
    CLOSE = 2,        
    /** %List has opening and closing delimiters, like '(' and ')' */
    OPEN_CLOSE = 3,   
    /** %List has separators, like ',' */
    SEPARATORS = 4,   
    /** %List pretend to be empty, like for "(void)" */
    FORCE_EMPTY = 8,  
    /** %List has trailing separator, like "a,b,c," */
    END_SEP = 16,     
    /** %List has no separator before last element, like "(a,b...)" */
    NO_LAST_SEP = 32, 
    /** %List has an introduction chararacter, like "=" in "={a,b}" */
    INTRO = 64        
  };
 
  /** Get a pointer to this CT_List. */
  CT_List *IsList () { return this; }
  /** Get the number of list entries. */
  int Entries () const;
  /** Get the n-th list entry.
   *  \param n The index of the entry. 
   *  \return The list entry or NULL. */
  CTree *Entry (int n) const;
  /** Get the number of sons. */
  int Sons () const { return _sons.length (); }
  /** Get the n-th son.
   *  \param n The index of the son. 
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return _sons.lookup (n); }
  /** Get the index of the given son, or -1 if not found. */
  int Index (CTree *son);
  /** Get the list properties. */
  int GetProperties () const { return _properties; }
  /** Add a list property.
   *  \param p The property to add. */
  void AddProperties (int p) { _properties |= p; }
  /** Add a son.
   *  \param s The son to add. */
  void AddSon (CTree *s);
  /** Prepend a son.
   *  \param s The son to prepend. */
  void PrefixSon (CTree *s);
  /** Insert a son before another son.
   *  \param before The son to insert the new son before.
   *  \param son The son to insert. */
  void InsertSon (CTree *before, CTree *son); 
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son);
  /** Remove a son.
   *  \param son The son to remove. */
  void RemoveSon (CTree *son);
  /** Insert a son at the given index. 
   *  \param idx The index at which to insert.
   *  \param s The son to insert. */
  void InsertSon (int idx, CTree *s);
  /** Replace the son at the given index.
   *  \param idx The index of the son to replace.
   *  \param s The new son. */
  void ReplaceSon (int idx, CTree *s);
  /** Remove the son at the given index. 
   *  \param idx The index of the son to remove. */
  void RemoveSon (int idx);
};

/** \class CT_ExprList CTree.h Puma/CTree.h
 *  Tree node representing an expression list. */

#line 1004 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ExprList : public CT_List, public CSemValue, public CSemObject {
#line 1040 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1047 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_ExprList () { AddProperties (SEPARATORS); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the last expression in the expression list.
   *  \return The type or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the last expression in the expression list.
   *  \return The value of NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value of the node. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get the semantic information about the node. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
};

/** \class CT_DeclaratorList CTree.h Puma/CTree.h
 *  Tree node representing a list of declarators. */

#line 1104 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclaratorList : public CT_List {
#line 1140 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1147 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_DeclaratorList () { AddProperties (SEPARATORS); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_EnumeratorList CTree.h Puma/CTree.h
 *  Tree node representing a list of enumerator constants. */

#line 1193 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_EnumeratorList : public CT_List {
#line 1229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1236 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_EnumeratorList () { AddProperties (SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};
   
/** \class CT_DeclList CTree.h Puma/CTree.h
 *  Tree node representing a list of declarations. */

#line 1282 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 555 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclList : public CT_List {
#line 1318 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 555 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1325 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 555 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. 
   *  \param size The initial size of the list.
   *  \param incr The initial increment count of the list. */
  CT_DeclList (int size = 20, int incr = 20) : CT_List (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Set the linkage specifiers to each declaration in the list.
   *  \param l The linkage specifiers node. */
  void Linkage (CT_LinkageSpec *l);
};

/** \class CT_DeclSpecSeq CTree.h Puma/CTree.h
 *  Tree node representing a sequence of declaration specifiers. */

#line 1376 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 572 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 572 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclSpecSeq : public CT_List {
#line 1423 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 572 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 572 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }};

/** \class CT_CmpdStmt CTree.h Puma/CTree.h
 *  Tree node representing a compound statement. */

#line 1480 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CmpdStmt : public CT_List, public CSemScope {
#line 1516 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1523 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 582 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /* Constructor. */
  CT_CmpdStmt () { AddProperties (OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the compound statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_HandlerSeq CTree.h Puma/CTree.h
 *  Tree node representing an exception handler sequence. */

#line 1571 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_HandlerSeq : public CT_List {
#line 1607 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 596 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_TemplateParamList CTree.h Puma/CTree.h
 *  Tree node representing a template parameter list. */

#line 1658 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 606 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateParamList : public CT_List, public CSemScope {
#line 1694 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 606 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1701 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 606 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  CT_TemplateParamList () { AddProperties (INTRO | SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the template parameter list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_TemplateArgList CTree.h Puma/CTree.h
 *  Tree node representing a template argument list. */

#line 1748 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateArgList : public CT_List {
#line 1784 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1791 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_TemplateArgList () { AddProperties (SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_ExtensionList CTree.h Puma/CTree.h
 *  Tree node representing a sequence of compiler specific extensions such
 *  as __attribute__((...)) nodes. */

#line 1838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ExtensionList : public CT_List {
#line 1874 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1881 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/*****************************************************************************/
/*                                                                           */
/*                              Expressions                                  */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Expression CTree.h Puma/CTree.h
 *  Base class for all expression tree nodes. */

#line 1931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1967 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1978 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Expression : public CTree, public CSemValue {
#line 2000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2007 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_Expression () {}

  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the type of the expression.
   *  \return The type information object or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the expression.
   *  \return The value object or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information of the expression.
   *  \return The value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get this. */
  virtual CT_Expression *IsExpression () { return this; }
   private:
  typedef CT_Expression CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Expression CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_Call CTree.h Puma/CTree.h
 *  Tree node representing explicit or implicit function calls 
 *  including built-in or user-defined functions and overloaded
 *  operators. */

#line 2085 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2121 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2132 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Call : public CT_Expression, public CSemObject {
#line 2143 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2150 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_Call () {}
  
public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the semantic information of the call. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get this. */
  CT_Call *IsCall () { return this; }
   private:
  typedef CT_Call CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Call CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ImplicitCall CTree.h Puma/CTree.h
 *  Tree node representing implicit function calls detected by
 *  the semantic analysis. 
 *  Example:
 *  \code
 * class Number {
 *   int _n;
 * public:
 *   Number(int n) : _n(n) {}
 *   int operator+(const Number& n) { return n._n + _n; }
 * };
 *     
 * Number one(1), two(2);
 * one + two;  // implicitely calls one.operator+(two)
 *  \endcode */

#line 2225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2261 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2272 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ImplicitCall : public CT_Call {
#line 2283 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_arg;

public:
  /** Constructor.
   *  \param arg The call argument. */
  CT_ImplicitCall (CTree *arg) { AddSon (_arg, arg); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _arg : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_arg, old_son, new_son); }
   private:
  typedef CT_ImplicitCall CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ImplicitCall CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_String CTree.h Puma/CTree.h
 *  Tree node representing a string literal. 
 *  Example: \code "abc" \endcode */

#line 2361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2397 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2408 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_String : public CT_List, public CSemValue {
#line 2419 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2426 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 734 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. 
   *  \param size The number of sub-strings. */
  CT_String (int size) : CT_List (size, 1) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the string. 
   *  \return The type or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the string value.
   *  \return The value or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value info object.
   *  \return The semantic value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get this. */
  virtual CT_String *IsString () { return this; }
   private:
  typedef CT_String CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_String CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_WideString CTree.h Puma/CTree.h
 *  Tree node representing a wide string literal. 
 *  Example: \code L"abc" \endcode */

#line 2496 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2532 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_WideString : public CT_String {
#line 2554 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2561 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The number of sub-strings. */
  CT_WideString (int size) : CT_String (size) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_WideString CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_WideString CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_Integer CTree.h Puma/CTree.h
 *  Tree node representing an integer constant. 
 *  Example: \code 1234 \endcode */

#line 2619 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2655 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2666 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Integer : public CT_Expression {
#line 2677 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2684 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 774 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the integer value. */
  CT_Integer (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return _value ? 1 : 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
   private:
  typedef CT_Integer CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Integer CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_Character CTree.h Puma/CTree.h
 *  Tree node representing a single character constant. 
 *  Example: \code 'a' \endcode */

#line 2755 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2791 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2802 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Character : public CT_Expression {
#line 2813 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the character value. */
  CT_Character (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
   private:
  typedef CT_Character CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Character CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_WideCharacter CTree.h Puma/CTree.h
 *  Tree node representing a wide character constant. 
 *  Example: \code L'a' \endcode */

#line 2891 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 828 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2927 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 828 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2938 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 828 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_WideCharacter : public CT_Character {
#line 2949 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 828 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2956 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 828 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param token The token containing the wide character value. */
  CT_WideCharacter (CTree *token) : CT_Character (token) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_WideCharacter CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_WideCharacter CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_Float CTree.h Puma/CTree.h
 *  Tree node representing a floating point constant. 
 *  Example: \code 12.34 \endcode */

#line 3014 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3050 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3061 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Float : public CT_Expression {
#line 3072 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3079 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 842 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the floating point value. */
  CT_Float (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
   private:
  typedef CT_Float CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Float CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_Bool CTree.h Puma/CTree.h
 *  Tree node representing a boolean literal. 
 *  Examples: 
 *  \code 
 * true
 * false
 *  \endcode */

#line 3154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3201 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Bool : public CT_Expression {
#line 3212 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3219 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 873 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the boolean value. */
  CT_Bool (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
   private:
  typedef CT_Bool CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_Bool CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_BracedExpr CTree.h Puma/CTree.h
 *  Tree node representing a braced expression.
 *  Example: \code (a+b) \endcode */

#line 3290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3326 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3337 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BracedExpr : public CT_Expression {
#line 3348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3355 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // open, expr, close

public:
  /** Constructor.
   *  \param o The opening brace.
   *  \param e The enclosed expression.
   *  \param c The closing brace. */
  CT_BracedExpr (CTree *o, CTree *e, CTree *c) { 
    AddSon (sons[0], o); AddSon (sons[1], e); AddSon (sons[2], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the enclosed expression. */
  CTree *Expr () const { return sons[1]; }
  /** Get the semantic value of the expression. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:
  typedef CT_BracedExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_BracedExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_SimpleName CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing a name. 
 *  Example: \code a \endcode */

#line 3435 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3471 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3482 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3493 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SimpleName : public CT_List, public Printable, 
                      public CSemValue, public CSemObject {
#line 3505 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 937 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3512 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 937 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). */
  CT_SimpleName (int size) : CT_List (size, 1) {}
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). 
   *  \param properties Additional name list properties (for root qualified names). */
  CT_SimpleName (int size, int properties) : 
    CT_List (size, 2, properties) {}
  
public:
  /** Constructor.
   *  \param n The sub-tree containing the name. */
  CT_SimpleName (CTree *n) : CT_List (1, 1) { AddSon (n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the string containing the name. */
  virtual const char *Text () const 
   { return Son (Sons ()-1)->token ()->text (); }
  /** Print the name on the given stream. 
   *  \param os The output stream. */
  virtual void print (ostream &os) const { os << Text (); }
  /** Get this. */
  virtual CT_SimpleName *Name () const { return (CT_SimpleName*)this; }
  /** Get the type of the entity represented by the name. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the entity represented by the name. */ 
  CExprValue *Value () const { return value; }
  /** Get the sematic value information of the name. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get the sematic information about the name. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get this. */
  virtual CT_SimpleName *IsSimpleName () { return this; }  

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_SimpleName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_SimpleName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_SpecialName CTree.h Puma/CTree.h
 *  Base class for tree nodes representing a special name, like destructor names. */

#line 3615 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3662 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SpecialName : public CT_SimpleName {
#line 3673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3680 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  char *_name;
  
protected:
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). */
  CT_SpecialName (int size = 1) : CT_SimpleName (size), _name (0) {}
  
public:
  /** Destructor. Deletes the name string. */
  ~CT_SpecialName () { if (_name) delete[] _name; }
  /** Get the string containing the name. */
  const char *Text () const { return _name; }
  /** Set the name. The name is copied.
   *  \param n The name. */
  void Name (const char *n) { 
    if (n) { 
      _name = new char[strlen(n) + 1];
      strcpy (_name,n);
    }
  }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_SpecialName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_SpecialName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_PrivateName CTree.h Puma/CTree.h
 *  Tree node representing a private name. Private names 
 *  are generated names for instance for abstract declarators.
 *  Example: 
 *  \code 
 * void foo(int*);  // first parameter of foo has private name
 *  \endcode */

#line 3760 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1020 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3796 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1020 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3807 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1020 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PrivateName : public CT_SpecialName {
#line 3818 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1020 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3825 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1020 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param n The private (generated) name. */
  CT_PrivateName (const char *n) { Name (n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (CTree*)0; }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_PrivateName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_PrivateName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_DestructorName CTree.h Puma/CTree.h
 *  Tree node representing a destructor name.
 *  Example: \code ~X \endcode */

#line 3895 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3931 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3942 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DestructorName : public CT_SpecialName {
#line 3953 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3960 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param t The tilde operator.
   *  \param n The class name. */
  CT_DestructorName (CTree *t, CTree *n);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_DestructorName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_DestructorName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_TemplateName CTree.h Puma/CTree.h
 *  Tree node representing a template name.
 *  Example: \code X<T> \endcode */

#line 4025 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4061 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4072 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateName : public CT_SpecialName {
#line 4083 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4090 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param n The template class or function name.
   *  \param a The template argument list. */
  CT_TemplateName (CTree *n, CTree *a) 
   { AddSon (n); AddSon (a); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the template argument list. */
  CT_TemplateArgList *Arguments () const 
   { return (CT_TemplateArgList*)Son (Sons ()-1); }
  /** Get the template class or function name. */
  CT_SimpleName *TemplateName () const 
   { return (CT_SimpleName*)Son (Sons ()-2); }
  // may change in the future
  const char *Text () const { return TemplateName ()->Text (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_TemplateName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_TemplateName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_OperatorName CTree.h Puma/CTree.h
 *  Tree node representing the name of an overloaded operator. 
 *  Example: \code operator== \endcode */

#line 4164 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4200 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_OperatorName : public CT_SpecialName {
#line 4222 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4229 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1097 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  int _oper;

public:
  /** Complex operator types. */
  enum { 
    FCT_CALL = -100,  /** Function call operator, i.e. (). */
    SUBSCRIPT,        /** Array subscript operator, i.e. []. */
    NEW_ARRAY,        /** New array operator, i.e. new[]. */
    DEL_ARRAY         /** Delete array operator, i.e. delete[]. */
  };
 
public:
  /** Constructor.
   *  \param op The token containing the operator. */
  CT_OperatorName (CTree *op);
  /** Constructor.
   *  \param f The operator function keyword 'operator'.
   *  \param op The token containing the operator. 
   *  \param o The token of '[' or '('.
   *  \param c The token of ']' or ')'. */
  CT_OperatorName (CTree *f, CTree *op, CTree *o, CTree *c);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the operator type (either the token type or one of 
   *  the complex operator types). */
  int Operator () const { return _oper; }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_OperatorName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_OperatorName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ConversionName CTree.h Puma/CTree.h
 *  Tree node representing the name of a conversion function.
 *  Example: \code operator int* \endcode */

#line 4313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4360 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConversionName : public CT_SpecialName {
#line 4371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4378 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param f The operator function keyword 'operator'.
   *  \param t The sub-tree containing the conversion type. */
  CT_ConversionName (CTree *f, CTree *t);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the conversion type. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)Son (Sons ()-1); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_ConversionName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ConversionName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_QualName CTree.h Puma/CTree.h
 *  Tree node representing a qualified name.
 *  Example: \code X::Y::Z \endcode */

#line 4445 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4481 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_QualName : public CT_SimpleName {
#line 4503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4510 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1160 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial number sub-names plus separators. */
  CT_QualName (int size = 3) : 
    CT_SimpleName (size, CT_List::SEPARATORS) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Print the qualified name on the given stream. 
   *  \param os The output stream. */
  void print (ostream &os) const;
  /** Get the last name of the qualified name, e.g. Z of qualified name X::Y::Z. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)Son (Sons ()-1); }
  /** Get the string containing the last name of the qualified name. */
  const char *Text () const { return Name ()->Text (); }
  /** Get the type of the last name. */
  CTypeInfo *Type () const { return Name ()->Type (); }
  /** Get the value of the last name. */
  CExprValue *Value () const { return Name ()->Value (); }
  /** Get the semantic value object of the last name. */
  CSemValue *SemValue () const { return Name ()->SemValue (); }
  /** Get the semantic information of the last name. */
  CSemObject *SemObject () const { return Name ()->SemObject (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_QualName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_QualName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_RootQualName CTree.h Puma/CTree.h
 *  Tree node representing a qualified name with introducing name separator.
 *  Example: \code ::X::Y::Z \endcode */

#line 4590 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4626 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4637 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_RootQualName : public CT_QualName {
#line 4648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4655 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size Initial number of sub-name plus separator. */
  CT_RootQualName (int size = 2) : 
    CT_QualName (size) { AddProperties (INTRO); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
   private:
  typedef CT_RootQualName CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_RootQualName CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_BinaryExpr CTree.h Puma/CTree.h
 *  Tree node representing a binary expression.
 *  Example: \code a+b \endcode */

#line 4720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4756 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4767 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BinaryExpr : public CT_Call {
#line 4778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4785 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // expr, oper, expr

public:
  /** Constructor. 
   *  \param l Left hand side of the expression. 
   *  \param o The operator token. 
   *  \param r Right hand side of the expression. */
  CT_BinaryExpr (CTree *l, CTree *o, CTree *r) {
    AddSon (sons[0], l); AddSon (sons[1], o); AddSon (sons[2], r);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:
  typedef CT_BinaryExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_BinaryExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_MembPtrExpr CTree.h Puma/CTree.h
 *  Tree node representing a member pointer expression.
 *  Example: \code a->b \endcode */

#line 4861 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4897 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4908 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembPtrExpr : public CT_Expression, public CSemObject {
#line 4919 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1249 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // expr, oper, expr
  
public:
  /** Constructor.
   *  \param e Expression on which to call the member.
   *  \param o The arrow operator token.
   *  \param i The member name. */
  CT_MembPtrExpr (CTree *e, CTree *o, CTree *i) {
    AddSon (sons[0], e); AddSon (sons[1], o); AddSon (sons[2], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:
  typedef CT_MembPtrExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_MembPtrExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_MembRefExpr CTree.h Puma/CTree.h
 *  Tree node representing a member reference expression.
 *  Example: \code a.b \endcode */

#line 5002 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5038 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5049 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembRefExpr : public CT_MembPtrExpr {
#line 5060 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5067 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param e Expression on which to call the member.
   *  \param o The dot operator.
   *  \param i The member name. */
  CT_MembRefExpr (CTree *e, CTree *o, CTree *i) :
    CT_MembPtrExpr (e, o, i) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_MembRefExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_MembRefExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_UnaryExpr CTree.h Puma/CTree.h
 *  Base class for tree nodes representing unary expressions. 
 *  Example: \code !a \endcode */

#line 5128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5164 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5175 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UnaryExpr : public CT_Call {
#line 5186 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5193 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1298 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // oper, expr

public:
  /** Constructor.
   *  \param o The unary operator.
   *  \param e The expression on which the operator is invoked. */
  CT_UnaryExpr (CTree *o, CTree *e) { AddSon (sons[0], o); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression node. */
  CTree *Expr () const { return sons[1]; }
   private:
  typedef CT_UnaryExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_UnaryExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_PostfixExpr CTree.h Puma/CTree.h
 *  Tree node representing a postfix expression.
 *  Example: \code a++ \endcode */

#line 5268 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5304 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5315 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PostfixExpr : public CT_UnaryExpr {
#line 5326 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5333 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param e The expression on which to invoke the operator. 
   *  \param o The postfix operator. */
  CT_PostfixExpr (CTree *e, CTree *o) :
    CT_UnaryExpr (e, o) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_PostfixExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_PostfixExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_AddrExpr CTree.h Puma/CTree.h
 *  Tree node representing an address expression.
 *  Example: \code &a \endcode */

#line 5393 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5429 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5440 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AddrExpr : public CT_UnaryExpr {
#line 5451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1345 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param o The address operator, i.e. '&'.
   *  \param e The expression from which to take the address. */
  CT_AddrExpr (CTree *o, CTree *e) :
    CT_UnaryExpr (o, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_AddrExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_AddrExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_DerefExpr CTree.h Puma/CTree.h
 *  Tree node representing a pointer dereferencing expression.
 *  Example: \code *a \endcode */

#line 5518 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5554 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5565 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DerefExpr : public CT_UnaryExpr {
#line 5576 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1361 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param o The dereferencing operator, i.e. '*'.
   *  \param e The expression to dereference. */
  CT_DerefExpr (CTree *o, CTree *e) :
    CT_UnaryExpr (o, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_DerefExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_DerefExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_DeleteExpr CTree.h Puma/CTree.h
 *  Tree node representing a delete expression.
 *  Example: \code delete a \endcode */

#line 5643 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5679 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5690 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeleteExpr : public CT_Expression, public CSemObject {
#line 5701 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5708 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1377 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // oper, expr

public:
  /** Constructor.
   *  \param op The delete operator.
   *  \param e The expression representing the object to delete. */
  CT_DeleteExpr (CTree *op, CTree *e) { AddSon (sons[0], op); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[1]; }
  /** Get the operator name, i.e. 'delete' or 'delete[]'. */
  CT_SimpleName *OperName () const { return (CT_SimpleName*)sons[0]; }
  /** Get the semantic information. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:
  typedef CT_DeleteExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_DeleteExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_NewExpr CTree.h Puma/CTree.h
 *  Tree node representing a new expression.
 *  Example: \code new A() \endcode */

#line 5787 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5823 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5834 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NewExpr : public CT_Expression, public CSemObject {
#line 5845 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5852 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1412 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // oper, placement, open, type, close, init

public:
  /** Constructor.
   *  \param op The new operator.
   *  \param p The optional placement expression.
   *  \param o The optional left parenthesis around the type identifier.
   *  \param t The type identifier specifying the type of the object to create.
   *  \param c The optional right parenthesis around the type identifier.
   *  \param i The optional initializer. */
  CT_NewExpr (CTree *op, CTree *p, CTree *o, CTree *t, CTree *c, CTree *i) {
    AddSon (sons[0], op); AddSon (sons[1], p); AddSon (sons[2], o); 
    AddSon (sons[3], t); AddSon (sons[4], c); AddSon (sons[5], i); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 6); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the operator name. */
  CT_SimpleName *OperName () const { return (CT_SimpleName*)sons[0]; }
  /** Get the placement expression. */
  CT_ExprList *Placement () const { return (CT_ExprList*)sons[1];; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[5]; }
  /** Get the type of the object to create. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[3]; }
  /** Get the semantic information. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:
  typedef CT_NewExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_NewExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_IfThenExpr CTree.h Puma/CTree.h
 *  Tree node representing an if-then expression.
 *  Example: \code a>0?a:b \endcode or \code a?:b \endcode */

#line 5942 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5978 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 5989 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IfThenExpr : public CT_Expression {
#line 6000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6007 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1458 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // cond, oper, left, colon, right

public:
  /** Constructor.
   *  \param c1 The condition expression.
   *  \param o The question mark operator. 
   *  \param l The expression to the left of the colon.
   *  \param c2 The colon operator.
   *  \param r The expression to the right of the colon. */ 
  CT_IfThenExpr (CTree *c1, CTree *o, CTree *l, CTree *c2, CTree *r) {
    AddSon (sons[0], c1); AddSon (sons[1], o); AddSon (sons[2], l); 
    AddSon (sons[3], c2); AddSon (sons[4], r);
  }
  /** Constructor.
   *  \param c1 The condition expression.
   *  \param o The question mark operator. 
   *  \param c2 The colon operator.
   *  \param r The expression to the right of the colon. */ 
  CT_IfThenExpr (CTree *c1, CTree *o, CTree *c2, CTree *r) {
    AddSon (sons[0], c1); AddSon (sons[1], o); AddSon (sons[2], 0); 
    AddSon (sons[3], c2); AddSon (sons[4], r);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the condition expression. */
  CTree *Condition () const { return sons[0]; }
  /** Get the left expression (condition=true). */
  CTree *LeftOperand () const { return sons[2]; }
  /** Get the right expression (condition=false). */
  CTree *RightOperand () const { return sons[4]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
   private:
  typedef CT_IfThenExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_IfThenExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_CmpdLiteral CTree.h Puma/CTree.h
 *  Tree node representing a compound literal.
 *  Example: \code (int[]){1,2,3) \endcode */

#line 6101 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6137 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6148 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CmpdLiteral : public CT_Expression, public CSemObject {
#line 6159 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6166 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1508 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, type, close, init

public:
  /** Constructor.
   *  \param r Left parenthesis of the type name.
   *  \param t The type name.
   *  \param cr Right parenthesis of the type name.
   *  \param i The initializer list. */
  CT_CmpdLiteral (CTree *r, CTree *t, CTree *cr, CTree *i) {
    AddSon (sons[0], r); AddSon (sons[1], t); 
    AddSon (sons[2], cr); AddSon (sons[3], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[1]; }
  /** Get the initializer list. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[3]; }
  /** Get the semantic information about the created object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:
  typedef CT_CmpdLiteral CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_CmpdLiteral CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ConstructExpr CTree.h Puma/CTree.h
 *  Tree node representing a construct expression.
 *  Example: \code std::string("abc") \endcode */

#line 6250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6286 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6297 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConstructExpr : public CT_Expression, public CSemObject {
#line 6308 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6315 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // type, init

public:
  /** Constructor.
   *  \param t The type name.
   *  \param i The initializer list. */
  CT_ConstructExpr (CTree *t, CTree *i) { AddSon (sons[0], t); AddSon (sons[1], i); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the created object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:
  typedef CT_ConstructExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ConstructExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ThrowExpr CTree.h Puma/CTree.h
 *  Tree node representing a throw expression.
 *  Example: \code throw std::exception() \endcode */

#line 6394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ThrowExpr : public CT_Expression {
#line 6452 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6459 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1583 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // throw, expr

public:
  /** Constructor.
   *  \param t The 'throw' keyword.
   *  \param e The expression. */
  CT_ThrowExpr (CTree *t, CTree *e = (CTree*)0) { AddSon (sons[0], t); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[1]; }
   private:
  typedef CT_ThrowExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ThrowExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_IndexExpr CTree.h Puma/CTree.h
 *  Tree node representing an index expression. 
 *  Example: \code a[1] \endcode */

#line 6534 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6570 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6581 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IndexExpr : public CT_Call {
#line 6592 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6599 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1614 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // expr, open, index, close

public:
  /** Constructor.
   *  \param e The expression on which to invoke the index operator.
   *  \param o Left parenthesis of the index expression.
   *  \param i The index expression. 
   *  \param c Right parenthesis of the index expression. */
  CT_IndexExpr (CTree *e, CTree *o, CTree *i, CTree *c) {
    AddSon (sons[0], e); AddSon (sons[1], o); 
    AddSon (sons[2], i); AddSon (sons[3], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
   private:
  typedef CT_IndexExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_IndexExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_CallExpr CTree.h Puma/CTree.h
 *  Tree node representing a function call expression.
 *  Example: \code f(i) \endcode */

#line 6677 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6713 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6724 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CallExpr : public CT_Call {
#line 6735 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6742 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // expr, args

public:
  /** Constructor.
   *  \param e The expression on which the call is invoked. */
  CT_CallExpr (CTree *e) { AddSon (sons[0], e); AddSon (sons[1], 0); }
  /** Constructor.
   *  \param e The expression on which the call is invoked.
   *  \param l The argument list of the call. */
  CT_CallExpr (CTree *e, CTree *l) { AddSon (sons[0], e); AddSon (sons[1], l); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); } 
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  CTree *Expr () const { return sons[0]; }
  CT_ExprList *Arguments () const { return (CT_ExprList*)sons[1]; }
   private:
  typedef CT_CallExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_CallExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_CastExpr CTree.h Puma/CTree.h
 *  Tree node representing a cast expression.
 *  Example: \code (int)a \endcode */

#line 6820 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6856 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CastExpr : public CT_Expression {
#line 6878 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 6885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, type, close, expr

public:
  /** Constructor.
   *  \param o Left parenthesis of the type name.
   *  \param t The type to cast to.
   *  \param c Right parenthesis of the type name. 
   *  \param e The expression to cast. */
  CT_CastExpr (CTree *o, CTree *t, CTree *c, CTree *e) {
    AddSon (sons[0], o); AddSon (sons[1], t); 
    AddSon (sons[2], c); AddSon (sons[3], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the casted expression. */
  CTree *Expr () const { return sons[3]; }
  /** Get the type to cast to. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[1]; }
   private:
  typedef CT_CastExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_CastExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_StaticCast CTree.h Puma/CTree.h
 *  Tree node representing a static cast.
 *  Example: \code static_cast<int>(a) \endcode */

#line 6967 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7003 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7014 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_StaticCast : public CT_Expression {
#line 7025 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7032 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // cast, open, type, close, expr

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'static_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_StaticCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) {
    AddSon (sons[0], cst); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the casted expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type to cast to. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
   private:
  typedef CT_StaticCast CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_StaticCast CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ConstCast CTree.h Puma/CTree.h
 *  Tree node representing a const cast.
 *  Example: \code const_cast<int>(a) \endcode */

#line 7115 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1759 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7151 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1759 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1759 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConstCast : public CT_StaticCast {
#line 7173 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1759 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7180 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1759 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'const_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_ConstCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_ConstCast CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ConstCast CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ReintCast CTree.h Puma/CTree.h
 *  Tree node representing a reinterpret cast.
 *  Example: \code reinterpret_cast<int>(a) \endcode */

#line 7243 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7279 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ReintCast : public CT_StaticCast {
#line 7301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7308 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1778 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'reinterpret_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_ReintCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_ReintCast CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ReintCast CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_DynamicCast CTree.h Puma/CTree.h
 *  Tree node representing a dynamic cast.
 *  Example: \code dynamic_cast<int>(a) \endcode */

#line 7371 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1797 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7407 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1797 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7418 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1797 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DynamicCast : public CT_StaticCast {
#line 7429 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1797 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7436 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1797 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'dynamic_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_DynamicCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:
  typedef CT_DynamicCast CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_DynamicCast CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_ImplicitCast CTree.h Puma/CTree.h
 *  Tree node representing an implicit cast.
 *  Example: 
 *  \code 
 * int i = 1.2;  // implicit cast from float to int 
 *  \endcode */

#line 7502 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7538 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7549 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ImplicitCast : public CT_Expression {
#line 7560 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7567 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_expr; // casted expression

public:
  /** Constructor.
   *  \param e The expression that is implicitely casted. */
  CT_ImplicitCast (CTree *e) { AddSon (_expr, e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return n == 0 ? _expr : (CTree*)0; }
  /** Get the casted expression. */
  CTree *Expr () const { return _expr; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_expr, old_son, new_son); }
   private:
  typedef CT_ImplicitCast CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_ImplicitCast CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_TypeidExpr CTree.h Puma/CTree.h
 *  Tree node representing a typeid expression.
 *  Example: \code typeid(X) \endcode */

#line 7640 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7676 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7687 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TypeidExpr : public CT_Expression {
#line 7698 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7705 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1848 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // typeid, open, type_id/expr, close

public:
  /** Constructor.
   *  \param tid The 'typeid' operator.
   *  \param o The left parenthesis of the type name or expression.
   *  \param e The expression or type name for which to get the type identifier.
   *  \param c The right parenthesis of the type name or expression. */
  CT_TypeidExpr (CTree *tid, CTree *o, CTree *e, CTree *c) {
    AddSon (sons[0], tid); AddSon (sons[1], o); 
    AddSon (sons[2], e); AddSon (sons[3], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the typeid argument, i.e. the expression or type name for
   *  which to get the type identifier. */
  CTree *Arg () const { return sons[2]; }
   private:
  typedef CT_TypeidExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_TypeidExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_SizeofExpr CTree.h Puma/CTree.h
 *  Tree node representing a sizeof expression.
 *  Example: \code sizeof(int*) \endcode */

#line 7786 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7822 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7833 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SizeofExpr : public CT_Expression {
#line 7844 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7851 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1885 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, type, close, expr

public:
  /** Constructor.
   *  \param k The 'sizeof' keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the size.
   *  \param c Right parenthesis around the type name. */
  CT_SizeofExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], 0);
  }
  /** Constructor.
   *  \param k The 'sizeof' keyword.
   *  \param e The expression from which to get the size. */
  CT_SizeofExpr (CTree *k, CTree *e) {
    AddSon (sons[0], k); AddSon (sons[1], 0); AddSon (sons[2], 0); 
    AddSon (sons[3], 0); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
   private:
  typedef CT_SizeofExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_SizeofExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_AlignofExpr CTree.h Puma/CTree.h
 *  Tree node representing an alignof expression.
 *  Example: \code __alignof(int) \endcode */

#line 7940 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7976 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 7987 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AlignofExpr : public CT_Expression {
#line 7998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8005 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, type, close, expr

public:
  /** Constructor.
   *  \param k The 'alignof' keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the alignment.
   *  \param c Right parenthesis around the type name. */
  CT_AlignofExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], 0);
  }
  /** Constructor.
   *  \param k The 'alignof' keyword.
   *  \param e The expression from which to get the alignment. */
  CT_AlignofExpr (CTree *k, CTree *e) {
    AddSon (sons[0], k); AddSon (sons[1], 0); AddSon (sons[2], 0); 
    AddSon (sons[3], 0); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
   private:
  typedef CT_AlignofExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_AlignofExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_TypeTraitExpr CTree.h Puma/CTree.h
 *  Tree node representing an type trait expression.
 *  Example: \code __is_enum(E) \endcode */

#line 8094 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8130 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8141 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TypeTraitExpr : public CT_Expression {
#line 8152 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8159 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1975 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // key, open, type, comma, type, close

public:
  /** Constructor.
   *  \param k The type trait keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the trait.
   *  \param c Right parenthesis around the type name. */
  CT_TypeTraitExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t);
    AddSon (sons[3], 0); AddSon (sons[4], 0); AddSon (sons[5], c);
  }
  /** Constructor.
   *  \param k The type trait keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t1 The first type from which to get the trait.
   *  \param cc The comma between the types.
   *  \param t2 The second type from which to get the trait.
   *  \param c Right parenthesis around the type name. */
  CT_TypeTraitExpr (CTree *k, CTree *o, CTree *t1, CTree *cc, CTree *t2, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t1);
    AddSon (sons[3], cc); AddSon (sons[4], t2); AddSon (sons[5], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 6); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the type trait operator. */
  int Operator () const { return sons[0]->token ()->type (); }
  /** Get the first type. */
  CT_NamedType *FirstType () const { return (CT_NamedType*)sons[2]; }
  /** Get the second type. */
  CT_NamedType *SecondType () const { return (CT_NamedType*)sons[4]; }
   private:
  typedef CT_TypeTraitExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_TypeTraitExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_OffsetofExpr CTree.h Puma/CTree.h
 *  Tree node representing an offsetof expression.
 *  Example: \code offsetof(Circle,radius) \endcode */

#line 8254 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8290 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_OffsetofExpr : public CT_Expression {
#line 8312 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8319 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2026 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // key, open, type, comma, member, close

public:
  /** Constructor.
   *  \param k The 'offsetof' keyword.
   *  \param o Left parenthesis around the parameters.
   *  \param t The type containing the member.
   *  \param co The comma between type and member.
   *  \param m The member for which to get the offset.
   *  \param c Right parenthesis around the parameters. */
  CT_OffsetofExpr (CTree *k, CTree *o, CTree *t, CTree *co, CTree *m, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], co); AddSon (sons[4], m); AddSon (sons[5], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 6; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the typename. */
  CTree *TypeName () const { return sons[2]; }
  /** Get the member designator. */
  CT_DesignatorSeq *MemberDesignator () const { return (CT_DesignatorSeq*)sons[4]; }
   private:
  typedef CT_OffsetofExpr CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_OffsetofExpr CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_IndexDesignator CTree.h Puma/CTree.h
 *  Tree node representing an index designator.
 *  Example: \code [1] \endcode */

#line 8403 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2066 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8439 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2066 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8450 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2066 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IndexDesignator : public CT_Expression {
#line 8461 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2066 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8468 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2066 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // open, index, close

public:
  /** Constructor.
   *  \param o Left bracket of the index designator.
   *  \param i The index expression.
   *  \param c Right bracket of the index designator. */
  CT_IndexDesignator (CTree *o, CTree *i, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], i); AddSon (sons[2], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:
  typedef CT_IndexDesignator CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_IndexDesignator CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_MembDesignator CTree.h Puma/CTree.h
 *  Tree node representing a member designator.
 *  Example: \code .a \endcode */

#line 8544 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8580 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8591 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembDesignator : public CT_Expression {
#line 8602 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8609 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // dot, member

public:
  /** Constructor.
   *  \param d The dot before the member name.
   *  \param m The member name. */
  CT_MembDesignator (CTree *d, CTree *m) { AddSon (sons[0], d); AddSon (sons[1], m); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
   private:
  typedef CT_MembDesignator CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_MembDesignator CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_DesignatorSeq CTree.h Puma/CTree.h
 *  Tree node representing a designator sequence.
 *  Example: \code .a.b.c \endcode */

#line 8682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2127 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DesignatorSeq : public CT_List, public CSemValue {
#line 8718 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2127 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8725 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2127 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size Initial number of designators. */
  CT_DesignatorSeq (int size = 1) : CT_List (size, 2) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the entity to initialize. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the entity to initialize. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
};

/*****************************************************************************/
/*                                                                           */
/*                         Declaration specifiers                            */
/*                                                                           */
/*****************************************************************************/

/** \class CT_DeclSpec CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declaration specifiers. */

#line 8785 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2153 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8821 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2153 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclSpec : public CTree {
#line 8832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2153 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8839 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2153 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_DeclSpec () {}
   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_PrimDeclSpec CTree.h Puma/CTree.h
 *  Tree node representing a primitive declaration specifier. */

#line 8893 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PrimDeclSpec : public CT_DeclSpec {
#line 8929 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 8936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2161 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Declaration specifier types. */
  enum Type { 
    PDS_FRIEND,    /** friend */
    PDS_TYPEDEF,   /** typedef */
    PDS_AUTO,      /** auto */
    PDS_REGISTER,  /** register */
    PDS_STATIC,    /** static */
    PDS_EXTERN,    /** extern */
    PDS_MUTABLE,   /** mutable */
    PDS_INLINE,    /** inline */
    PDS_VIRTUAL,   /** virtual */
    PDS_EXPLICIT,  /** explicit */
    PDS_CONST,     /** const */
    PDS_VOLATILE,  /** volatile */
    PDS_RESTRICT,  /** restrict */
    PDS_CHAR,      /** char */
    PDS_WCHAR_T,   /** wchar_t */
    PDS_BOOL,      /** bool */
    PDS_C_BOOL,    /** _Bool */
    PDS_SHORT,     /** short */
    PDS_INT,       /** int */
    PDS_LONG,      /** long */
    PDS_SIGNED,    /** signed */
    PDS_UNSIGNED,  /** unsigned */
    PDS_FLOAT,     /** float */
    PDS_DOUBLE,    /** double */
    PDS_VOID,      /** void */
    // GNU C++ specific storage specifier
    PDS_THREAD,    /** __thread */
    // AspectC++ specific type specifier
    PDS_UNKNOWN_T, /** unknown_t */
    // Win specific declaration specifiers
    PDS_CDECL,     /** __cdecl */
    PDS_STDCALL,   /** __stdcall */
    PDS_FASTCALL,  /** __fastcall */
    PDS_INT64,     /** __int64 */
    PDS_UNKNOWN,   /** Unknown declaration specifier. */
    PDS_NUM        /** Number of declaration specifier types. */
  };

private:
  Type _type;
  CTree *_token; // has to be a CT_Token

  void determine_type ();

public:
  /** Constructor.
   *  \param t The token containing the declaration specifier. */
  CT_PrimDeclSpec (CT_Token *t) { AddSon (_token, (CTree*)t); determine_type (); }
  /** Constructor.
   *  \param t The declaration specifier type. */
  CT_PrimDeclSpec (Type t) : _token (0) { _type = t; }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return _token ? 1 : 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const 
   { return (n == 0) ? _token : (CTree*)0; }
  /** Get the textual representation of the declaration specifier.
   *  \return The string representation or " ". */
  const char *SpecText () const 
   { return _token ? _token->token ()->text () : " "; }
  /** Get the declaration specifier type. */
  Type SpecType () const { return _type; }
  /** Number of declaration specifier types. */
  static const int NumTypes = PDS_NUM;
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (_token, (CTree*)old_son, (CTree*)new_son);
    determine_type ();
  }
};

/** \class CT_NamedType CTree.h Puma/CTree.h
 *  Tree node representing a named type.
 *  Example: \code (int*)a \endcode where int* is a 
 *  type with a generated name. */

#line 9057 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2248 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NamedType : public CT_DeclSpec, public CSemObject {
#line 9093 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2248 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9100 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2248 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // declspecs, declarator

public:
  /** Constructor.
   *  \param dss The declaration specifier sequence of the type.
   *  \param d The type declarator. */
  CT_NamedType (CTree *dss, CTree *d) { AddSon (sons[0], dss); AddSon (sons[1], d); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the semantic information about the created temporary object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
};
      
/** \class CT_ClassSpec CTree.h Puma/CTree.h
 *  Tree node representing a class specifier.
 *  Example: \code class X \endcode */

#line 9167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9203 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ClassSpec : public CT_DeclSpec, public CSemObject {
#line 9214 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9221 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2281 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, name
  
public:
  /** Constructor.
   *  \param k The 'class' or 'struct' keyword.
   *  \param n The class name. */
  CT_ClassSpec (CTree *k, CTree *n) { AddSon (sons[0], k); AddSon (sons[1], n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); } 
  /** Get the class name. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Get the semantic information about the class. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
   private:

#line 129 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }};

/** \class CT_UnionSpec CTree.h Puma/CTree.h
 *  Tree node representing a union specifier.
 *  Example: \code union X \endcode */

#line 9295 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2314 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UnionSpec : public CT_ClassSpec {
#line 9331 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2314 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2314 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The 'union' keyword.
   *  \param n The name of the union. */
  CT_UnionSpec (CTree *k, CTree *n) : CT_ClassSpec (k, n) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_EnumSpec CTree.h Puma/CTree.h
 *  Tree node representing an enumeration specifier.
 *  Example: \code enum X \endcode */

#line 9387 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9423 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_EnumSpec : public CT_ClassSpec {
#line 9434 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9441 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2329 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The 'enum' keyword. 
   *  \param n The name of the enumeration. */
  CT_EnumSpec (CTree *k, CTree *n) : CT_ClassSpec (k, n) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
   private:

#line 129 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }};

/** \class CT_ExceptionSpec CTree.h Puma/CTree.h
 *  Tree node representing an exception specifier.
 *  Example: \code throw(std::exception) \endcode */

#line 9497 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ExceptionSpec : public CT_DeclSpec {
#line 9533 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9540 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2344 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // throw, type_id_list
  
public:
  /** Constructor.
   *  \param k The 'throw' keyword.
   *  \param l The type list for the exception type to throw. */
  CT_ExceptionSpec (CTree *k, CTree *l) { AddSon (sons[0], k); AddSon (sons[1], l); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the exception type list. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/*****************************************************************************/
/*                                                                           */
/*                              Declarations                                 */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Decl CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declarations. */

#line 9610 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Decl : public CTree {
#line 9646 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9653 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2380 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
 
  CT_LinkageSpec *_linkage;
  
protected:
  /** Constructor. */
  CT_Decl () : _linkage (0) {}
  
public:
  /** Set the linkage of the declared entity.
   *  \param l The linkage specifiers. */
  void Linkage (CT_LinkageSpec *l) { _linkage = l; }
  /** Get the linkage specifiers. */
  CT_LinkageSpec *Linkage () const { return _linkage; }
  /** Get this. */
  virtual CT_Decl *IsDeclaration () { return this; }
};

/** \class CT_Program CTree.h Puma/CTree.h
 *  Root node of C/C++ syntax trees. */

#line 9706 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Program : public CT_DeclList, public CSemScope {
#line 9742 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9749 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2399 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial number of declarations in the program.
   *  \param incr The initial increment count. */
  CT_Program (int size = 20, int incr = 20) : CT_DeclList (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the top scope. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};
   
/** \class CT_ObjDecl CTree.h Puma/CTree.h
 *  Tree node representing an object declaration.
 *  Example: \code int *i \endcode */

#line 9800 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2416 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9836 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2416 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ObjDecl : public CT_Decl {
#line 9847 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2416 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9854 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2416 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarators, colon

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param dl The declarator list.
   *  \param c Optional colon. */
  CT_ObjDecl (CTree *dsl, CTree *dl, CTree *c) {
    AddSon (sons[0], dsl); AddSon (sons[1], dl); AddSon (sons[2], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the declarator list. */
  CT_DeclaratorList *Declarators () const { return (CT_DeclaratorList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_TemplateDecl CTree.h Puma/CTree.h
 *  Tree node representing a template declaration. */

#line 9929 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9965 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateDecl : public CT_Decl, public CSemScope {
#line 9976 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 9983 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // export, param_list, decl

public:
  /** Constructor.
   *  \param e Optional 'export' keyword. 
   *  \param p The template parameter list.
   *  \param d The class or function declaration. */
  CT_TemplateDecl (CTree *e, CTree *p, CTree *d) {
    AddSon (sons[0], e); AddSon (sons[1], p); AddSon (sons[2], d);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son); 
  }
  /** Get the 'export' keyword. */
  CTree *Export () const { return sons[0]; }
  /** Get the template parameter list. */
  CT_TemplateParamList *Parameters () const { 
    return (CT_TemplateParamList*)sons[1]; 
  }
  /** Get the class or function declaration. */
  CTree *Declaration () const { return sons[2]; }
  /** Get the scope opened by the template declaration. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_TemplateParamDecl CTree.h Puma/CTree.h
 *  Base class for all tree nodesrepresenting a template parameter declaration. */

#line 10064 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateParamDecl : public CT_Decl, public CSemObject {
#line 10100 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_TemplateParamDecl () {}
  
public:
  /** Get the template default argument. */
  virtual CT_ExprList *DefaultArgument () const = 0;
  /** Get the semantic information about the template parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
};

/** \class CT_NonTypeParamDecl CTree.h Puma/CTree.h
 *  Tree node representing a template non-type parameter declaration. */

#line 10155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2506 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NonTypeParamDecl : public CT_TemplateParamDecl {
#line 10191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2506 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10198 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2506 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarator, init

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param d The parameter declarator.
   *  \param i The default template argument. */
  CT_NonTypeParamDecl (CTree *dsl, CTree *d, CTree *i = (CTree*)0) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); AddSon (sons[2], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the parameter declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the default template argument. */
  CT_ExprList *DefaultArgument () const { return (CT_ExprList*)sons[2]; }
  /** Get the semantic information about the template parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the default template argument. 
   *  \param i The default argument. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_TypeParamDecl CTree.h Puma/CTree.h
 *  Tree node representing a template type parameter declaration. */

#line 10274 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TypeParamDecl : public CT_TemplateParamDecl {
#line 10310 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10317 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // params, key, id, init

public:
  /** Constructor.
   *  \param pl The template parameter list of an template template parameter.
   *  \param k The type keyword, i.e. 'class' or 'typename'.
   *  \param id The parameter identifier.
   *  \param i The default template argument. */
  CT_TypeParamDecl (CTree *pl, CTree *k, CTree *id, CTree *i = (CTree*)0) { 
    AddSon (sons[0], pl); AddSon (sons[1], k); 
    AddSon (sons[2], id); AddSon (sons[3], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the template parameter list of a template template parameter. */
  CT_TemplateParamList *Parameters () const { 
    return (CT_TemplateParamList*)sons[0]; 
  }
  /** Get the templare parameter name. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Get the template default argument. */
  CT_ExprList *DefaultArgument () const { return (CT_ExprList*)sons[3]; }
  /** Set the template default argument.
   *  \param i The default argument. */
  void Initializer (CTree *i) { AddSon (sons[3], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_EnumDef CTree.h Puma/CTree.h
 *  Tree node representing the definition of an enumeration. 
 *  Example: \code enum E { A, B, C } \endcode */

#line 10396 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10432 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_EnumDef : public CT_Decl, public CSemObject {
#line 10443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10450 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2593 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, name, enumerators

public:
  /** Constructor.
   *  \param k The keyword 'enum'.
   *  \param n The name of the enumeration. */
  CT_EnumDef (CTree *k, CTree *n) {
    AddSon (sons[0], k); AddSon (sons[1], n); AddSon (sons[2], 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the name of the enumeration. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Set the list of enumeration constants.
   *  \param el The enumerator list. */
  void Enumerators (CTree *el) { AddSon (sons[2], el); }
  /** Get the list of enumeration constants. */
  CT_EnumeratorList *Enumerators () const { return (CT_EnumeratorList*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
  /** Get the semantic information about the enumeration. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }   private:

#line 129 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }};

/** \class CT_Enumerator CTree.h Puma/CTree.h
 *  Tree node representing a single enumeration constant. */

#line 10542 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Enumerator : public CT_Decl, public CSemObject {
#line 10578 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10585 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2632 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, init

public:
  /** Constructor.
   *  \param n The name of the enumerator. */
  CT_Enumerator (CTree *n) { AddSon (sons[0], n); AddSon (sons[1], 0); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the name of the enumerator. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Set the initializer expression of the enumerator. */
  void Initializer (CTree *i) { AddSon (sons[1], i); }
  /** Get the initializer expression of the enumerator. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son); 
  }
  /** Get the semantic information about the enumerator. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
};

/** \class CT_FctDef CTree.h Puma/CTree.h
 *  Tree node representing a function definition. 
 *  Example:
 *  \code
 * int mul(int x, int y) {
 *   return x*y;
 * }
 *  \endcode */

#line 10660 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10696 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_FctDef : public CT_Decl, public CSemObject {
#line 10707 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10714 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2673 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // declspecs, declarator, try, ctor_init, args, body, handlers

public:
  /** Constructor.
   *  \param dss The declaration specifier sequence. 
   *  \param d The function declarator.
   *  \param t Optional keyword 'try' for a function try-block.
   *  \param ci Optional constructor initializer list.
   *  \param as Optional K&R argument declaration list.
   *  \param b The function body.
   *  \param hs Exception handler sequence for a function try-block. */
  CT_FctDef (CTree *dss, CTree *d, CTree *t, CTree *ci, CTree *as, 
             CTree *b, CTree *hs) {
    AddSon (sons[0], dss); AddSon (sons[1], d); AddSon (sons[2], t); 
    AddSon (sons[3], ci); AddSon (sons[4], as); AddSon (sons[5], b); 
    AddSon (sons[6], hs); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 7); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the function declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the 'try' keyword of the function try-block. */
  CT_Token *TryKey () const { return (CT_Token*)sons[2]; }
  /** Get the constructor initializer list. */
  CTree *CtorInit () const { return sons[3]; }
  /** Get the K&R argument declaration sequence. */
  CT_ArgDeclSeq *ArgDeclSeq () const { return (CT_ArgDeclSeq*)sons[4]; }
  /** Get the function body. */
  CT_CmpdStmt *Body () const { return (CT_CmpdStmt*)sons[5]; }
  /** Get the exception handler sequence of a function try-block. */
  CT_HandlerSeq *Handlers () const { return (CT_HandlerSeq*)sons[6]; }
  /** Get the semantic information about the function. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the constructor initializer list. 
   *  \param i The initializer list. */
  void CtorInit (CTree *i) { AddSon (sons[3], i); }
  /** Set the function body.
   *  \param b The function body. */
  void Body (CTree *b) { AddSon (sons[5], b); }
  /** Set the exception handler sequence of a function try-block.
   *  \param h The handlers. */
  void Handlers (CTree *h) { AddSon (sons[6], h); }
  /** Set the function try-block.
   *  \param t The keyword 'try'.
   *  \param c Optional constructor initializer list.
   *  \param b The function body.
   *  \param h The exception handler sequence. */
  void FctTryBlock (CTree *t, CTree *c, CTree *b, CTree *h) { 
    AddSon (sons[2], t); AddSon (sons[3], c); 
    AddSon (sons[5], b); AddSon (sons[6], h);
  }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_AsmDef CTree.h Puma/CTree.h
 *  Tree node representing an inline assembly definition. 
 *  Example: \code asm("movl %ecx %eax"); \endcode */

#line 10827 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10863 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AsmDef : public CT_Decl {
#line 10874 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 10881 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2746 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // asm, open, str, close, semi_colon

public:
  /** Constructor.
   *  \param a The keyword 'asm'.
   *  \param o Left parenthesis around the assembler code string. 
   *  \param s The assembler code.
   *  \param c Right parenthesis around the assembler code string.
   *  \param sc Trailing semi-colon. */
  CT_AsmDef (CTree *a, CTree *o, CTree *s, CTree *c, CTree *sc) {
    AddSon (sons[0], a); AddSon (sons[1], o); AddSon (sons[2], s); 
    AddSon (sons[3], c); AddSon (sons[4], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the assembler code. */
  CT_String *Instructions () const { return (CT_String*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_Handler CTree.h Puma/CTree.h
 *  Tree node representing an exception handler. */

#line 10957 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Handler : public CT_Decl, public CSemScope {
#line 10993 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11000 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2782 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // catch, exception_decl, stmt

public:
  /** Constructor.
   *  \param c The keyword 'catch'.
   *  \param e The exception object declaration.
   *  \param s The exception handling statement. */
  CT_Handler (CTree *c, CTree *e, CTree *s) {
    AddSon (sons[0], c); AddSon (sons[1], e); AddSon (sons[2], s);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the exception object declaration. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Get the exception handling statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
  /** Get the scope opened by the handler. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_LinkageSpec CTree.h Puma/CTree.h
 *  Tree node representing a list of declaration with a specific linkage. */

#line 11071 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11107 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_LinkageSpec : public CT_Decl {
#line 11118 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11125 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // linkage specifiers, open, decls, close

public:
  /** Constructor.
   *  \param dss The linkage specifiers, e.g. extern and "C".
   *  \param o Left parenthesis around the declaration list.
   *  \param d The list of declarations.
   *  \param c Right parenthesis around the declaration list. */
  CT_LinkageSpec (CTree *dss, CTree *o, CTree *d, CTree *c) {
    AddSon (sons[0], dss); AddSon (sons[1], o);
    AddSon (sons[2], d); AddSon (sons[3], c);
    if (isList ())
      ((CT_DeclList*)Decls ())->Linkage (this);
    else
      ((CT_Decl*)Decls ())->Linkage (this);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the linkage specifier list. */
  CT_DeclSpecSeq *LinkageSpecifiers () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the list declarations. */
  CTree *Decls () const { return sons[2]; }
  /** Check if there is more than one enclosed declaration. 
   *  In this case the node returned by Decls() is a CT_DeclList
   *  node. */
  bool isList () const {
    return Decls ()->NodeName () == CT_DeclList::NodeId ();
  }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_ArgDecl CTree.h Puma/CTree.h
 *  Tree node representing the declaration of a function parameter. */

#line 11212 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2866 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArgDecl : public CT_Decl, public CSemObject, public CSemValue {
#line 11248 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2866 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11255 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2866 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declspecs, declarator, init, ellipsis

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param d The parameter declarator. */
  CT_ArgDecl (CTree *dsl, CTree *d) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); 
    AddSon (sons[2], 0); AddSon (sons[3], 0); 
  }
  /** Constructor.
   *  \param ellipsis The variable argument list operator "...". */
  CT_ArgDecl (CTree *ellipsis) {
    AddSon (sons[0], 0); AddSon (sons[1], 0); 
    AddSon (sons[2], 0); AddSon (sons[3], ellipsis); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the function parameter declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the default argument. */
  CT_ExprList *Initializer () const {
    return (sons[2] && sons[2]->IsDelayedParse ()) ? 0 : (CT_ExprList*)sons[2];
  }
  /** Get the variable argument list operator. */
  CT_Token *Ellipsis () const { return (CT_Token*)sons[3]; }
  /** Get the semantic information about the function parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get the type of the function parameter.
   *  \return The type information object or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the function parameter.
   *  \return The value object or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information of the function parameter.
   *  \return The value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Set the default argument. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_ArgDeclList CTree.h Puma/CTree.h
 *  Tree node representing a function parameter list. */

#line 11349 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArgDeclList : public CT_DeclList, public CSemScope {
#line 11385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list.
   *  \param props The list properties. */
  CT_ArgDeclList (int size = 2, int props = SEPARATORS | OPEN_CLOSE) : 
   CT_DeclList (size, 2) { AddProperties (props); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the parameter list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_ArgDeclSeq CTree.h Puma/CTree.h
 *  Tree node representing a K&R function parameter declarations list. */

#line 11443 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2943 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArgDeclSeq : public CT_DeclList, public CSemScope {
#line 11479 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2943 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11486 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2943 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_ArgDeclSeq (int size = 2) : CT_DeclList (size, 2) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the parameter declarations list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_ArgNameList CTree.h Puma/CTree.h
 *  Tree node representing a K&R function parameter name list. */

#line 11535 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArgNameList : public CT_ArgDeclList {
#line 11571 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11578 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2958 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_ArgNameList () : CT_ArgDeclList () {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_NamespaceDef CTree.h Puma/CTree.h
 *  Tree node representing a namespace definition.
 *  Example: \code namespace a {} \endcode */

#line 11625 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 2971 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11661 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2971 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NamespaceDef : public CT_Decl, public CSemObject {
#line 11672 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 2971 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11679 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2971 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // ns, name, members

public:
  /** Constructor.
   *  \param n The keyword 'namespace'.
   *  \param nm The name of the namespace. */
  CT_NamespaceDef (CTree *n, CTree *nm) {
    AddSon (sons[0], n); AddSon (sons[1], nm); AddSon (sons[2], 0); 
  }
  /** Constructor.
   *  \param n The keyword 'namespace'.
   *  \param nm The name of the namespace. 
   *  \param m The namespace member declarations list. */
  CT_NamespaceDef (CTree *n, CTree *nm, CTree *m) {
    AddSon (sons[0], n); AddSon (sons[1], nm); AddSon (sons[2], m); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Set the namespace member declarations list. */
  void Members (CTree *m) { AddSon (sons[2], m); }
  /** Get the namespace member declarations list. */
  CT_MembList *Members () const { return (CT_MembList*)sons[2]; }
  /** Get the name of the namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Get the semantic information about the namespace. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_NamespaceAliasDef CTree.h Puma/CTree.h
 *  Tree node representing a namespace alias definition.
 *  Example: \code namespace b = a; \endcode */

#line 11765 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3017 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11801 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3017 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NamespaceAliasDef : public CT_Decl, public CSemObject {
#line 11812 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3017 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11819 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3017 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // ns, alias, assign, name, semi_colon

public:
  /** Constructor.
   *  \param n The keyword 'namespace'.
   *  \param a The name of the namespace alias.
   *  \param as The assignment operator '='.
   *  \param nm The name of the original namespace.
   *  \param s The trailing semi-colon. */
  CT_NamespaceAliasDef (CTree *n, CTree *a, CTree *as, CTree *nm, CTree *s) {
    AddSon (sons[0], n); AddSon (sons[1], a); AddSon (sons[2], as); 
    AddSon (sons[3], nm); AddSon (sons[4], s); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the name of the original namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[3]; }
  /** Get the name of the namespace alias. */
  CT_SimpleName *Alias () const { return (CT_SimpleName*)sons[1]; }
  /** Get the semantic information about the namespace alias. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_UsingDirective CTree.h Puma/CTree.h
 *  Tree node representing a namespace using directive.
 *  Example: \code using namespace std; \endcode */

#line 11900 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11936 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UsingDirective : public CT_Decl {
#line 11947 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 11954 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3058 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // using, ns, name, semi_colon

public:
  /** Constructor. 
   *  \param u The keyword 'using'.
   *  \param ns The keyword 'namespace'. 
   *  \param n The name of the namespace.
   *  \param s The trailing semi-colon. */
  CT_UsingDirective (CTree *u, CTree *ns, CTree *n, CTree *s) {
    AddSon (sons[0], u); AddSon (sons[1], ns); AddSon (sons[2], n); 
    AddSon (sons[3], s); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the name of the namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }   private:

#line 156 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 2 ; }};

/*****************************************************************************/
/*                                                                           */
/*                              Declarators                                  */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Declarator CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declarators. */

#line 12042 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3099 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12078 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3099 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Declarator : public CTree {
#line 12089 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3099 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12096 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3099 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_Declarator () {}

public:
  /** Get the declarator. */
  virtual CTree *Declarator () const = 0;
  /** Get this. */
  virtual CT_Declarator *IsDeclarator () { return this; }
  /** Get the declared name. */
  CT_SimpleName *Name ();
  /** Get the declared name and set last_declarator to 
   *  the declarator containing the name. 
   *  \param last_declarator To be set to the declarator containing the name. */
  CT_SimpleName *Name (CT_Declarator *&last_declarator);
   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_InitDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a declarator with initializer.
 *  Example: \code int *i = 0; \endcode */

#line 12163 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12199 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_InitDeclarator : public CT_Declarator, public CSemObject {
#line 12210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12217 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3120 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // declarator, init
  CTree *obj_decl;

public:
  /** Constructor.
   *  \param d The declarator.
   *  \param e Optional extension list.
   *  \param i The initializer. */
  CT_InitDeclarator (CTree *d, CTree *i = 0) {
    AddSon (sons[0], d); AddSon (sons[1], i);
    AddSon (obj_decl, 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the declared object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get the object declaration node containing the declarator. */
  CT_ObjDecl *ObjDecl () const { return (CT_ObjDecl*)obj_decl; }
  /** Set the initializer. */
  void Initializer (CTree* i) { AddSon (sons[1], i); }
  /** Set the object declaration node containing the declarator. 
   *  \param od The object declaration node. */
  void ObjDecl (CTree *od) { AddSon (obj_decl, od); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
   private:

#line 138 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }};

/** \class CT_BracedDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a braced declarator.
 *  Example: \code int (i); \endcode */

#line 12305 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BracedDeclarator : public CT_Declarator {
#line 12341 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12348 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3167 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, win_specs, declarator, close

public:
  /** Constructor.
   *  \param o Left parenthesis around the declarator.
   *  \param d The declarator.
   *  \param c Right parenthesis around the declarator. */
  CT_BracedDeclarator (CTree *o, CTree *d, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], 0); 
    AddSon (sons[2], d); AddSon (sons[3], c); 
  }
  /** Constructor.
   *  \param o Left parenthesis around the declarator.
   *  \param ws Declaration specifiers.
   *  \param d The declarator.
   *  \param c Right parenthesis around the declarator. */
  CT_BracedDeclarator (CTree *o, CTree *ws, CTree *d, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], ws); 
    AddSon (sons[2], d); AddSon (sons[3], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_ArrayDelimiter CTree.h Puma/CTree.h
 *  Tree node representing an array delimiter.
 *  Example: \code [10] \endcode or \code [*] \endcode */

#line 12426 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArrayDelimiter : public CTree {
#line 12462 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12469 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3211 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // star, static, quals, expr
  bool pos0;

public:
  /** Constructor.
   *  \param m The operator '*'.
   *  \param s The keyword 'static'.
   *  \param q The const/volatile qualifier sequence. 
   *  \param e The array size expression. 
   *  \param p Position of keyword 'static', true means before the
   *           qualifier sequence and false means behind it. */
  CT_ArrayDelimiter (CTree *m, CTree *s, CTree *q, CTree *e, bool p = false) {
    AddSon (sons[0], m); AddSon (sons[1], s); 
    AddSon (sons[2], q); AddSon (sons[3], e); pos0 = p;
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the operator '*'. */
  CT_Token *Star () const { return (CT_Token*)sons[0]; }
  /** Get the keyword 'static'. */
  CT_Token *Static () const { return (CT_Token*)sons[pos0?2:1]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[pos0?1:2]; }
  /** Get the array size expression. */
  CTree *Expr () const { return sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_ArrayDeclarator CTree.h Puma/CTree.h
 *  Tree node representing an array declarator.
 *  Example: \code a[10] \endcode */

#line 12548 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ArrayDeclarator : public CT_Declarator, public CSemValue {
#line 12584 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12591 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3256 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declarator, open, delim, close

public:
  /** Constructor.
   *  \param d The array declarator.
   *  \param o Left bracket around the delimiter.
   *  \param ad The array delimiter.
   *  \param c Right bracket around the delimiter. */
  CT_ArrayDeclarator (CTree *d, CTree *o, CTree *ad, CTree *c) {
    AddSon (sons[0], d); AddSon (sons[1], o); 
    AddSon (sons[2], ad); AddSon (sons[3], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the array declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the array delimiter. */
  CT_ArrayDelimiter *Delimiter () const 
   { return (CT_ArrayDelimiter*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the semantic information for the type of the declared array. */
  CTypeInfo *Type () const { return type; }
  /** Get the semantic information for the value of the declared array. */
  CExprValue *Value () const { return value; }
  /** Get the semantic information object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
};

/** \class CT_FctDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a function declarator.
 *  Example: \code f(int a) const \endcode */

#line 12670 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_FctDeclarator : public CT_Declarator {
#line 12706 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12713 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3301 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declarator, args, cv_quals, exception_specs

public:
  /** Constructor.
   *  \param d The function declarator.
   *  \param args The function parameter list.
   *  \param cv The function qualifiers.
   *  \param es The exception specifier. */
  CT_FctDeclarator (CTree *d, CTree *args, CTree *cv, CTree *es) {
    AddSon (sons[0], d); AddSon (sons[1], args); 
    AddSon (sons[2], cv); AddSon (sons[3], es); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the function declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the function parameter list. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Get the function qualifier list. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[2]; }
  /** Get the exception specifier. */
  CT_ExceptionSpec *ExceptionSpecs () const { return (CT_ExceptionSpec*)sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_RefDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a reference declarator.
 *  Example: \code &a \endcode */

#line 12789 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_RefDeclarator : public CT_Declarator {
#line 12825 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3343 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // ref, declarator

public:
  /** Constructor.
   *  \param r The reference operator '&'.
   *  \param d The declarator. */
  CT_RefDeclarator (CTree *r, CTree *d) { AddSon (sons[0], r); AddSon (sons[1], d); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/** \class CT_PtrDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a pointer declarator.
 *  Example: \code *a \endcode */

#line 12897 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PtrDeclarator : public CT_Declarator {
#line 12933 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 12940 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // ptr, cv_quals, declarator

public:
  /** Constructor.
   *  \param p The pointer operator '*'.
   *  \param c The const/volatile pointer qualifier sequence.
   *  \param d The declarator. */
  CT_PtrDeclarator (CTree *p, CTree *c, CTree *d) {
    AddSon (sons[0], p); AddSon (sons[1], c); AddSon (sons[2], d); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[2]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_MembPtrDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a member pointer declarator.
 *  Example: \code *X::a \endcode */

#line 13010 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembPtrDeclarator : public CT_Declarator {
#line 13046 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13053 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3410 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // class, colon, ptr, cv_quals, declarator

public:
  /** Constructor.
   *  \param c The class name.
   *  \param cc The scope operator '::'.
   *  \param p The name of the pointer.
   *  \param q The const/volatile pointer qualifier sequence.
   *  \param d The declarator. */
  CT_MembPtrDeclarator (CTree *c, CTree *cc, CTree *p, CTree *q, CTree *d) {
    AddSon (sons[0], c); AddSon (sons[1], cc); AddSon (sons[2], p); 
    AddSon (sons[3], q); AddSon (sons[4], d); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the name of the declared pointer. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[4]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
};

/** \class CT_BitFieldDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a bit-field declarator.
 *  Example: \code a : 2 \endcode */

#line 13128 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BitFieldDeclarator : public CT_Declarator, public CSemObject {
#line 13164 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13171 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3451 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declarator, colon, expr

public:
  /** Constructor.
   *  \param d The declarator.
   *  \param c The colon between the declarator and the bit count.
   *  \param e The expression specifying the number of bits. */
  CT_BitFieldDeclarator (CTree *d, CTree *c, CTree *e = 0) {
    AddSon (sons[0], d); AddSon (sons[1], c); AddSon (sons[2], e); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the expression specifying the number of bits. */
  CTree *Expr () const { return sons[2]; }
  /** Set the expression specifying the number of bits. */
  void FieldSize (CTree *s) { AddSon (sons[2], s); }
  /** Get the semantic information about the declared bit-field. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/*****************************************************************************/
/*                                                                           */
/*                              Statements                                   */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Statement CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing statements. */

#line 13250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3496 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Statement : public CTree {
#line 13286 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3496 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13293 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3496 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
 
protected:
  /** Constructor. */
  CT_Statement () {}
  /** Get this. */
  virtual CT_Statement *IsStatement () { return this; }
};

/** \class CT_LabelStmt CTree.h Puma/CTree.h
 *  Tree node representing a label statement.
 *  Example: \code incr_a: a++; \endcode */

#line 13338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_LabelStmt : public CT_Statement {
#line 13385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13392 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3507 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // id, colon, stmt

public:
  /** Constructor.
   *  \param id The name of the label.
   *  \param c The colon behind the label.
   *  \param stmt The statement following the label. */
  CT_LabelStmt (CTree *id, CTree *c, CTree *stmt) {
    AddSon (sons[0], id); AddSon (sons[1], c); AddSon (sons[2], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Get the name of the label. */
  CT_SimpleName *Label () const { return (CT_SimpleName*)sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:

#line 117 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 1 ; }};

/** \class CT_DefaultStmt CTree.h Puma/CTree.h
 *  Tree node representing a default statement of a switch statement.
 *  Example: \code default: break; \endcode */

#line 13469 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DefaultStmt : public CT_Statement {
#line 13505 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13512 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3543 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // keyword, colon, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'default'.
   *  \param c The colon behind the keyword.
   *  \param stmt The statement of the default case. */
  CT_DefaultStmt (CTree *kw, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], c); AddSon (sons[2], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_TryStmt CTree.h Puma/CTree.h
 *  Tree node representing a try-catch statement.
 *  Example: \code try { f(); } catch (...) {} \endcode */

#line 13580 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3577 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TryStmt : public CT_Statement {
#line 13616 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3577 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13623 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3577 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // try, stmt, handlers

public:
  /** Constructor.
   *  \param t The keyword 'try'.
   *  \param s The statement enclosed in the try-catch block.
   *  \param h The exception handler sequence. */
  CT_TryStmt (CTree *t, CTree *s, CTree *h) {
    AddSon (sons[0], t); AddSon (sons[1], s); AddSon (sons[2], h); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the enclosed statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[1]; }
  /** Get the exception handler sequence. */
  CT_HandlerSeq *Handlers () const { return (CT_HandlerSeq*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_CaseStmt CTree.h Puma/CTree.h
 *  Tree node representing a case statement.
 *  Example: \code case 42: a=42; \endcode */

#line 13693 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3613 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CaseStmt : public CT_Statement {
#line 13729 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3613 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13736 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3613 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // keyword, expr, colon, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'case'.
   *  \param expr The constant expression specifying the case value.
   *  \param c The colon.
   *  \param stmt The statement of the case. */
  CT_CaseStmt (CTree *kw, CTree *expr, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], expr); 
    AddSon (sons[2], c); AddSon (sons[3], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[3]; }
  /** Get the expression specifying the case value. */
  CTree *Expr () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
};

/** \class CT_ExprStmt CTree.h Puma/CTree.h
 *  Tree node representing an expression statement.
 *  Example: \code a+b; \endcode */

#line 13808 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13844 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ExprStmt : public CT_Statement {
#line 13855 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13862 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3651 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // expr, semi_colon

public:
  /** Constructor.
   *  \param expr The expression.
   *  \param sc The trailing semi-colon. */
  CT_ExprStmt (CTree *expr, CTree *sc) { AddSon (sons[0], expr); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the expression. */
  CTree *Expr () const { return sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/** \class CT_DeclStmt CTree.h Puma/CTree.h
 *  Tree node representing a declaration statement.
 *  Example: \code int i = 0; \endcode */

#line 13933 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclStmt : public CT_Statement {
#line 13969 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 13976 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3682 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_decl;

public:
  /** Constructor.
   *  \param decl The declaration. */
  CT_DeclStmt (CTree *decl) { AddSon (_decl, decl); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return n == 0 ? _decl : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_decl, old_son, new_son); }
};

/** \class CT_SwitchStmt CTree.h Puma/CTree.h
 *  Tree node representing a switch statement.
 *  Example: \code switch(a) { case 0: a++; } \endcode */

#line 14037 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3709 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SwitchStmt : public CT_Statement, public CSemScope {
#line 14073 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3709 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14080 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3709 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // keyword, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'switch'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The switch-expression. 
   *  \param c Right parenthesis behind the condition. 
   *  \param stmt The cases of the switch-statement. */
  CT_SwitchStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the cases. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the switch-expression. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the switch-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_IfStmt CTree.h Puma/CTree.h
 *  Tree node representing a if-statement.
 *  Example: \code if(a==0) a++; \endcode */

#line 14155 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IfStmt : public CT_Statement, public CSemScope {
#line 14191 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14198 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // keyword, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'if'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The condition.
   *  \param c Right parenthesis behind the condition.
   *  \param stmt The controlled statement. */
  CT_IfStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the condition. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the if-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_IfElseStmt CTree.h Puma/CTree.h
 *  Tree node representing a if-else-statement.
 *  Example: \code if(a==0) a++; else a=0; \endcode */

#line 14273 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3791 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IfElseStmt : public CT_Statement, public CSemScope {
#line 14309 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3791 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14316 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3791 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // if, open, cond, close, if_stmt, else, else_stmt

public:
  /** Constructor.
   *  \param i The keyword 'if'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The condition.
   *  \param c Right parenthesis behind the condition.
   *  \param is The statement controlled by the if-branch.
   *  \param e The keyword 'else'.
   *  \param es The statement controlled by the else-branch. */
  CT_IfElseStmt (CTree *i, CTree *o, CTree *cond, CTree *c, 
                 CTree *is, CTree *e, CTree *es) {
    AddSon (sons[0], i); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], is); AddSon (sons[5], e); 
    AddSon (sons[6], es); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 7; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the condition. */
  CTree *Condition () const { return sons[2]; }
  /** Get the statement controlled by the if-branch. */
  CT_Statement *IfPart () const { return (CT_Statement*)sons[4]; }
  /** Get the statement controlled by the else-branch. */
  CT_Statement *ElsePart () const { return (CT_Statement*)sons[6]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
  /** Get the scope opened by the if-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_BreakStmt CTree.h Puma/CTree.h
 *  Tree node representing a break-statement.
 *  Example: \code break; \endcode */

#line 14397 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BreakStmt : public CT_Statement {
#line 14433 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14440 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3838 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'break'.
   *  \param sc The trailing semi-colon. */
  CT_BreakStmt (CTree *key, CTree *sc) { AddSon (sons[0], key); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/** \class CT_ContinueStmt CTree.h Puma/CTree.h
 *  Tree node representing a continue-statement.
 *  Example: \code continue; \endcode */

#line 14503 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ContinueStmt : public CT_Statement {
#line 14539 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14546 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'continue'.
   *  \param sc The trailing semi-colon. */
  CT_ContinueStmt (CTree *key, CTree *sc) { AddSon (sons[0], key); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/** \class CT_GotoStmt CTree.h Puma/CTree.h
 *  Tree node representing a goto-stmt.
 *  Example: \code goto incr_a; \endcode */

#line 14609 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3896 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_GotoStmt : public CT_Statement {
#line 14645 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3896 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14652 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3896 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, label, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'goto'.
   *  \param l The name of the jump label.
   *  \param sc The trailing semi-colon. */
  CT_GotoStmt (CTree *key, CTree *l, CTree *sc) {
    AddSon (sons[0], key); AddSon (sons[1], l); AddSon (sons[2], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the name of the jump label. */
  CT_SimpleName *Label () const { return (CT_SimpleName*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_ReturnStmt CTree.h Puma/CTree.h
 *  Tree node representing a return-statement.
 *  Example: \code return 1; \endcode */

#line 14720 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ReturnStmt : public CT_Statement {
#line 14756 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14763 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3930 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, expr, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'return'.
   *  \param e The expression specifying the return value. 
   *  \param sc The trailing semi-colon. */
  CT_ReturnStmt (CTree *key, CTree *e, CTree *sc) {
    AddSon (sons[0], key); AddSon (sons[1], e); AddSon (sons[2], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the expression specifying the return value. */
  CTree *Expr () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_WhileStmt CTree.h Puma/CTree.h
 *  Tree node representing a while-statement.
 *  Example: \code while(a>0) a--; \endcode */

#line 14831 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 3964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_WhileStmt : public CT_Statement, public CSemScope {
#line 14867 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 3964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14874 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3964 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'while'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The loop condition. 
   *  \param c Right parenthesis behind the condition. 
   *  \param stmt The controlled statement. */
  CT_WhileStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the loop condition. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the while-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_DoStmt CTree.h Puma/CTree.h
 *  Tree node representing a do-while-statement.
 *  Example: \code do a--; while(a>0); \endcode */

#line 14949 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4005 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DoStmt : public CT_Statement {
#line 14985 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4005 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 14992 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4005 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // do, stmt, while, open, expr, close, semi_colon

public:
  /** Constructor.
   *  \param d The keyword 'do'.
   *  \param stmt The controlled statement.
   *  \param w The keyword 'while'.
   *  \param o Left parenthesis before the loop condition.
   *  \param e The loop condition.
   *  \param c Right parenthesis behind the loop condition.
   *  \param sc The trailing semi-colon. */
  CT_DoStmt (CTree *d, CTree *stmt, CTree *w, CTree *o, CTree *e, 
             CTree *c, CTree *sc) {
    AddSon (sons[0], d); AddSon (sons[1], stmt); AddSon (sons[2], w); 
    AddSon (sons[3], o); AddSon (sons[4], e); AddSon (sons[5], c); 
    AddSon (sons[6], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 7; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[1]; }
  /** Get the loop condition. */
  CTree *Expr () const { return sons[4]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
};

/** \class CT_ForStmt CTree.h Puma/CTree.h
 *  Tree node representing a for-statement.
 *  Example: \code for(int i=0; i<10; i++) f(i); \endcode */

#line 15069 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4048 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ForStmt : public CT_Statement, public CSemScope {
#line 15105 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4048 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15112 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4048 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[8]; // key, open, init, cond, semi_colon, expr, close, stmt

public:
  /** Constructor.
   *  \param k The keyword 'for'.
   *  \param o Left parenthesis.
   *  \param i The loop initializer statement.
   *  \param co The loop condition.
   *  \param sc The semi-colon behind the loop condition.
   *  \param e The loop counter expression.
   *  \param c Right parenthesis.
   *  \param stmt The controlled statement. */
  CT_ForStmt (CTree *k, CTree *o, CTree *i, CTree *co, CTree *sc,
              CTree *e, CTree *c, CTree *stmt) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], i); 
    AddSon (sons[3], co); AddSon (sons[4], sc); AddSon (sons[5], e); 
    AddSon (sons[6], c); AddSon (sons[7], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 8); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 8, n); }
  /** Get the loop initializer. */
  CTree *InitStmt () const { return sons[2]; }
  /** Get the loop condition. */
  CTree *Condition () const { return sons[3]; }
  /** Get the loop counter expression. */
  CTree *Expr () const { return sons[5]; }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[7]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 8, old_son, new_son);
  }
  /** Get the scope opened by the for-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_Condition CTree.h Puma/CTree.h
 *  Tree node representing a control-statement condition.
 *  Example: \code int i = 0 \endcode */

#line 15196 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15232 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Condition : public CT_Decl, public CSemObject {
#line 15243 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15250 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4098 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarator, init

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence. 
   *  \param d The variable declarator. */
  CT_Condition (CTree *dsl, CTree *d) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); AddSon (sons[2], 0);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the initializer of the declaration. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[2]; }
  /** Get the semantic information of the declared object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the initializer. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
   private:

#line 147 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 1 ; }};

/*****************************************************************************/
/*                                                                           */
/*                              Classes                                      */
/*                                                                           */
/*****************************************************************************/

/** \class CT_ClassDef CTree.h Puma/CTree.h
 *  Tree node representing a class definition.
 *  Example: \code class X : Y { int x; } \endcode */

#line 15338 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15374 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
namespace Puma {

#line 4145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15385 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ClassDef : public CT_Decl, public CSemObject {
#line 15396 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15403 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4145 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

   
#line 15438 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

  struct __ac_wrapper_sons {
    typedef ::Puma::CTree * E; typedef E A[4]; A _data;
    operator A& () { return _data; }
    operator A& () const { return (A&)*(::Puma::CTree * *)_data; }
    operator const A& () { return _data; }
    operator const A& () const { return _data; }
    operator void* () { return _data; }
    operator void* () const { return (void*)_data; }
    operator const void* () { return _data; }
    operator const void* () const { return _data; }
    template <typename I> E& operator [] (I i) { return _data[i]; } // for VC++ 2003
    template <typename I> const E& operator [] (I i) const { return _data[i]; } // for VC++ 2003
  } sons
#line 4146 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4146 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
; // key, name, bases, members
  CTree *obj_decl;

public:
  /** Constructor.
   *  \param k The keyword 'class' or 'struct'.
   *  \param n The name of the class.
   *  \param b The base class list. */
  
#line 15465 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"


template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0 {
  typedef TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 9061;
  static const AC::JPType JPTYPE = (AC::JPType)16;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
CT_ClassDef (CTree * arg0, CTree * arg1, CTree * arg2 = (CTree*)0) 
#line 15491 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
{
  typedef TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0< void, ::Puma::CT_ClassDef , ::Puma::CT_ClassDef ,  AC::TL< ::Puma::CTree * , AC::TL< ::Puma::CTree * , AC::TL< ::Puma::CTree * , AC::TLE > > > > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
    this->__exec_old_C1(arg0, arg1, arg2);
  AC::invoke_ExtACTree_ExtACTree_a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_C1(::Puma::CTree * k,::Puma::CTree * n,::Puma::CTree * b)
#line 4154 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
{
    AddSon (sons[0], k); AddSon (sons[1], n); AddSon (sons[2], b); 
    AddSon (sons[3], 0); AddSon (obj_decl, 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the name of the class. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Get the member declarations list. */
  CT_MembList *Members () const { return (CT_MembList*)sons[3]; }
  /** Get the base class specifiers list. */
  CT_BaseSpecList *BaseClasses () const { return (CT_BaseSpecList*)sons[2]; }
  /** Get the object declaration node containing the class definition. */
  CT_ObjDecl *ObjDecl () const { return (CT_ObjDecl*)obj_decl; }
  /** Get the semantic information about the declared class. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the member declarations list. */
  void Members (CTree *m) { AddSon (sons[3], m); }
  /** Set the base class specifiers list. */
  void BaseClasses (CTree *bc) { AddSon (sons[2], bc); }
  /** Set the object declaration containing the class definition. */
  void ObjDecl (CTree *od) { AddSon (obj_decl, od); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
   private:

#line 37 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtACTree.ah"
 Puma :: CTree * _intro_members ;
Puma :: CTree * _base_intros ;
public :
Puma :: CTree * IntroMembers ( ) const { return _intro_members ; }
void IntroMembers ( Puma :: CTree * members ) { _intro_members = members ; }
Puma :: CTree * BaseIntros ( ) const { return _base_intros ; }
void BaseIntros ( Puma :: CTree * bases ) { _base_intros = bases ; }   private:

#line 79 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }   private:

#line 129 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 15567 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0 {
  typedef TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 9124;
  static const AC::JPType JPTYPE = (AC::JPType)16;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15592 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

public:
inline CT_ClassDef (const Puma::CT_ClassDef & arg0) : Puma::CT_Decl (arg0), Puma::CSemObject (arg0), sons (arg0.sons), obj_decl (arg0.obj_decl), _intro_members (arg0._intro_members), _base_intros (arg0._base_intros), _gnu_suffix (arg0._gnu_suffix), _gnu_prefix (arg0._gnu_prefix), _gnu_infix (arg0._gnu_infix) {
  typedef TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0< void, ::Puma::CT_ClassDef , ::Puma::CT_ClassDef ,  AC::TL< const ::Puma::CT_ClassDef & , AC::TLE > > __TJP;
  __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  AC::invoke_ExtACTree_ExtACTree_a0_after<__TJP> (&tjp);

}

#line 4190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15605 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

template <typename TResult, typename TThat, typename TTarget, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefD1Ev_0 {
  typedef TJP__ZN4Puma11CT_ClassDefD1Ev_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const int JPID = 9122;
  static const AC::JPType JPTYPE = (AC::JPType)32;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15630 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

public:
inline ~CT_ClassDef () {
  typedef TJP__ZN4Puma11CT_ClassDefD1Ev_0< void, ::Puma::CT_ClassDef , ::Puma::CT_ClassDef ,  AC::TLE > __TJP;
  __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  AC::invoke_ExtACTree_ExtACTree_a1_before<__TJP> (&tjp);

}

#line 4190 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
};
      
/** \class CT_UnionDef CTree.h Puma/CTree.h
 *  Tree node representing the definition of a union.
 *  Example: \code union U { int i; } \endcode */

#line 15648 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4195 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UnionDef : public CT_ClassDef {
#line 15684 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4195 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15691 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4195 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The keyword 'union'.
   *  \param n The name of the union.
   *  \param b The base union list. */
  CT_UnionDef (CTree *k, CTree *n, CTree *b = 0) : CT_ClassDef (k, n, b) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};
      
/** \class CT_MembList CTree.h Puma/CTree.h
 *  Tree node representing a member declarations list. */ 

#line 15740 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembList : public CT_DeclList, public CSemScope {
#line 15776 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15783 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4210 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  CT_MembList (int size = 10, int incr = 10) : 
    CT_DeclList (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the member declarations list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_MembInitList CTree.h Puma/CTree.h
 *  Tree node representing a constructor initializer list.
 *  Example: \code : Base(), m_Member(0) \endcode */

#line 15832 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembInitList : public CT_List, public CSemScope {
#line 15868 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15875 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4225 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_MembInitList (int size = 2) : 
    CT_List (size, 2, CT_List::OPEN) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the member initializer list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
};

/** \class CT_MembInit CTree.h Puma/CTree.h
 *  Tree node representing a member initializer.
 *  Example: \code m_Member(0) \endcode */

#line 15926 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15962 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 4242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15973 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 4242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembInit : public CT_Expression, public CSemObject {
#line 15984 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 15991 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4242 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, init

public:
  /** Constructor.
   *  \param n The name of the member.
   *  \param i The member initializer. */
  CT_MembInit (CTree *n, CTree *i) { AddSon (sons[0], n); AddSon (sons[1], i); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the name of the member. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the initialized member. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
   private:
  typedef CT_MembInit CCExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CCExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;   private:
  typedef CT_MembInit CExprResolveExpr;

#line 36 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/CExprResolveH.ah"
 public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;};

/** \class CT_BaseSpecList CTree.h Puma/CTree.h
 *  Tree node representing a base specifier list.
 *  Example: \code : X, Y, Z \endcode */

#line 16070 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BaseSpecList : public CT_List {
#line 16106 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16113 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4277 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_BaseSpecList (int size = 2) : 
    CT_List (size, 2, CT_List::OPEN|CT_List::SEPARATORS) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_AccessSpec CTree.h Puma/CTree.h
 *  Tree node representing an access specifier.
 *  Example: \code public: \endcode */

#line 16162 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4292 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AccessSpec : public CTree {
#line 16198 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4292 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16205 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4292 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // access, colon

public:
  /** Constructor.
   *  \param a The access specifier, i.e. 'public', 'private', or 'protected'.
   *  \param c The trailing colon. */
  CT_AccessSpec (CTree *a, CTree *c) { AddSon (sons[0], a); AddSon (sons[1], c); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the access specifier type (token type). */
  int Access () const { return sons[0]->token ()->type (); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/** \class CT_BaseSpec CTree.h Puma/CTree.h
 *  Tree node representing a base class specifier.
 *  Example: \code public X \endcode */

#line 16270 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4323 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BaseSpec : public CTree {
#line 16306 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4323 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16313 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4323 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // virtual, access, name

public:
  /** Constructor.
   *  \param v Optional keyword 'virtual'.
   *  \param a The optional access specifier.
   *  \param n The name of the base class. */
  CT_BaseSpec (CTree *v, CTree *a, CTree *n) {
    AddSon (sons[0], v); AddSon (sons[1], a); AddSon (sons[2], n); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the type of the access specifier (token type). */
  int Access () const { return sons[1]->token ()->type (); }
  /** The access specifier. */
  CTree *AccessSpec () const { return sons[1]; }
  /** Get the keyword 'virtual'. */
  CTree *Virtual () const { return sons[0]; }
  /** Get the name of the base class. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};

/** \class CT_AccessDecl CTree.h Puma/CTree.h
 *  Tree node representing a member access declaration.
 *  Example: \code m_BaseClassMember; \endcode */

#line 16387 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AccessDecl : public CT_Decl {
#line 16423 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16430 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4363 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, semi_colon

public:
  /** Constructor.
   *  \param n The name of the base class member.
   *  \param s The trailing semi-colon. */
  CT_AccessDecl (CTree *n, CTree *s) { AddSon (sons[0], n); AddSon (sons[1], s); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the name of the base class member. */
  CT_QualName *Member () const { return (CT_QualName*)sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
};

/** \class CT_UsingDecl CTree.h Puma/CTree.h
 *  Tree node representing a using declaration.
 *  Example: \code using Base::m_Member; \endcode */

#line 16495 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16531 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UsingDecl : public CT_AccessDecl {
#line 16542 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16549 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4394 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // using, typename

public:
  /** Constructor.
   *  \param u The keyword 'using'.
   *  \param n The name of the entity.
   *  \param s The trailing semi-colon. */
  CT_UsingDecl (CTree *u, CTree *n, CTree *s) : CT_AccessDecl (n, s) {
    AddSon (sons[0], u); AddSon (sons[1], 0); 
  }
  /** Constructor.
   *  \param u The keyword 'using'.
   *  \param t The keyword 'typename'.
   *  \param n The name of the entity.
   *  \param s The trailing semi-colon. */
  CT_UsingDecl (CTree *u, CTree *t, CTree *n, CTree *s) : CT_AccessDecl (n, s) {
    AddSon (sons[0], u); AddSon (sons[1], t); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2) + CT_AccessDecl::Sons (); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const {
    int num = CTree::Sons (sons, 2);
    CTree *result = CTree::Son (sons, 2, n);
    return result ? result : CT_AccessDecl::Son (n-num);
  }
  /** Get the keyword 'typename'. */
  CTree *Typename () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
    CT_AccessDecl::ReplaceSon (old_son, new_son);
  }
   private:

#line 108 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/aspects/Puma/ExtGnuCTree.ah"
 CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }};

/*****************************************************************************/
/*                                                                           */
/*                              Wildcards                                    */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Any CTree.h Puma/CTree.h
 *  Tree node representing a wildcard. */

#line 16641 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4446 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Any : public CTree {
#line 16677 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4446 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16684 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4446 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // keyword, extension

public:
  /** Constructor.
   *  \param k The wildcard keyword.
   *  \param e The extension. */
  CT_Any (CTree *k, CTree *e = (CTree*)0) { AddSon (sons[0], k); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the type of the wildcard (token type). */
  int AnyType () const { return sons[0]->token ()->type (); }
  /** Get the extension. */
  CT_AnyExtension *Extension () const { return (CT_AnyExtension*)sons[1]; }
};

/** \class CT_AnyList CTree.h Puma/CTree.h
 *  Tree node representing a list wildcard. */

#line 16750 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AnyList : public CT_Any {
#line 16786 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16793 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4478 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The wildcard keyword.
   *  \param e The extension. */
  CT_AnyList (CTree *k, CTree *e = (CTree*)0) : CT_Any (k, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
};

/** \class CT_AnyExtension CTree.h Puma/CTree.h
 *  Tree node representing a wildcard extension. */

#line 16841 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AnyExtension : public CTree, public CSemValue {
#line 16877 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 16884 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4492 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // open, string, comma, cond, close

public:
  /** Constructor.
   *  \param o Left parenthesis before the extension. 
   *  \param n The name of the extension.
   *  \param co The comma between the name and the condition. 
   *  \param c The condition.
   *  \param cr Right parenthesis behind the extension. */
  CT_AnyExtension (CTree *o, CTree *n, CTree *co, CTree *c, CTree *cr) {
    AddSon (sons[0], o); AddSon (sons[1], n); AddSon (sons[2], co); 
    AddSon (sons[3], c); AddSon (sons[4], cr); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the condition. */
  CTree *Condition () const { return sons[3]; }
  /** Get the name string. */
  CT_Token *String () const { return (CT_Token*)sons[1]; }
  /** Get the extension name. */
  const char *Name () const { return value ? value->StrLiteral ()->String () : (const char*)0; }
  /** Get the value of the extension (the name). */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
};

/** \class CT_AnyCondition CTree.h Puma/CTree.h
 *  Tree node representing the condition of a wildcard. */

#line 16962 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACBuilderCoupling;
class ExtACSyntaxCoupling;
class ExtACTree;
class ExtACKeywords;
class ExtGnu;
class ExtGnuCTree;
class ExtCC1X;
class PragmaOnceUnitState;
class PragmaOnce;
namespace Puma {

#line 4536 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AnyCondition : public CTree {
#line 16998 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct Caller {};
  template <typename, int> friend struct Caller;
private:
#line 4536 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 17005 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACBuilderCoupling;
  friend class ::ExtACSyntaxCoupling;
  friend class ::ExtACTree;
  friend class ::ExtACKeywords;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtCC1X;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4536 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // arg1, arg2, arg3

public:
  /** Constructor.
   *  \param a1 The first argument.
   *  \param a2 The optional second argument.
   *  \param a3 The optional third argument. */
  CT_AnyCondition (CTree *a1, CTree *a2 = (CTree*)0, CTree *a3 = (CTree*)0) {
    AddSon (sons[0], a1); AddSon (sons[1], a2); AddSon (sons[2], a3); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
};


} // namespace Puma

#endif /* __CTree_h__ */

#line 17072 "/tmp/aspectc++/AspectC++-Project/Puma/gen-release/step2/inc/Puma/CTree.h"

#ifdef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CTree_h__
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderH_ah__
#include "Puma/ExtACBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACBuilderCC_ah__
#include "Puma/ExtACBuilderCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxH_ah__
#include "Puma/ExtACSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACSyntaxCC_ah__
#include "Puma/ExtACSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderH_ah__
#include "Puma/ExtCC1XBuilderH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XBuilderCC_ah__
#include "Puma/ExtCC1XBuilderCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxH_ah__
#include "Puma/ExtCC1XSyntaxH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSyntaxCC_ah__
#include "Puma/ExtCC1XSyntaxCC.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticH_ah__
#include "Puma/ExtCC1XSemanticH.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtACKeywords_ah__
#include "Puma/ExtACKeywords.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1X_ah__
#include "Puma/ExtCC1X.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_ExtCC1XSemanticCC_ah__
#include "Puma/ExtCC1XSemanticCC.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1__
#undef __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CTree_h__
#endif // __ac_FIRST_FILE__tmp_aspectc4343_AspectC434345Project_Puma_gen45release_step1_inc_Puma_CTree_h__
