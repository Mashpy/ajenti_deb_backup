require 'active_support/core_ext/process/daemon'
