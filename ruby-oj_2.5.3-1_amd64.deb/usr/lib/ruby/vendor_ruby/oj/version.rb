
module Oj
  # Current version of the module. 
  VERSION = '2.5.3'
end
