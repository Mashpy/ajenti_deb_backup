module Arel
  InnerJoin = Nodes::InnerJoin
  OuterJoin = Nodes::OuterJoin
end
