yn_getter = lambda x: x == 'yes'
yn_setter = lambda x: 'yes' if x else 'no'
onezero_getter = lambda x: x == '1'
onezero_setter = lambda x: '1' if x else '0'
