##
## $Release: 2.7.0 $
## copyright(c) 2006-2011 kuwata-lab.com all rights reserved.
##

##
## you can add site-local settings here.
## this files is required by erubis.rb
##
