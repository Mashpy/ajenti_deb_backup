/* freebsd9 is a superset of freebsd8 */
#include "freebsd8.h"
#define freebsd9 freebsd9
