/* freebsd7 is a superset of freebsd6 */
#include "freebsd6.h"
#define freebsd6 freebsd6
