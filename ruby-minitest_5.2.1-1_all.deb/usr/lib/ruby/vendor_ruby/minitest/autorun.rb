require "minitest"
require "minitest/spec"
require "minitest/mock"

Minitest.autorun
