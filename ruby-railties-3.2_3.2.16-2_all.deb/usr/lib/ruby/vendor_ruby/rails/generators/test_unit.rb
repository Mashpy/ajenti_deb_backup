require 'rails/generators/named_base'

module TestUnit
  module Generators
    class Base < Rails::Generators::NamedBase #:nodoc:
    end
  end
end
