require 'test_helper'

class <%= class_name %>Test < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
