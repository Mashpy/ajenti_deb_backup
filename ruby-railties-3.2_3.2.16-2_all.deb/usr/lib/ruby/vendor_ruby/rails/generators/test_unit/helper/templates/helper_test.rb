require 'test_helper'

<% module_namespacing do -%>
class <%= class_name %>HelperTest < ActionView::TestCase
end
<% end -%>
