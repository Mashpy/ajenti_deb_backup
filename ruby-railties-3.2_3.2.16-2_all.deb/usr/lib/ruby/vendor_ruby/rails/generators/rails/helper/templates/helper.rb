<% module_namespacing do -%>
module <%= class_name %>Helper
end
<% end -%>
