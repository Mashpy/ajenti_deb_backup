module Sprockets
  VERSION = "2.10.1"
end
