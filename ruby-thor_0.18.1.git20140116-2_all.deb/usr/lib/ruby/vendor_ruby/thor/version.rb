class Thor
  VERSION = '0.18.1.20140116'
end
